/*
    Cornerstone Framework v0.9.1

    COPYRIGHT(C) 2012 BY SKTELECOM CO., LTD. ALL RIGHTS RESERVED.
    Released under the Apache License, Version 2.0
*/
$(function(){new(MultipageRouter.extend({useDataAttributes:!0})),Backbone.history.start()});