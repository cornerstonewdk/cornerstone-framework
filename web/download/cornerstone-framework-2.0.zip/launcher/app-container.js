/*
    Cornerstone Framework v0.9.1

    COPYRIGHT(C) 2012 BY SKTELECOM CO., LTD. ALL RIGHTS RESERVED.
    Released under the Apache License, Version 2.0
*/
requirejs.config({baseUrl:Cornerstone.App.baseUrl}),require([Cornerstone.App.mainModule],function(a){a.launch()});