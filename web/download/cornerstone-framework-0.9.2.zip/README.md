Cornerstone Framework
=====================

설치 방법
--------

1. 애플리케이션의 최상위 폴더 내에 폴더를 하나 만든다. (아무 이름이나 상관없지만 cornerstone 으로 할 것을 권장한다.)
2. 다운로드 받은 zip 파일의 압축을 풀어서 폴더에 넣는다.

사용 방법
--------

다음 페이지를 방문하면 Cornerstone Framework의 자세한 사용법을 찾을 수 있다.

http://cornerstone.sktelecom.com/livedoc/


COPYRIGHT(C) 2012 BY SKTELECOM CO., LTD. ALL RIGHTS RESERVED.
