
var audios = {};

function createAudio() {
	audios[1] = new Media("file:///android_asset/example/sound/ts01.mp3"); //vuvuzela
	audios[2] = new Media("file:///android_asset/example/sound/ts02.mp3");
	audios[3] = new Media("file:///android_asset/example/sound/ts03.mp3");
	audios[4] = new Media("file:///android_asset/example/sound/ts04.mp3");
	audios[5] = new Media("file:///android_asset/example/sound/ts05.mp3");
}

function onBtnImg(tmpId,tmpImg,tmpFnc){
	$("#"+tmpId+" img").attr("src",tmpImg);
    setTimeout(tmpFnc, 500); //0.5�λ뜇��
}

function goToMenu() {
    $("#menuBtn img").attr("src","img/btn_menu.png");
    document.getElementById("bottomMenu").style.display="inline";
}
function goToPlay(type) {
    document.getElementById("wrapper").style.display="none";
    document.getElementById("playPage").style.display="inline";

    switch (type) {
	case 1  : $("#soundDefault img").attr("src","img/s1.png");
	          tsType = 1;
	          break;
	case 2  : $("#soundDefault img").attr("src","img/s2.png");
	          tsType = 2;
	          break;
	case 3  : $("#soundDefault img").attr("src","img/s3.png");
	          tsType = 3;
	          break;
    case 4  : $("#soundDefault img").attr("src","img/s4.png");
	          tsType = 4;
              break;
    case 5  : $("#soundDefault img").attr("src","img/s5.png");
	          tsType = 5;
              break;				 				 
	default : $("#soundDefault img").attr("src","img/s1.png");
              tsType = 1;
              break;
    }
	goToSubMenuNone(type);
}

function goToPlaySound(soundType) {
	$("#soundDefault img").attr("src","img/s"+soundType+"on.jpg");
	
	switch(soundType){
	case 1: 	navigator.vibrate(1600);
				setTimeout(function() {
					$("#soundDefault img").attr("src","img/s"+soundType+".png");
				}, 1600);
	break;
	case 2: 	navigator.vibrate([500,20,500]);
				setTimeout(function() {
					$("#soundDefault img").attr("src","img/s"+soundType+".png");
				}, 800);
	break;
	case 3: 	navigator.vibrate(500);
				setTimeout(function() {
					$("#soundDefault img").attr("src","img/s"+soundType+".png");
				}, 600);
	break;
	case 4: 	navigator.vibrate([200,100,200,100]);
				setTimeout(function() {
					$("#soundDefault img").attr("src","img/s"+soundType+".png");
				}, 300);
	break;
	case 5: 	navigator.vibrate(1300);
				setTimeout(function() {
					$("#soundDefault img").attr("src","img/s"+soundType+".png");
				}, 1000);
	break;
	}
	
    audios[soundType].play(); 
    
    
}

function goToSubMenuNone(type) {
	$("#subMenu"+type+" img").attr("src","img/m"+type+".png");
	document.getElementById("bottomMenu").style.display="none";
}
