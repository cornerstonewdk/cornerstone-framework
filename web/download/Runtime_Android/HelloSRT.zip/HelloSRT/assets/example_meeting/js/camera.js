var myParent
var mainCamera;
var cameraId;
var op;
var gPhotoNm; //사진 결과파일명
var gAudioNm = ""; //오디오 저장 경로 
var gPhotoName; //사진파일명 추가

function cameraArraySCB(cameras){
	if(cameras.length > 0) {
		//document.getElementById('result').innerHTML += "<br>getCameras SuccessCallback Success! length : " + cameras.length;
		console.log("getCameras SuccessCallback Success! length : " + cameras.length);
		mainCamera = cameras[0];
		createPreviewNode();
	} else {
		//document.getElementById('result').innerHTML += "<br>getCameras SuccessCallback Failed! length : " + cameras.length;
		console.log("getCameras SuccessCallback Failed! length : " + cameras.length);
	}
}

function cameraArrayECB(error){
	//document.getElementById('result').innerHTML += "<br>getCameras ErrorCallback";
	console.log("getCameras ErrorCallback");
}

function getCameras(){
	
	//[20120831][chisu]kwac api 사용 안함 
//	try{
//		deviceapis.camera.getCameras(cameraArraySCB, cameraArrayECB);
//	}catch(e){
//		console.log(e);
//	}
	
	function captureSuccess(filename) {
		
		gPhotoNm = filename;
		//세로모드였으면 가로로 돌려놓고 사진 삽입
		if(gLPMode=="P"){
			$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('webkitTransform','rotate(0deg)');
			$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('width','200px');
			gLPMode = "L";
		}
		if(gLPMode2=="P"){
			$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('webkitTransform','rotate(0deg)');
			$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('width','200px');
			gLPMode2 = "L";
		}
		//20110725수정
		$("#ViewCreateDetail #contentsArea3 .photoArea2 img").attr("src",filename);
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").attr("src",filename);
		//gLayerNm.pop();
		//gLayerNm.pop();
		//fnPageOnOff("ViewPreview", gLayerNm[gLayerNm.length-1]);
		fnRestoreBtnImg();
	}

	// capture error callback
	function captureError(err) {
		// do something with resulting error
		fnRestoreBtnImg();
	}

	// start Image capture
	navigator.capture.captureImage(captureSuccess, captureError, {
		destinationFilename : "file://sdcard/skruntime/meeting/"+ new Date().getTime() + ".png",
		highRes : true
	});
	
}


function getAudios(){
	
	function captureSuccess(filename) {
		
		
		gAudioNm = filename;
		
		document.getElementById("saveaudiopath").value = filename;
		
		fnRestoreBtnImg();
	}

	// capture error callback
	function captureError(err) {
		// do something with resulting error
		fnRestoreBtnImg();
	}

	// start Image capture
	navigator.capture.captureAudio(captureSuccess, captureError, {
		destinationFilename : "file://sdcard/skruntime/meeting/"+ new Date().getTime() + ".wav",
		highRes : true
	});
	
}
/*
function createAudio() {
    function createmediasc (media) {
        alert(media.src + " is created");
        gMedia1 = media;
        gMedia1.play();
    }
    
    function error (err) {
        // do something with resulting error
        alert(err.code);
        // ...
    }
    alert(gAudio);
    alert(gAudioNm);
    
    if(gAudio == "") {
        navigator.mediamanager.createAudio(createmediasc,error,gAudioNm);
    } else {
        navigator.mediamanager.createAudio(createmediasc,error,gAudio);
    }
    
    
}
function playAudios(){
    if(gAudioNm == "" && gAudio == "") {
        return;
    }
    
    if(gMedia1 == "") {
        createAudio();
    } else {
        gMedia1.play();
    }
}
function pauseAudios(){
    
    if(gMedia1 == "") {
        
    } else {
        gMedia1.pause();
    }
}
*/

function captureImage(){
	fnRestoreBtnImg();
//gPhotoNm => gPhotoName으로 변경 gPhotoNm은 전체경로로 지정하여 저장할때 사용, gPhotoName은 순수한 사진파일명
	gPhotoName = new Date().getTime()+".jpg";
	var options = {destinationFilename:"images/mytravel/"+gPhotoName, highRes:true};
	//gPhotoNm = new Date().getTime()+".jpg";
	//var options = {destinationFilename:"mytravel/"+gPhotoNm, highRes:true};
	try{
		mainCamera.captureImage(
			function(filename) {
				//document.getElementById('result').innerHTML +="<br>Captured image path:" + filename;
				console.log("Captured image path:" + filename);
				
//추가부분 시작
		deviceapis.filesystem.resolve(
		    function(file) {
				//20110725수정
				console.log("Captured Image Path URI => "+file.toURI());
				gPhotoNm = file.toURI();
				$("#ViewPreview #cPreviewArea img").attr("src",file.toURI());
//추가부분 끝
				//$("#ViewPreview #cPreviewArea img").attr("src","/mnt/sdcard/images/mytravel/"+gPhotoNm);
				//$("#ViewPreview #cPreviewArea img").css('width','653px');
				//$("#ViewPreview #cPreviewArea img").css('height','480px');
				$("#ViewPreview #cPreviewArea img").css('webkitTransform','rotate(90deg)');
				$("#ViewPreview #cPreviewArea img").css('padding-top','174px');
				$("#ViewPreview #cPreviewArea img").css('width','653px');
				$("#ViewPreview #cPreviewArea img").css('height','480px');

				fnPageOnOff("ViewCamera", "ViewPreview");
				gLayerNm.push("ViewPreview");
//추가부분 시작
		    },
            function(e) {
                console.log("Image Capture (resolve) Failure");
            },
            filename, "r");
//추가부분 끝
		}, function(e) {
			//document.getElementById('result').innerHTML +="<br>Image Capture Failure";
			console.log("Image Capture Failure");
		}, options
	);
		

	}catch(e){
		console.log(e);
	}
}

function startVideoCapture(){
	var options = {destinationFilename:"videos/a.mp4", highRes:true};
	op = mainCamera.startVideoCapture(
		function(filename) {
			//document.getElementById('result').innerHTML +="<br>Captured video path:" + filename;
			console.log("Captured video path:" + filename);
			op = null;
		}, function(e) {
			//document.getElementById('result').innerHTML +="<br>Video Capture Failure";
			console.log("Video Capture Failure");
			op = null;
		}, options
	);
}

function stopVideoCapture(){
	//if (op != null)
	mainCamera.stopVideoCapture();
	//else
	//	       document.getElementById('result').innerHTML +="<br>Video recording cannot be stopped as it already finished";
}

function cameraPreviewSCB(obj){
	myParent = document.getElementById("cPreviewArea");
	cameraId = obj.id;
	obj.width = 480;
	obj.height = 654;
	myParent.appendChild(obj);
	//obj.style.visibility = "visible";
	//document.getElementById('result').innerHTML += "<br>createPreviewNode SuccessCallback Success! : " + cameraId;
	console.log("createPreviewNode SuccessCallback Success! : " + cameraId);
}

function cameraPreviewECB(error){
	//document.getElementById('result').innerHTML += "<br>createPreviewNode ErrorCallback";
	console.log("createPreviewNode ErrorCallback");
} 

function createPreviewNode(){
	mainCamera.createPreviewNode(cameraPreviewSCB, cameraPreviewECB);
}

function deletePreviewNode(){
	var preview = document.getElementById(cameraId);
	preview.style.visibility = "hidden";
	myParent.removeChild(preview);
}


function fnReShot()
{
	imgDelete(gPhotoNm,"ViewCamera");
	fnRestoreBtnImg();
}


function fnUseShot()
{
//추가부분 시작
    deviceapis.filesystem.resolve(
        function(file) {
//추가부분 끝
		//세로모드였으면 가로로 돌려놓고 사진 삽입
		if(gLPMode=="P"){
			$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('webkitTransform','rotate(0deg)');
			$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('width','200px');
			gLPMode = "L";
		}
		if(gLPMode2=="P"){
			$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('webkitTransform','rotate(0deg)');
			$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('width','200px');
			gLPMode2 = "L";
		}
//20110725수정
		$("#ViewCreateDetail #contentsArea3 .photoArea2 img").attr("src",file.toURI());
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").attr("src",file.toURI());
		//$("#ViewCreateDetail #contentsArea3 .photoArea2 img").attr("src","/mnt/sdcard/images/mytravel/"+gPhotoNm);
		//$("#ViewCreateGroup #contentsArea4 .photoArea2 img").attr("src","/mnt/sdcard/images/mytravel/"+gPhotoNm);
		//fnPageOnOff("ViewPreview", "ViewWriteMan");
		//gLayerNm.push("ViewWriteMan");
		gLayerNm.pop();
		gLayerNm.pop();
		fnPageOnOff("ViewPreview", gLayerNm[gLayerNm.length-1]);
		fnRestoreBtnImg();
//추가부분 시작
	},
    function(e) {
        console.log("Useshot failed");
    },"images/mytravel/"+gPhotoName, "r");
//추가부분 끝
}
