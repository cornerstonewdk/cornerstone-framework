var wid;
var wstime;

var wifionoff = "ON"; //와이파이 ON,OFF여부
var nssid = ""; //ssid
var nstrength = "0"; //신호세기
var nstatus = "forbidden";//"connected"; //연결여부


/*
 * 이미지 경로 체크 로직 추가 시작
 */
var threeG = true;
var arrayCnt = 1;
var array3G = new Array();
array3G.push("http://www.iwix.co.kr/img/iwixlogo.jpg");
array3G.push("http://static.naver.com/www/u/2010/0611/nmms_215646753.gif");
array3G.push("http://wstatic.naver.com/w/n_c600.gif");


function set3gValue(){
	threeG = false;
	console.log("connection dead!!!!!!");
}

function set3gImg() {	
	var tmp = 0;
	tmp = arrayCnt%3;
	console.log("array3G URL ====>"+array3G[tmp]+"?date="+ new Date().getTime()); 
	
	$("#3g img").attr("src","img_signal/null.png");
	$("#3g img").attr("src",array3G[tmp]+"?date="+ new Date().getTime());
	arrayCnt ++;
}


function isWiFiHardwareSupported(){
	try{
		function onValueRetrieved1(value) {
			//document.getElementById('textx').innerHTML += "The WiFiHardware status is :"+value+"</br>";
			//alert("The WiFiHardware status is :"+value);
			wifionoff = value;
		}
		if (deviceapis.devicestatus.isSupported('WiFiHardware','status')) {
			deviceapis.devicestatus.getPropertyValue(onValueRetrieved1,	function(error){
				alert("An error occurred " + error.message);
			},{property:"status", aspect:"WiFiHardware"});
		}
	}
	catch(e){
		console.log(e);
	}

}

function isWiFiNetworkSupported1(){
	try{
		function onValueRetrieved2(value) {
			//document.getElementById('textx').innerHTML += "The WiFiNetwork signalStrength is :"+value+"</br>";
			//alert("The WiFiNetwork signalStrength is :"+value);
			nstrength = value;
			console.log("nstrength============"+nstrength);
		}
		
		if (deviceapis.devicestatus.isSupported('WiFiNetwork','signalStrength')) {
			deviceapis.devicestatus.getPropertyValue(onValueRetrieved2, function(error){
				alert("An error occurred " + error.message);
			}, {property:"signalStrength", aspect:"WiFiNetwork"});
		}
		
		function onValueRetrieved3(value) {
			//document.getElementById('textx').innerHTML += "The WiFiNetwork networkStatus is :"+value+"</br>";
			//alert("The WiFiNetwork networkStatus is :"+value);
			nstatus = value;
			console.log("nstatus============"+nstatus);
		}
		
		if (deviceapis.devicestatus.isSupported('WiFiNetwork','networkStatus')) {
			deviceapis.devicestatus.getPropertyValue(onValueRetrieved3, function(error){
				alert("An error occurred " + error.message);
			}, {property:"networkStatus", aspect:"WiFiNetwork"});
		}
		
		function onValueRetrieved1(value) {
			//document.getElementById('textx').innerHTML += "The WiFiNetwork ssid is :"+value+"</br>";
			//alert("The WiFiNetwork ssid is :"+value);
			nssid = value;
			console.log("nssid============"+nssid);
		}
		
		if (deviceapis.devicestatus.isSupported('WiFiNetwork','ssid')) {
			deviceapis.devicestatus.getPropertyValue(onValueRetrieved1, function(error){
				alert("An error occurred " + error.message);
			},{property:"ssid", aspect:"WiFiNetwork"});
		}
	}
	catch(e){
		console.log(e);
	}

}

function watchPropertyChange(){
	var id = null;
	function propertyChange(ref, value) {
		alert("New value for " + ref.property + " is " + value);
		if (wid != null) // After receiving the first notification, we clear it
		{

		}
	}

	wid = deviceapis.devicestatus.watchPropertyChange(propertyChange, function(error){
		alert("An error occured " + error.message);
	}, {property:"batteryLevel", aspect:"Battery"},{minNotificationInterval:1000,maxNotificationInterval:3000,minChangePercent:1});
}

function clearPropertyChange() {
	if(wid != null) {
		deviceapis.devicestatus.clearPropertyChange(wid);
		alert("clear Property Change!");
	}
}


function fnChcekWeakSignal(){
	var retVal = true;
	var wsStr = "";
	if(weakSignalFlag)
	{
		//isWiFiHardwareSupported();
		//isWiFiNetworkSupported1();
		
		console.log("wifionoff="+wifionoff);
		console.log("nssid="+nssid);
		console.log("nstrength="+nstrength);
		console.log("nstatus="+nstatus);
		console.log("3G status ===>"+threeG);
		if(threeG)
		{
			retVal = true;
		}
		else
		{
			if(wifionoff=="OFF"){ //와이파이가 꺼진경우
				document.getElementById("wsdiv").style.display="inline";
				wsStr = "<div id=\"ws_wrapper\"><div class=\"ws_popup\"><ul><li class=\"ws_p_txt\">Network is not connected.</li><li class=\"ws_p_btn01\"><img src=\"img_signal/popup_btn_ok_n.png\" onClick=\"fnClearPop();\" /></li></ul></div></div>";
				document.getElementById("wsdiv").innerHTML = wsStr;
				retVal = false;
			}
			else //와이파이가 켜진경우
			{
				if(nstatus=="connected"){ //연결이 되어있고
					if(nstrength<=25) { //신호세기가 25이하면 신호찾는다는 얘기를 해주고
						document.getElementById("wsdiv").style.display="inline";
						wsStr = "<div id=\"ws_wrapper\"><div class=\"ws_txt01\">It may take a few seconds due to weak network signal</div><div class=\"ws_loading\"><img src=\"img_signal/animationgif_new.gif\" width=\"46\" height=\"46\" /></div><div class=\"ws_b_cancel\"><img src=\"img_signal/btn_cancel_n.png\" width=\"480\" height=\"79\" onClick=\"fnClearPop();\"/></div></div>";
						document.getElementById("wsdiv").innerHTML = wsStr;
						wstime = setTimeout(function(){ //5초뒤에 재실행여부를 물어보는걸로 변경
							wsStr = "<div id=\"ws_wrapper\"><div class=\"ws_popup\"><ul><li class=\"ws_p_txt\">Network signal is weak.<br />Please try again.</li><li class=\"ws_p_btn01\"><img src=\"img_signal/popup_btn_tryagain_n.png\" onClick=\"isWiFiNetworkSupported1();fnClearPop();fnChcekWeakSignal();\"/><span class=\"ws_p_btn02\"><img src=\"img_signal/popup_btn_cancel_n.png\" onClick=\"fnClearPop();\" /></span></li></ul></div></div>";
							document.getElementById("wsdiv").innerHTML = wsStr;
							clearTimeout(wstime);
						}, 5000);
						retVal = false;
					}
					else{ //신호가 25보다 크면 상관없다.
						document.getElementById("wsdiv").innerHTML = "";
						document.getElementById("wsdiv").style.display="none";
						retVal = true;
					}
				}
				else{ //연결이 안되어있으면
					document.getElementById("wsdiv").style.display="inline";
					wsStr = "<div id=\"ws_wrapper\"><div class=\"ws_popup\"><ul><li class=\"ws_p_txt\">Network is not connected.</li><li class=\"ws_p_btn01\"><img src=\"img_signal/popup_btn_ok_n.png\" onClick=\"fnClearPop();\"/></li></ul></div></div>";
					document.getElementById("wsdiv").innerHTML = wsStr;
					retVal = false;
				}
			}
		}
	}
	else{
		retVal = true;
	}
	//console.log("wsStr==>"+wsStr);
	console.log("retVal==>"+retVal);
	return retVal;
	
}

function fnClearPop()
{
	clearTimeout(wstime);
	document.getElementById("wsdiv").style.display="none";
	document.getElementById('wsdiv').innerHTML='';
}





