var gLayerNm = new Array(); //이동한 레이어들의 history
var chkArr = new Array(); //사진삭제 및 분류삭제의 체크플래그
var galleryList = new Array(); //갤러리의 array
var tempArrList = new Array(); //임시어레이
var delFileArr; //지울파일어레이
var gImgPath = "";
var gLPMode = "L" //가로사진 : L, 세로사진 P
var gImgPath2 = "";
var gLPMode2 = "L" //가로사진 : L, 세로사진 P

var gGroupnm = ""; //여행기명
var gGrouploc = ""; //여행기위치
var gGroupmemo = "";//여행기 메모
var gAudio = "";
var gMedia1 = null;

var gListnm = "";//놀이이름
var gGroupseq = ""; //여행기 일련번호
var gListetc1 = ""; //리스트쪽 임시컬럼1
var gListetc2 = ""; //리스트쪽 임시컬럼2
var gListmemo = ""; //메모

var ggGroupseq = "";
var ggListseq = "";


/**
 * 메인페이지 - 여행기보기
 */
function fnMain()
{
	fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewMain");
	gLayerNm.push("ViewMain");
	fnRestoreBtnImg();
	
	//데이터를 구조화한다.
	if(isundefined(groupStr)=="") {
		gGroupArr = new Array();
		gGroupKey = new Array();
	}
	else {
		gGroupArr = fnStrToJson(groupStr); //그룹에대한 string을 json배열로 변경
		gGroupKey = new Array();
		for(var i=0; i<gGroupArr.length; i++)
		{
			//gGroupKey에 key에 맞춰서 배열순서를 매핑하였다.
			gGroupKey[gGroupArr[i]["groupseq"]] = i;
		}
	}
	$("#ViewMain #existNums").html(gGroupArr.length);
	
	var mhtml = "";
	if(gGroupArr.length>0){
		for(var i=0; i<gGroupArr.length; i++){
			mhtml += "<li><a href=\"#\" onClick=\"fnMain0('"+gGroupArr[i]["groupseq"]+"');\"><img src=\"img/icon1.png\" /><p class=\"titleText\">"+gGroupArr[i]["groupnm"]+"</p><p>["+convertTimeStamp(gGroupArr[i]["groupseq"],".")+"] "+gGroupArr[i]["grouploc"]+"</p></a></li>\n";
		}
	}
	document.getElementById("scroller").innerHTML=mhtml;
		
	/* i스크롤 enable */
	var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
		loaded();
		clearTimeout(tmp);
	}, 500);
}

/**
 * 여행기정보조회
 * @param {Object} groupseq
 */
function fnMain0(groupseq) {
	ggGroupseq = groupseq;
	fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewMain0");
	gLayerNm.push("ViewMain0");
	fnRestoreBtnImg();
	
	var vSeq1 = gGroupKey[groupseq];
	console.log("groupseq="+groupseq+"//vSeq1="+vSeq1);
	
	gGroupnm = gGroupArr[vSeq1]["groupnm"]; //여행기명
	gGrouploc = gGroupArr[vSeq1]["grouploc"]; //여행기위치
	gGroupmemo = gGroupArr[vSeq1]["groupmemo"];//여행기 메모
	
	$("#ViewMain0 #officeInfo .titleText2").html(gGroupnm); //여행기이름
	$("#ViewMain0 #officeInfo .adressText").html(gGrouploc); //여행기주소
	//$("#ViewMain0 #contentsArea2 .memoArea").html(gGroupmemo); //여행기메모
	gAddress = gGroupArr[vSeq1]["grouploc"]; //전역변수에 주소세팅 
	
	gLPMode2 = gGroupArr[vSeq1]["imglp"]; //사진 가로/세로모드
	gImgPath2 = gGroupArr[vSeq1]["imgpath"]; //이미지경로
	gAudio = gGroupArr[vSeq1]["audiopath"]; //이미지경로
	gMedia1 = null;
	
	//사진회전관련
	if(gLPMode2=="P"){
		$("#ViewMain0 .bigPhotoArea img").css('webkitTransform','rotate(90deg)');
		$("#ViewMain0 .bigPhotoArea img").css('width','360px');
		$("#ViewMain0 .bigPhotoArea img").css('height','270px');
		$("#ViewMain0 .bigPhotoArea img").css('padding-top','45px');
		$("#ViewMain0 .bigPhotoArea img").css('padding-bottom','45px');
	}
	else{
		$("#ViewMain0 .bigPhotoArea img").css('webkitTransform','rotate(0deg)');
		$("#ViewMain0 .bigPhotoArea img").css('width','480px');
		$("#ViewMain0 .bigPhotoArea img").css('height','360px');
		$("#ViewMain0 .bigPhotoArea img").css('padding-top','0px');
		$("#ViewMain0 .bigPhotoArea img").css('padding-bottom','0px');
	}
	
	//[20120905][chisu]if audio file
	//if(stringContains(gImgPath2 , "3ga")){
	//	$("#ViewMain0 .bigPhotoArea img").attr("src","img/audio.jpg"); //오디오 이미지삽입
	//}
	// if image file
	//else{
		$("#ViewMain0 .bigPhotoArea img").attr("src",gImgPath2); //이미지삽입
	//}	
	
	gGroupmemo = replaceAll(gGroupmemo, "   ", "<br/>");
	document.getElementById("scroller2").innerHTML=gGroupmemo; //메모
	/* i스크롤 enable */
	var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
		loaded2();
		clearTimeout(tmp);
	}, 500);
}




/**
 * 서브리스트에서 체크박스를 선택했을때의 이벤트
 * @param {Object} num
 */
function fnSubCheck(num)
{
	//console.log(num+"::"+chkArr[num]);
	if(!chkArr[num]){
		$("#scroller2 .checkBtn img").eq(num).attr("src","img/btn_check_on.png");
		chkArr[num] = true;
	}
	else{
		$("#scroller2 .checkBtn img").eq(num).attr("src","img/btn_check.png");
		chkArr[num] = false;
	}
}

/**
 * 여행기등록
 */
function fnCreateGroup(){
	fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewCreateGroup");
	gLayerNm.push("ViewCreateGroup");
	fnRestoreBtnImg();
	
	/*초기화*/
	tname = "";
	document.getElementById("iGroupnm").value="";
	document.getElementById("iGrouploc").value="";
	document.getElementById("iGroupmemo").value="";
	document.getElementById("saveaudiopath").value = "";
	
	gGroupnm = ""; //회사명
	gGrouploc = ""; //회사위치
	gGroupmemo = "";//거래처 메모
	gAddress = ""; //위치
	gAudio = "";
	gAudioNm = "";
	gMedia1 = null;
	
	gImgPath2 = "img/nophoto.jpg"; //none 이미지
	gPhotoNm = "";
	$("#ViewCreateGroup #contentsArea4 .photoArea2 img").attr("src",gImgPath2);
	//가로모드로 초기화
	$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('webkitTransform','rotate(0deg)');
	$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('width','200px');
	gLPMode = "L";
	
}

//[20120905][chisu]to Contains str.
function stringContains(strSrc, strTarget){
	strSrc = strSrc.toUpperCase();
	strTarget = strTarget.toUpperCase();
	
	var nSrcLength = strSrc.length;
	var nTargetLength = strTarget.length;
	
	if(strSrc == strTarget){
		return true;
	}
	if(nSrcLength < nTargetLength){
		return false;
	}
	
	for(var i = 0 ; i<nSrcLength ; i++){
		if(strSrc.substr(i , nTargetLength ) == strTarget){
			return true
		}
	}
	return false;
}
//[20120905][chisu]to split string 
function stringSplit(strData, strIndex){ 
	 var stringList = new Array(); 
	 while(strData.indexOf(strIndex) != -1){
	  stringList[stringList.length] = strData.substring(0, strData.indexOf(strIndex)); 
	  strData = strData.substring(strData.indexOf(strIndex)+(strIndex.length), strData.length); 
	 } 
	 stringList[stringList.length] = strData; 
	 return stringList; 
}
	
function fnPlayAudio()
{
	function createmediasc (media) {
		//alert(media.src + " is created");
		gMedia1 = media;
		gMedia1.play();
	}

	function error (err) {
		// do something with resulting error
		alert(err.code);
		// ...
	}

	if(gAudio != "" && gMedia1 == null) 
		navigator.mediamanager.createAudio(createmediasc,error,gAudio);
	else if(gAudio == "" && gMedia1 == null)
		return;
	else
		gMedia1.play();
}

function fnPauseAudio()
{
	if(gMedia1 != null)
		gMedia1.pause();
}

//[20120905][chisu]to send email
function fnSendEmail(){

	var msg = navigator.messaging.createMessage(Messaging.TYPE_EMAIL);
	
	msg.body = "회의장소 : " + gGrouploc + "\n" + "회의내용 : " + replaceAll(gGroupmemo, "<br/>", "\n");
	msg.subject = gGroupnm;
	
	var imagefile = null;
	var audioFile = null;
	
	if(gImgPath2 != "img/nophoto.jpg"){
		var splitStr = stringSplit(gImgPath2,"/");	
		imagefile = new FileEntry(splitStr[splitStr.length - 1],gImgPath2);
	}
	
	if(gAudio != ""){
		var splitAudioStr = stringSplit(gAudio,"/");
		audioFile = new FileEntry(splitAudioStr[splitAudioStr.length - 1],gAudio);		
	}
	
	if(imagefile != null && audioFile != null)
		msg.attachments = [imagefile,audioFile];
	else if(imagefile != null)
		msg.attachments = [imagefile];
	else if(audioFile != null)
		msg.attachments = [audioFile];
	
	try {
		var reval = navigator.messaging.sendMessage(function sc() {
			fnRestoreBtnImg();
		}, function ec(err) {
			alert(err.message)
		}, msg);
	} catch (e) {
		alert(e);
	}
	
}
/**
 * 그룹수정
 */
function fnModifyGroup(){
	fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewCreateGroup");
	gLayerNm.push("ViewCreateGroup");
	fnRestoreBtnImg();
	
	/*데이터세팅*/
	tname = ggGroupseq;
	document.getElementById("iGroupnm").value = gGroupnm;
	document.getElementById("iGrouploc").value = gGrouploc;
	document.getElementById("iGroupmemo").value = replaceAll(gGroupmemo, "<br/>", "\n"); //약속된 스페이스바표시를 엔터기호로 변경
	
	document.getElementById("saveaudiopath").value = gAudio;
	
	
	//사진정보에따라 사진방향 돌리기
	if(gLPMode2=="P"){
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('webkitTransform','rotate(90deg)');
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('width','170px');
	}
	else{
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('webkitTransform','rotate(0deg)');
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('width','200px');
	}
	
	//[20120905][chisu]if audio file
	//if(stringContains(gImgPath2 , "3ga")){
	//	$("#ViewCreateGroup #contentsArea4 .photoArea2 img").attr("src","img/audio.jpg"); //오디오 이미지삽입
	//}
	// if image file
	//else{
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").attr("src",gImgPath2);
	//}	
	
	gPhotoNm = "modify";
	
}

/**
 * 검증1
 */
function fnValidation1()
{
	gGroupnm = (document.getElementById("iGroupnm").value).trim();
	gGrouploc = (document.getElementById("iGrouploc").value).trim();
	gGroupmemo = (document.getElementById("iGroupmemo").value).trim();

	if(gGroupnm==""){ fnErrPop("제목을 입력하세요."); return false;}
	//20110726 저장을 위해 임시로 허용
	//if(gGrouploc == ""){ fnErrPop("위치를 설정하세요."); return false;}
	if(gGroupmemo == ""){ fnErrPop("내용을 입력하세요."); return false;}
	
	return true;
}

/**
 * 그룹등록프로세스
 */
function fnSaveGroup()
{
	fnRestoreBtnImg();
	if(fnValidation1())
	{
		if(gPhotoNm=="") gImgPath2 = "img/nophoto.jpg"; //none 이미지
		else if(gPhotoNm=="modify") {} //수정페이지에서 오는경우는 gImgPath에 모든경로가 다 있어서 수정할필요 없음
//20110725수정
		else gImgPath2 = gPhotoNm;
		//else gImgPath2 = "/mnt/sdcard/images/mytravel/"+gPhotoNm;
		
		if(gAudioNm !="") gAudio = gAudioNm;
		
		//[][chisu]
		var timeStamp = new Date().getTime();
		if(tname==""){ //등록
			gGroupArr.push({groupseq:timeStamp,groupnm:gGroupnm,grouploc:gGrouploc,
							groupmemo:gGroupmemo,imgpath:gImgPath2,imglp:gLPMode2
							,audiopath:gAudio});
		}
		else{ //수정
			timeStamp = tname;
			var vSeq = gGroupKey[timeStamp];
			gGroupArr[vSeq]["groupnm"] = gGroupnm;
			gGroupArr[vSeq]["grouploc"] = gGrouploc;
			gGroupArr[vSeq]["groupmemo"] = gGroupmemo;
			gGroupArr[vSeq]["imgpath"] = gImgPath2;
			gGroupArr[vSeq]["imglp"] = gLPMode2;
			//[20120905][chisu]save audiofile
			gGroupArr[vSeq]["audiopath"] = gAudio;
		}
		groupStr = fnJsonToStr(gGroupArr);
		setPrefItem("groupVal",groupStr);  //Preference에 저장
		fnMain();
	}
}

/**
 * 구글맵 호출
 * @param {Object} addr 주소
 */
function fnMap(addr)
{
    set3gImg(); //3g체크
	isWiFiHardwareSupported(); //wifi체크
	isWiFiNetworkSupported1(); //wifi신호세기체크
	
	var tsignal = setTimeout(function(){ //wifi가져오는 딜레이때문에 interval 함수 호출.
		if(fnChcekWeakSignal()) { //약전계가 아닐때 실행시키겠다.
			if(gLayerNm[gLayerNm.length-1]!="ViewMap"){
				fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewMap");
				gLayerNm.push("ViewMap");
			}
			fnRestoreBtnImg();
			
			if(addr==""){ //위치선택용 지도라면
				$("#ViewMap #directSelect").html("<img src=\"img/map_top.png\" class=\"tipArea\" />");	
				$("#ViewMap #mapBottomMenu").html(" <img id=\"btnMapBack\" src=\"img/map_btn1.jpg\" onClick=\"this.src='img/map_btn1_on.jpg';fnBack('ViewMap');\"/><img src=\"img/map_btn2.jpg\" onClick=\"fnMap('');\"/><img src=\"img/map_btn3.jpg\" onClick=\"fnClickEvt();\" /><img id=\"btnZoomIn\" src=\"img/map_btn4.jpg\" onClick=\"this.src='img/map_btn4_on.jpg';fnZoomIn();\"/><img id=\"btnZoomOut\" src=\"img/map_btn5.jpg\" onClick=\"this.src='img/map_btn5_on.jpg';fnZoomOut();\"/> ");
			}
			else{ //주소검색용이라면
				$("#ViewMap #directSelect").html("");
				$("#ViewMap #mapBottomMenu").html(" <img id=\"btnMapBack\" src=\"img/map_btn1.jpg\" onClick=\"this.src='img/map_btn1_on.jpg';fnBack('ViewMap');\"/><img src=\"img/map_btn2_disable.jpg\" /><img src=\"img/map_btn3_disable.jpg\" /><img id=\"btnZoomIn\" src=\"img/map_btn4.jpg\" onClick=\"this.src='img/map_btn4_on.jpg';fnZoomIn();\"/><img id=\"btnZoomOut\" src=\"img/map_btn5.jpg\" onClick=\"this.src='img/map_btn5_on.jpg';fnZoomOut();\"/> ");		
			}
		
			document.getElementById("tmdiv").style.display="inline"; //약전계 로딩창 활성화
			
			//구글맵 호출
			var tmp = setTimeout(function(){ //interval 함수 호출
				MAPAPI_LOAD(addr); 
			}, 1000);
		}
	}, 1500);
}

/**
 * 전역변수에 주소가 세팅된 상태에서 지도 호출
 */
function fnMap2()
{
	fnMap(gAddress);
}


/**
 * 거래처 삭제 팝업을 띄운다.
 */
function fnDelPopup1()
{
	fnRestoreBtnImg();
	if(ggGroupseq !=""){
		document.getElementById("ViewPopup1").style.display="inline";			
	}
}

/**
 * 담당자 삭제 팝업을 띄운다.
 */
function fnDelPopup2()
{
	fnRestoreBtnImg();
	delFileArr = new Array();
	//console.log(chkArr.join());
	var tmpCnt = 0;
	for(var i=0; i<chkArr.length;i++)
	{
		if(chkArr[i]){
			tmpCnt++;
			delFileArr.push(tempArrList[i]["listseq"]);
		} 
	}
	if(tmpCnt>0){
		document.getElementById("ViewPopup2").style.display="inline";	
	}
}

/**
 * 개별파일삭제 팝업을 띄운다.
 */
function fnOneDelPopup()
{
	delFileArr = new Array();
	delFileArr.push(ggListseq); //읽었던 파일명 넣어주기
	document.getElementById("ViewPopup2").style.display="inline";	
	fnRestoreBtnImg();
}

/**
 * 그룹과 해당되는 담당자들을 모두 삭제한다.
 */
function fnDeleteGroup()
{
	//거래처배열을 삭제한다.
	var vSeq = gGroupKey[ggGroupseq];
	delete gGroupArr[vSeq];
	
	//Preference에 저장
	listStr = fnJsonToStr(gListArr);
	setPrefItem("listVal",listStr); 
	groupStr = fnJsonToStr(gGroupArr);
	setPrefItem("groupVal",groupStr);
	
	document.getElementById("ViewPopup1").style.display="none";
	fnMain();	
}



/**
 * 놀이등록에서 90도 회전
 */
function fnRotate()
{
	$("#ViewCreateDetail #contentsArea3 .photobtn3").attr("src","img/btn_rotate_on.png");
	if(gPhotoNm != "") //none 이미지가 아니면
	{
		if(gLPMode=="L"){
			$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('webkitTransform','rotate(90deg)');
			$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('width','170px');
			//$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('padding','18px');
			gLPMode = "P";
		}
		else if (gLPMode=="P"){
			$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('webkitTransform','rotate(0deg)');
			$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('width','200px');
			//$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('padding','0px');
			gLPMode = "L";
		}
	}
	fnRestoreBtnImg();
}

/**
 * 그룹등록에서 사진회전
 */
function fnRotate2()
{
	$("#ViewCreateGroup #contentsArea4 .photobtn3").attr("src","img/btn_rotate_on.png");
	if(gPhotoNm != "") //none 이미지가 아니면
	{
		if(gLPMode2=="L"){
			$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('webkitTransform','rotate(90deg)');
			$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('width','170px');
			//$("#ViewCreate #imgs").css('padding','18px');
			gLPMode2 = "P";
		}
		else if (gLPMode2=="P"){
			$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('webkitTransform','rotate(0deg)');
			$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('width','200px');
			//$("#ViewCreate #imgs").css('padding','0px');
			gLPMode2 = "L";
		}
	}
	fnRestoreBtnImg();
}

/**
 * 카메라 페이지로 이동후 카메라호출.
 */
function fnGetCamera()
{
	$("#ViewCreateGroup #contentsArea4 .photobtn1").attr("src","img/btn_camera_on.png");
	$("#ViewCreateDetail #contentsArea3 .photobtn1").attr("src","img/btn_camera_on.png");
	
	//[20120831][chisu]화면전환 필요 읍슴
	//fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewCamera");
	//gLayerNm.push("ViewCamera");
	//fnRestoreBtnImg();
	
	getCameras();
}

function fnGetAudio()
{
	$("#ViewCreateGroup #contentsArea4 .photobtn4").attr("src","img/btn_audio.png");
	$("#ViewCreateDetail #contentsArea3 .photobtn4").attr("src","img/btn_audio.png");
	
	//[20120831][chisu]화면전환 필요 읍슴
	//fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewCamera");
	//gLayerNm.push("ViewCamera");
	//fnRestoreBtnImg();
	
	getAudios();
}

/**
 * 갤러리페이지로 이동한다.
 */
function fnGetGallery()
{
	$("#ViewCreateGroup #contentsArea4 .photobtn2").attr("src","img/btn_album_on.png");
	$("#ViewCreateDetail #contentsArea3 .photobtn2").attr("src","img/btn_album_on.png");
	
	fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewGallery");
	gLayerNm.push("ViewGallery");
	fnRestoreBtnImg();
	
	if(fileApplyFlag) fGalleryList(); //갤러리 파일 리스트 불러오기
	else{
		//크롬용 샘플 
		galleryList = new Array();
		for(var j=0; j<20; j++)
		{
			galleryList.push("sample.jpg");
		}
		var ghtml = "";
		for(var i=0; i<galleryList.length;i++)
		{
			ghtml += "<li onClick=\"fnSelectPhoto('"+galleryList[i]+"');\"><img src='img_camera/"+galleryList[i]+"' width='133' height='100' /></li>\n";
		}
		//console.log(ghtml);
		document.getElementById("scroller4").innerHTML=ghtml;
		/* i스크롤 enable */
		var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
			loaded4();
			clearTimeout(tmp);
		}, 500);
	}

}

/**
 * 갤러리에서 삭제 후 갤러리리스트를 재호출할때 쓰는 함수
 */
function fnGetGallery2()
{
	fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewGallery");
	gLayerNm.pop();
	fnRestoreBtnImg();
	
	if(fileApplyFlag) fGalleryList(); //갤러리 파일 리스트 불러오기
	else{
		//크롬용 샘플 
		galleryList = new Array();
		for(var j=0; j<20; j++)
		{
			galleryList.push("sample.jpg");
		}
		var ghtml = "";
		for(var i=0; i<galleryList.length;i++)
		{
			ghtml += "<li onClick=\"fnSelectPhoto('"+galleryList[i]+"');\"><img src='img_camera/"+galleryList[i]+"' width='133' height='100' /></li>\n";
		}
		//console.log(ghtml);
		document.getElementById("scroller4").innerHTML=ghtml;
		/* i스크롤 enable */
		var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
			loaded4();
			clearTimeout(tmp);
		}, 500);
	}
}

/**
 * 갤러리에서 사진을 선택한다.
 * @param {Object} nm
 */
function fnSelectPhoto(nm)
{
	//fnPageOnOff("ViewGallery", "ViewCreateDetail");
	//gLayerNm.push("ViewCreateDetail");
	gLayerNm.pop();
	fnPageOnOff("ViewGallery", gLayerNm[gLayerNm.length-1]);
	
	gPhotoNm = nm;
	//세로모드였으면 가로로 돌려놓고 사진 삽입
	if(gLPMode=="P"){
		$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('webkitTransform','rotate(0deg)');
		$("#ViewCreateDetail #contentsArea3 .photoArea2 img").css('width','200px');
		gLPMode = "L";
	}
	
	//세로모드였으면 가로로 돌려놓고 사진 삽입
	if(gLPMode2=="P"){
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('webkitTransform','rotate(0deg)');
		$("#ViewCreateGroup #contentsArea4 .photoArea2 img").css('width','200px');
		gLPMode2 = "L";
	}
	
//20110725수정부분 gPhotoNm = file.toURI() 사진경로포함파일명	
	$("#ViewCreateGroup #contentsArea4 .photoArea2 img").attr("src",gPhotoNm);
	$("#ViewCreateDetail #contentsArea3 .photoArea2 img").attr("src",gPhotoNm);
	//$("#ViewCreateGroup #contentsArea4 .photoArea2 img").attr("src","/mnt/sdcard/images/mytravel/"+gPhotoNm);
	//$("#ViewCreateDetail #contentsArea3 .photoArea2 img").attr("src","/mnt/sdcard/images/mytravel/"+gPhotoNm);
}

/**
 * 사진삭제 체크박스 만들기
 */
function fnChkDelete()
{
	fnPageOnOff("ViewGallery", "ViewGallery2");
	gLayerNm.push("ViewGallery2");
	fnRestoreBtnImg();
	
	var ghtml = "";
	chkArr = new Array();
	tempArrList = new Array();
	
	for(var i=0; i<galleryList.length;i++)
	{
//20110725수정
		if(fileApplyFlag) ghtml += "<li><span class=\"cDelBtn\"><img src=\"img_camera/c_check.png\" onClick=\"fnGalCheck("+i+");\"/></span><img src='"+galleryList[i]+"' width='133' height='100' /></li>\n";
		//if(fileApplyFlag) ghtml += "<li><span class=\"cDelBtn\"><img src=\"img_camera/c_check.png\" onClick=\"fnGalCheck("+i+");\"/></span><img src='/mnt/sdcard/images/mytravel/"+galleryList[i]+"' width='133' height='100' /></li>\n";
		else ghtml += "<li><span class=\"cDelBtn\"><img src=\"img_camera/c_check.png\" onClick=\"fnGalCheck("+i+");\"/></span><img src='img_camera/"+galleryList[i]+"' width='133' height='100' /></li>\n"; 
		chkArr.push(false);
		tempArrList.push(galleryList[i]);
	}
	//console.log(ghtml);
	document.getElementById("scroller5").innerHTML=ghtml;
	/* i스크롤 enable */
	var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
		loaded5();
		clearTimeout(tmp);
	}, 500);
}

/**
 * 갤러리에서 체크박스 선택
 * @param {Object} num
 */
function fnGalCheck(num)
{
	if(!chkArr[num]){
		$("#ViewGallery2 .galleryList .cDelBtn img").eq(num).attr("src","img_camera/c_check_on.png");
		chkArr[num] = true;
	}
	else{
		$("#ViewGallery2 .galleryList .cDelBtn img").eq(num).attr("src","img_camera/c_check.png");
		chkArr[num] = false;
	}
}

/**
 * 갤러리 삭제 팝업을 띄운다.
 */
function fnGalDelPopup()
{
	delFileArr = new Array();
	//console.log(chkArr.join());
	var tmpCnt = 0;
	for(var i=0; i<chkArr.length;i++)
	{
		if(chkArr[i]){
			tmpCnt++;
			delFileArr.push(tempArrList[i]);
		} 
	}
	if(tmpCnt>0){
		document.getElementById("ViewPopup3").style.display="inline";	
		//console.log(delFileArr.join());
	}
	fnRestoreBtnImg();
	//fnPageOnOff("ViewSubList","ViewPopup1");
	//gLayerNm.push("ViewPopup1");
}



/**
 * 선택한 사진 삭제
 */
function fnPhotoDelete()
{
	imgDelete(delFileArr.join(),"ViewGallery")
	fnRestoreBtnImg();
}


/**
 * 에러팝업 띄우기
 * @param {Object} cont
 */
function fnErrPop(cont)
{ 
	$("#ViewErrPop #popupcontents .popupText").html(cont);
	document.getElementById('ViewErrPop').style.display='inline';
}

/**
 * 뒤로 이동
 * @param {Object} source
 */
function fnBack(source)
{
	if (source=="ViewCreate"){
		fnPageOnOff(source, "ViewMain");
		gLayerNm.push("ViewMain");
	}
	else if(source=="ViewCreate2"){
		fnPageOnOff(source, "ViewMain2");
		gLayerNm.push("ViewMain2");
	}
	else if(source=="ViewMain2"){
		fnPageOnOff(source, "ViewMain");
		gLayerNm.push("ViewMain");
	}
	else if(source=="ViewMain3"){
		fnPageOnOff(source, "ViewMain2");
		gLayerNm.push("ViewMain2");
	}
	else{
		gLayerNm.pop();
		fnPageOnOff(source, gLayerNm[gLayerNm.length-1]);
		if(source=="ViewGallery2"){
			if(fileApplyFlag) fGalleryList(); //갤러리 파일 리스트 불러오기
		}
	}
	fnRestoreBtnImg();
	
	
}

/**
 * 페이지단위의 레이어를 온,오프시킨다.
 * @param {Object} source 오프시킬 현재레이어 
 * @param {Object} target 온 시킬 바꿀레이어
 */
function fnPageOnOff(source, target)
{
	var tmp = setTimeout(function(){ //interval 함수 호출

		document.getElementById(source).style.display="none";
		document.getElementById(target).style.display="inline";
		hLayerNm = source;
		if (gLayerNm.length > 100) {
			for (i = 0; i < 95; i++) {
				gLayerNm.shift();
			}
		}
		console.log(gLayerNm.join());
		
		if(target=="ViewMain0" || target=="ViewCreateGroup") $("#everybody").attr("style","overflow:scroll");
		else $("#everybody").attr("style","overflow:hidden");
		clearTimeout(tmp);
	}, 400);

}

/**
 * 모든(설정된) 버튼에대해 원래이미지로 돌리는 함수
 */
function fnRestoreBtnImg(){
	var temp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.

		$("#ViewMain0 #btnDelete").attr("src","img/btn_delete.png");
		$("#ViewMain0 #btnModify").attr("src","img/btn_modify.png");
		$("#ViewMain0 #btnMap").attr("src","img/btn_map.png");
		$("#ViewMain0 #btnMail").attr("src","img/btn_mail.png");
        $("#ViewMain0 #btnPlay").attr("src","img/btn_play.png");
        $("#ViewMain0 #btnPause").attr("src","img/btn_pause.png");
		
		$("#ViewCreateGroup #contentsArea4 .photobtn1").attr("src","img/btn_camera.png");
		$("#ViewCreateGroup #contentsArea4 .photobtn2").attr("src","img/btn_album.png");
		$("#ViewCreateGroup #contentsArea4 .photobtn3").attr("src","img/btn_rotate.png");
		$("#ViewCreateGroup #contentsArea4 .photobtn4").attr("src","img/btn_audio.png");
        $("#ViewCreateGroup #contentsArea4 .photobtn5").attr("src","img/btn_play.png");
        $("#ViewCreateGroup #contentsArea4 .photobtn6").attr("src","img/btn_pause.png");
		
		$("#ViewCreateGroup #btnGroupSave").attr("src","img/btn_bottom_write.jpg");
		$("#ViewCreateGroup #btnGroupCancel").attr("src","img/btn_bottom_cancel.jpg");
		$("#ViewCreateGroup #btnLocation").attr("src","img/btn_location.png");
		
		$("#ViewMap #btnMapBack").attr("src","img/map_btn1.jpg");
		$("#ViewMap #btnZoomIn").attr("src","img/map_btn4.jpg");
		$("#ViewMap #btnZoomOut").attr("src","img/map_btn5.jpg");
		
		$("#ViewCamera #btnCameraBack").attr("src","img_camera/c_btn_back.jpg");
		$("#ViewCamera #btnCameraShot").attr("src","img_camera/c_btn_shot.jpg");
		
		$("#ViewPreview #btnCameraBack").attr("src","img_camera/c_btn_back.jpg");
		$("#ViewPreview #btnReShot").attr("src","img_camera/c_btn_shotagain.jpg");
		$("#ViewPreview #btnUseShot").attr("src","img_camera/c_btn_use.jpg");

		$("#ViewGallery #cTopBtn #btnGalBack").attr("src","img_camera/c_btn_back2.jpg");
		$("#ViewGallery #cTopBtn #btnGalDel").attr("src","img_camera/c_btn_del.jpg");
		
		$("#ViewGallery2 #cTopBtn #btnGalBack").attr("src","img_camera/c_btn_back2.jpg");
		$("#ViewGallery2 #cTopBtn #btnSelDel").attr("src","img_camera/c_btn_seldel.jpg");
		$("#ViewGallery2 #cTopBtn #btnGalList").attr("src","img_camera/c_btn_list.jpg");
		
		clearTimeout(temp);
	}, 400);
}


/**
 * 숫자만 걸러낸다.
 * @param {Object} obj
 */
function getOnlyNumber(obj)
{
	var fff = false;
	var vlu = obj.value;
	var str = "";
	for (var i=0; i< vlu.length; i++) { 
		ch = vlu.charAt(i); 
		if ("0" <= ch && ch <= "9") {
			str += ch;
			obj.value = str;
		}
		else {
			obj.value = str;
			fff = true;
		}
	}
	if(fff) fnErrPop("숫자만 입력하세요.");
	//return str;
}
