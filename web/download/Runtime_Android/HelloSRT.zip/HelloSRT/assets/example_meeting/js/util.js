/**
 * Util fnc - widget.preferences.setItem
 * by HeeJu 2011.02.17 
 * @param {Object} sKey
 * @param {Object} item
 */ 
function setPrefItem(sKey, item){
    /* config.xml에 key값이 설정되어 있어야함
     * xml 설정 방법 <preference name="여기에 key명을 설정" value=""/>
     * key값을 여러개 설정가능
     */
	try{
		//widget.preferences.setItem(sKey, fnUrlEncode(item));
		navigator.preferences.setItem(sKey, fnUrlEncode(item));
	}catch(e){
		console.log(e);
	}
}

/**
 * Util fnc - widget.preferences.getItem
 * by HeeJu 2011.02.17 
 * @param {Object} sKey
 */ 
function getPrefItem(sKey){
     var getData = "";
	try{
	    //if (typeof widget.preferences.getItem(sKey) != 'undefined') {
		if (typeof navigator.preferences.getItem(sKey) != 'undefined') {
	        //getData = widget.preferences.getItem(sKey); // 위아래 둘다 사용가능
	    	getData = navigator.preferences.getItem(sKey); // 위아래 둘다 사용가능
	    }else{
	        return "";
	    }
	}catch(e){
		console.log(e);
	}
    
    return fnUrlDecode(isundefined(getData));
}


//===================================================================
// JAVA에서 URLDecoder.decode() 로 받을수 있게 인코딩하기
//===================================================================
function fnUrlEncode(str){
     var s0, i, s, u;
     s0 = "";
     for (var i = 0; i < str.length; i++){
         s = str.charAt(i);
         u = str.charCodeAt(i);
         if (s == " "){s0 += "+";}
         else {
             if ( u == 0x2a || u == 0x2d || u == 0x2e || u == 0x5f || ((u >= 0x30) && (u <= 0x39)) || ((u >= 0x41) && (u <= 0x5a)) || ((u >= 0x61) && (u <= 0x7a))){
                 s0 = s0 + s;
             }else {
                 if ((u >= 0x0) && (u <= 0x7f)){
                     s = "0"+u.toString(16);
                     s0 += "%"+ s.substr(s.length-2);
                 } else if (u > 0x1fffff){
                     s0 += "%" + (oxf0 + ((u & 0x1c0000) >> 18)).toString(16);
                     s0 += "%" + (0x80 + ((u & 0x3f000) >> 12)).toString(16);
                     s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
                     s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                 } else if (u > 0x7ff){
                     s0 += "%" + (0xe0 + ((u & 0xf000) >> 12)).toString(16);
                     s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
                     s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                 } else {
                     s0 += "%" + (0xc0 + ((u & 0x7c0) >> 6)).toString(16);
                     s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                 }
             }
         }
     }
     return s0;
 }

//===================================================================
// JAVA에서 URLEncoder.encode() 로 인코딩된 Str 디코딩하기
//===================================================================
function fnUrlDecode(str){
    var s0, i, j, s, ss, u, n, f;
    s0 = "";

    for (var i = 0; i < str.length; i++){
        s = str.charAt(i);
        if (s == "+"){
            s0 += " ";
        }else {
            if (s != "%"){
                s0 += s;
            }else{
                u = 0;
                f = 1;
                while (true) {
                    ss = "";
                    for (var j = 0; j < 2; j++ ) {
                        sss = str.charAt(++i);
                        if (((sss >= "0") && (sss <= "9")) || ((sss >= "a") && (sss <= "f"))  || ((sss >= "A") && (sss <= "F"))) {
                            ss += sss;
                        } else {
                            --i;
                            break;
                        }
                    }
                    n = parseInt(ss, 16);
                    if (n <= 0x7f){u = n; f = 1;}
                    if ((n >= 0xc0) && (n <= 0xdf)){u = n & 0x1f; f = 2;}
                    if ((n >= 0xe0) && (n <= 0xef)){u = n & 0x0f; f = 3;}
                    if ((n >= 0xf0) && (n <= 0xf7)){u = n & 0x07; f = 4;}
                    if ((n >= 0x80) && (n <= 0xbf)){u = (u << 6) + (n & 0x3f); --f;}
                    if (f <= 1){break;}
                    if (str.charAt(i + 1) == "%"){ i++ ;}
                    else {break;}
                }
                s0 += String.fromCharCode(u);
            }
        }
    }
    return s0;
} 

/**
 * Util fnc - 제목 줄임 기능
 * by Heeju 2011.02.11 
 * @param {Object} strText
 * @param {Object} strLen
 */ 
function getDisplayString(strText, strLen)
{
    var str      = ""; // 치환 되어질 값을 담을 변수 
    var title    = ""; // 치환되어져 제목이 담길 변수 
    
    var len = strLen; //제목글자 갯수 
      
    str = strText; 
    var l = 0; 
      
    for (var x=0; x<str.length; x++)
    {  
          
        l += (parseInt(str.charAt(x),10) > 128) ? 2 : 1;  
        
        if (l > len)
        { 
            title = str.substring(0,x) + "..."; 
            break; 
        } 
    } 
    //치환되지 않았을 경우.. 원래 데이터를 title에 셋팅해준다. 
    if("" == title){ 
           title = str;     
    }  
    return title;
}

/* ----------------------------------------------------------------------------
 * by boram 2011.02.11
 * 특정 날짜에 대해 지정한 값만큼 가감(+-)한 날짜를 반환 
 *
 * ----입력 파라미터 -----
 * pInterval : "yyyy" 는 연도 가감, "m" 은 월 가감, "d" 는 일 가감
 * pAddVal  : 가감 하고자 하는 값 (정수형)
 * pYyyymmdd : 가감의 기준이 되는 날짜
 * pDelimiter : pYyyymmdd 값에 사용된 구분자를 설정 (없으면 "" 입력)
 * 
 * ----반환값 ----
 * yyyymmdd 또는 함수 입력시 지정된 구분자를 가지는 yyyy(구분자)mm(구분자)dd 값
 * 
 * ----사용예 ---
 * 2008-01-01 에 3 일 더하기 ==> addDate("d", 3, "2008-08-01", "-");
 * 20080301 에 8 개월 더하기 ==> addDate("m", 8, "20080301", "");
 --------------------------------------------------------------------------- */
function calcuDate(pInterval, pAddVal, pYyyymmdd, pDelimiter)
{
	var yyyy;
	var mm;
	var dd;
	var cDate;
	var oDate;
	var cYear, cMonth, cDay;
	
	if (pDelimiter != "") {
		pYyyymmdd = pYyyymmdd.replace(eval("/\\" + pDelimiter + "/g"), "");
	}
	
	yyyy = pYyyymmdd.substr(0, 4);
	mm  = pYyyymmdd.substr(4, 2);
	dd  = pYyyymmdd.substr(6, 2);
	
	if (pInterval == "yyyy") {
		yyyy = (yyyy * 1) + (pAddVal * 1);
	} else if (pInterval == "m") {
		mm  = (mm * 1) + (pAddVal * 1);
	} else if (pInterval == "d") {
		dd  = (dd * 1) + (pAddVal * 1);
	}
	
	cDate = new Date(yyyy, mm - 1, dd) // 12월, 31일을 초과하는 입력값에 대해 자동으로 계산된 날짜가 만들어짐.
	cYear = cDate.getFullYear();
	cMonth = cDate.getMonth() + 1;
	cDay = cDate.getDate();
	
	cMonth = cMonth < 10 ? "0" + cMonth : cMonth;
	cDay = cDay < 10 ? "0" + cDay : cDay;
	
	if (pDelimiter != "") {
		return cYear + pDelimiter + cMonth + pDelimiter + cDay;
	} else {
		return cYear + cMonth + cDay;
	}
}

/**
 * 해당월의 마지막 날짜를 리턴한다.
 * ex)1월->31일, 2월->28일 혹은 29일...
 * @param {Object} yyyy
 * @param {Object} mm
 */
function getLastestDay(yyyy, mm) {
   var mmm = Number(mm)-1;

   var end = new Array(31,28,31,30,31,30,31,31,30,31,30,31);
   if ((yyyy % 4 == 0 && yyyy % 100 != 0) || yyyy % 400 == 0) {
       end[1] = 29;
   }
   var retVal = end[mmm];
   

   return retVal;
}

/**
 * 한자리숫자일경우 "0"을 붙여서 리턴. ex) 1->01, 10->10
 * by boram 2011.02.11
 * @param {Object} val
 */
function setZeroStr(val){
	if( Number(val) < 10 ) return "0"+val;
	else return val;
}

/**
 * 1에서 입력받은 숫자중 랜덤으로 하나를 리턴한다. by boram 2011.02.11
 * ex) getRandNumber(100) --> 1~100중 랜덤한 숫자1개 리턴
 * @param {Object} max
 */
function getRandNumber(max)
{
	var t = Math.floor(Math.random()*max)+1;

	return t;
}



/**
 * 숫자에 콤마를 찍어준다. by boram 2011.02.11
 * ex) putComma("10000000") --> 10,000,000
 * ex) putComma("100123.12") --> 100,123.12
 * @param {Object} strData
 */
function putComma( strData ){
	if( strData == "undefined" || strData == null || strData == "" ) return "0";
	var retValue = "";
	strData = strData + "";
	try{
		var data = strData.replace( /[^0-9]/ ,"");

		var tmp2 = ""+strData+""; //string형태로 형변환
		var tmp = tmp2.split('.'); //소수점을 자르고
		var data2 = "";
		if(tmp.length>1){
			// 소수점 자리 원 단위로 만들어서 리턴..!!
			data = tmp[0]; //소수점이상
			data2 = "."+tmp[1]; //소수점이하
		}
		if( data.length <= 3 ) return data+data2;

		var len = data.length;

		for( var i = 0; i < len; i++ ) 
		{
			if( i != 0 && ( i % 3 == len % 3) ) 
				retValue += ",";

			if( i < data.length )
				retValue += data.charAt(i);
		}
	}catch( e ){}

	return retValue+data2;
}


/**
 * 문자를 대체한다.
 * @param {Object} str-원문자열
 * @param {Object} baseStr-바꿀문자
 * @param {Object} repStr-대체할문자
 */
function replaceAll(str, baseStr, repStr) {
    var index;
    while (str.search(baseStr) != -1) {
      str = str.replace(baseStr, repStr);
    }
    return str;
}

/**
 * 문자열을 구분자로 나눈다.
 * @param {Object} originString - 원 문자열
 * @param {Object} delimeter - 구분자
 */
function stringTokenizer(originString, delimeter)
{
	var result = new Array();
	var i = 0;
	while(true)
	{
		if(originString.indexOf(delimeter) < 0){
			result[i] = trim(originString);
			break;
		}else{
			result[i] = originString.substring(0,originString.indexOf(delimeter));
			originString = originString.substring(originString.indexOf(delimeter) + delimeter.length);
		}

		i++;
	}

	return result;
}


/**
 * 한글이 하나라도 섞여 있으면true를 반환
 * @param {Object} val
 */
function is_han(val) {
	var judge = false;
	for(var i = 0; i < val.length; i++) {
		var chr = val.substr(i,1);
		chr = escape(chr);
		if(chr.charAt(1) == "u") {
			chr = chr.substr(2, (chr.length - 1));
			if((chr >= "3131"&& chr <= "3163") || (chr >= "AC00"&& chr <= "D7A3")) {
				judge = true;
				break;
			}
		}
		else judge = false;
	}
	return judge;
} 

/**
 * yyyymmdd 형식의 string을 date형태로 바꿔준다.
 * 예) 20110102 -> 2011.01.02
 * @param {Object} originString
 * @param {Object} delimeter
 */
function makeDateForm(originString, delimeter)
{
	var returnVal = originString;
	if(originString.length==8){
		 var tempy = originString.substring(0,4);
		 var tempm = originString.substring(4,6);
		 var tempd = originString.substring(6,8);
		 
		 returnVal = tempy+delimeter+tempm+delimeter+tempd;
	}
	//console.log(returnVal);
	return returnVal;
}

/**
 * timestamp로 된 string을 date형태의string으로 변환시켜준다.
 * @param {Object} timestamp
 */
function convertTimeStamp(timestamp, delimeter)
{
	var retDate = timestamp;
	var expDate = new Date();
	expDate.setTime(timestamp);
	var vYear = expDate.getFullYear();
	var vMonth = fnPutZeroStr(expDate.getMonth()+1);
	var vDay = fnPutZeroStr(expDate.getDate());
	
	if(delimeter=="" || delimeter==null) retDate = vYear+vMonth+vDay;
	else retDate = makeDateForm(vYear+vMonth+vDay,delimeter);
	
	return retDate;
}

/**
 * 값이 undefined일경우 ""를 반환한다.
 * @param {Object} val
 */
function isundefined(val)
{
	if(val=="undefined" || val==undefined || val==null || val=="null" || val=="none") return "";
	else return val;
}

/**
 * 특수문자 제거 - 정규식을 이용
 * @param {Object} nValue
 */
function setFilter(nValue)
{
	var strobj = document.getElementById(nValue);
    re = /[\{\}\[\]\/?.,;:|\)*~`!^\-_+┼<>@\#$%&\'\"\\\(\=]/gi;
	
	if(re.test(strobj.value))
	{
		//alert("특수문자는 입력하실 수 없습니다.");
		fnErrPop("특수문자는 입력하실 수 없습니다.");
		strobj.value = strobj.value.replace(re,"");
		//strobj.focus();
		return;
	}
}

/**
 * json문법의 string을 json배열로 리턴한다.
 * @param {Object} str
 */
function fnStrToJson(str)
{
	var vStr = "";
	var sArr = new Array();
	var retArr = new Array();
	if(isundefined(str)!=""){
		vStr = replaceAll(str, "},{", "}##{");
		vStr = replaceAll(vStr, "\n", "<br/>"); //엔터기호를 약속된기호로 변경
		//console.log(vStr);
		sArr = vStr.split("##");
		//배열을 등록시간 역순으로 정렬
		sArr.sort();
		sArr.reverse();
		for(var i=0; i<sArr.length; i++)
		{
			retArr.push(eval("("+sArr[i]+")"));
		}
	}
	return retArr;
}


/**
 * json 배열을 json형식의 String으로 리턴한다.
 * @param {Object} jsonArr
 */
function fnJsonToStr(jsonArr)
{
	var vStr = "";
	var tStr = ""; //json배열 삭제해서 들어왔을경우를 대비한 플래그
	
	if(jsonArr.length>0){
		for(var i=0; i<jsonArr.length; i++){
			vStr += "{";
			tStr = ""
			for (var j in jsonArr[i]) {
				//console.log(j+"="+gGroupArr[i][j]);
				vStr += j+":'"+jsonArr[i][j]+"',";
				tStr = j;
			}
			vStr = vStr.substr(0,vStr.length-1);
			if(tStr!="") vStr += "},";
		}
		vStr = vStr.substr(0,vStr.length-1);
	}
	//console.log(vStr);
	return vStr;
}

/*
function removeArray(arr,index){
	var retArr = arr.slice(0, index).concat(arr.slice(index+1));
	return retArr;
}
*/