var fname = "";
var tname = "";
var fileContents = "";
var fileListArr = new Array();
var fcnt = 0;
var ghtml = "";


/**
 * 디렉토리가 존재하는지 체크
 * 없으면 만들고, 있으면 패스한다.
 */
function isDir()
{
	var documentsDir;
	try{
		deviceapis.filesystem.resolve(
			function(dir){
				documentsDir = dir;
				//var newDir = documentsDir.createDirectory("newDir");
				//var anotherNewDir = documentsDir.createDirectory("iwix/mytravel");
//20110727수정 Exception 방지를 위한 try~catch
	            var anotherNewDir;
				try {
					anotherNewDir = documentsDir.createDirectory("iwix/mytravel");
				} catch(e) {
					console.log("Dir is Already Created!");
				}
				
				if(anotherNewDir != null){
					//document.getElementById('textx').innerHTML += anotherNewDir.fullPath + "directory created"+"</br>";
					console.log(anotherNewDir.fullPath + " directory created");
					//fread("setting"); //세팅파일읽기
				} else{
					console.log("dir is already created!");
					//fread("setting"); //세팅파일읽기
				}
			}, function(e){
				alert("Error" + e.message);
			}, 'documents', 'rw'
		);
	} catch(e){
		console.log(e);
	}
}

function isDir2()
{
	var documentsDir;
	try{
		deviceapis.filesystem.resolve(
			function(dir){
				documentsDir = dir;
				//var newDir = documentsDir.createDirectory("newDir");
				//var anotherNewDir = documentsDir.createDirectory("mytravel");
//20110727수정 Exception 방지를 위한 try~catch
	            var anotherNewDir;
				try {
					anotherNewDir = documentsDir.createDirectory("mytravel");
				} catch(e) {
					console.log("Dir is Already Created!");
				}
				
				if(anotherNewDir != null){
					//document.getElementById('textx').innerHTML += anotherNewDir.fullPath + "directory created"+"</br>";
					console.log(anotherNewDir.fullPath + " directory created");
				} else{
					console.log("dir is already created!");
				}
			}, function(e){
				alert("Error" + e.message);
			}, 'images', 'rw'
		);
	} catch(e){
		console.log(e);
	}
}

/*디렉토리를 맹근다*/
function makeDir()
{
	deviceapis.filesystem.resolve(
	    function(dir){
			var anotherNewDir = dir.createDirectory("iwix/mytravel"); //경로생성 /sdcard/document/iwix/storynote
			console.log("directory create!!!!!!!!!"); 
	    }, 
	    function(e){ alert("Error" + e.message); return true; }, 
	    'documents',  
	    "rw"
	);
}


/**
 * 파일리스트 호출함수
 */
function flist(){

	fileListArr = new Array();
	
	/*
	 * 파일 리스트 성공 프로세스
	 */
	function successCBl(files) {
	
		var len = files.length;
		for(var j=0; j<len; j++)
		{
			fileListArr.push(files[j].name);
		}
		fileListArr.sort(); //오름차순으로 정렬
		
		//fileListArr[0] = "I_20110422_1234567890";//구분명_날짜_시리얼숫자

		var mhtml = fnDispCalendar(syear,smonth);
		$("#ViewMain #tit .month").html(syear+"년"+smonth+"월");
		$("#ViewMain #calendar ul").html(mhtml);
	} 
	
	try {
		deviceapis.filesystem.resolve(
		    function(dir){
		        documentsDir = dir;
		        dir.listFiles(successCBl,errorCB);
		    }, 
		    function(e){ alert("Error" + e.message);  }, 
		    'documents/iwix/mytravel',  
		    "r"
		);
	} catch(e){
		console.log(e);
	}
}

/**
 * 파일리스트 호출함수
 */
function flist2(){

	fileListArr = new Array();
	
	/*
	 * 파일 리스트 성공 프로세스
	 */
	function successCBl(files) {
	
		var len = files.length;
		for(var j=0; j<len; j++)
		{
			fileListArr.push(files[j].name);
		}
		fileListArr.sort(); //오름차순으로 정렬
		
		fnMain(gGubun); //메인달력 호출
	} 
	
	try {
		deviceapis.filesystem.resolve(
		    function(dir){
		        documentsDir = dir;
		        dir.listFiles(successCBl,errorCB);
		    }, 
		    function(e){ alert("Error" + e.message);  }, 
		    'documents/iwix/mytravel',  
		    "r"
		);
	} catch(e){
		console.log(e);
	}
}


/**
 * 파일저장 호출함수
 */
function fsave(){
	
	/*
	 * 파일저장 성공 프로세스
	 */
	function successCBw(files) {
		if(tname!=""){ //기존파일이 있는경우 삭제후 저장
			var len = files.length;
			for(var j=0; j<len; j++)
			{
				if("documents/iwix/mytravel/"+tname==files[j].fullPath) //선택파일만 삭제
				{
					if (false) {}
					else documentsDir.deleteFile(
						
						function(){
							console.log(tname+" delete!");
							
							var sFile = documentsDir.createFile(fname);
							// 생성된 파일 내용 작성
							if (sFile != null) {
								sFile.openStream(
									function(fs){
										fs.write(encodeURL(fileContents));
										fs.close();
										console.log(fname+" saved!");
										flist2(); //저장후 메인리스트 호출
									}, function(e){
										alert("Error " + e.message);
									}, "w", "UTF-8"
								);
							}
							
						}, function(e) {
							alert("Error" + e.message);
						},files[j].fullPath
					);
				}
			}
		}
		else{
			var sFile = documentsDir.createFile(fname);
			// 생성된 파일 내용 작성
			if (sFile != null) {
				sFile.openStream(
					function(fs){
						fs.write(encodeURL(fileContents));
						fs.close();
						console.log(fname+" saved!");
						flist2(); //저장후 메인리스트 호출
					}, function(e){
						alert("Error " + e.message);
					}, "w", "UTF-8"
				);
			}
		}

	}
	
	
	try {
		//파일명과 파일내용은 각 앱의 환경에 맞게 변경
		deviceapis.filesystem.resolve(
		    function(dir){
		        documentsDir = dir;
		        dir.listFiles(successCBw,errorCB);
		    }, 
		    function(e){ alert("Error" + e.message);  }, 
		    //'documents',
		    'documents/iwix/mytravel',  
		    "rw"
		);	
	} catch(e){
		console.log(e);
	}
}

/**
 * 파일내용까지 읽고 리스트로 뿌린다.
 * @param {Object} nm
 */
function fReadList(nm){
	console.log("file read come in");
	fname = nm;
	var readVal = "";
	var readArr;
			
	/*
	 * 파일읽기 성공 프로세스
	 */
	function successCBr(files) {
		var len = files.length;
	
		for(var j=0; j<len; j++)
		{
			//console.log(files[j].name+"::"+fname);
			if(files[j].name==fname) files[j].readAsText(
				function(str){
					readVal = decodeURL(str); 
					
					console.log("file read!="+fname);
					readArr = readVal.split("##");
					
					//파일내용은  구분값#필요도#상품명#금액#쇼핑장소#기타#이미지경로#가로세로
					//           0      1      2     3    4       5     6        7
					console.log("readVal="+readVal);
					
					//필요도구성
					var imgNeed = "";
					if(readArr[1]=="H") imgNeed = "<img src=\"images/need_01.png\" class=\"need\">";
					else if (readArr[1]=="M") imgNeed = "<img src=\"images/need_02.png\" class=\"need\">";
					else if (readArr[1]=="L") imgNeed = "<img src=\"images/need_03.png\" class=\"need\">";
					
					var liClass = "";
					if(fcnt==0)  liClass = " class=\"pd_t20\"";
					else liClass = "";
					
					ghtml += "<li "+liClass+"><img src=\"images/arrow_n.png\" class=\"arrow\">"+imgNeed+"<img src=\"images/check_off.png\" class=\"check\" onClick=\"fnSubCheck("+fcnt+");\"><span onClick=\"fnReadOne('"+fname+"')\"><span class=\"txt01\">"+readArr[2]+"</span><span class=\"txt02\">"+putComma(readArr[3])+"원</span><span class=\"txt03\">"+readArr[4]+"</span><span class=\"txt04\">"+readArr[5]+"</span></span><img src=\"images/line.png\"></li>\n";
					//$("#scroller").append(lhtml);
					fcnt++;
					if(fcnt<tempArrList.length){
						var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
							fReadList(tempArrList[fcnt]);
							clearTimeout(tmp);
						}, 300);
					}
					else{
						document.getElementById("tmdiv").style.display="none"; //로딩창 비활성화
						fnPageOnOff(gLayerNm[gLayerNm.length-1], "ViewItemList");
						gLayerNm.push("ViewItemList");
						//console.log(ghtml);
						document.getElementById("scroller").innerHTML = ghtml;
						/* i스크롤 enable */
						var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
							loaded();
							clearTimeout(tmp);
						}, 600);
					}
				}, function(e){
					alert("Error " + e.message);
				}, "UTF-8"
			);
		}
	}
	
	try{
		deviceapis.filesystem.resolve(
		    function(dir){
		        documentsDir = dir;
		        dir.listFiles(successCBr,errorCB);
		    }, 
		    function(e){ alert("Error" + e.message);  }, 
		    'documents/iwix/mytravel',  
		    "rw"
		);
	}catch(e){
		console.log(e);
	}	
}

/**
 * 파일하나 읽기
 * @param {Object} nm
 */
function fReadOne(nm){
	
	tname = nm;
	fname = nm;
	var readVal = "";
	var readArr;
			
	/*
	 * 파일읽기 성공 프로세스
	 */
	function successCBr(files) {
		var len = files.length;
	
		for(var j=0; j<len; j++)
		{
			//console.log(files[j].name+"::"+fname);
			if(files[j].name==fname) files[j].readAsText(
				function(str){
					readVal = decodeURL(str); 
					
					console.log("readVal="+readVal);
					readArr = readVal.split("##");
					//파일내용은  구분값#필요도#상품명#금액#쇼핑장소#기타#이미지경로#가로세로
					//           0      1      2     3    4       5     6        7
					gGubuns = readArr[0];
					gNeed = readArr[1];
					gProduct = readArr[2];
					gMoney = readArr[3];
					gPlace = readArr[4];
					gEtc = readArr[5];
					gImgPath = readArr[6];
					gLPMode = isundefined(readArr[7])==""?"L":readArr[7];
					console.log("gLPMode="+gLPMode);
					
					//사진회전관련
					if(gLPMode=="P"){
						$("#ViewItemDetail #img_b_horizon img").css('webkitTransform','rotate(90deg)');
						$("#ViewItemDetail #img_b_horizon img").css('width','75%');
						$("#ViewItemDetail #img_b_horizon img").css('height','75%');
						$("#ViewItemDetail #img_b_horizon img").css('padding','42px');
					}
					else{
						$("#ViewItemDetail #img_b_horizon img").css('webkitTransform','rotate(0deg)');
						$("#ViewItemDetail #img_b_horizon img").css('width','100%');
						$("#ViewItemDetail #img_b_horizon img").css('height','100%');
						$("#ViewItemDetail #img_b_horizon img").css('padding','0px');
					}
					
					$("#ViewItemDetail #top .h1").html(gProduct); //상품명
					$("#ViewItemDetail #detail #spanDate").html("등록일:"+fname.substr(2,4)+"년 "+fname.substr(6,2)+"월 "+fname.substr(8,2)+"일"); //등록일
					
					if(gNeed=="H") $("#ViewItemDetail #iconNeed").attr("src","images/need_04.png");
					else if(gNeed=="M") $("#ViewItemDetail #iconNeed").attr("src","images/need_05.png");
					else if(gNeed=="L") $("#ViewItemDetail #iconNeed").attr("src","images/need_06.png");
					
					var vBuyYn = ""; //구매여부
					if(gGubuns=="I") vBuyYn = "구매여부:관심물품<img src=\"images/btn_buy_n.png\" class=\"buy\" onClick=\"fnChangeFlag('"+fname+"');\">";
					else vBuyYn = "구매여부:"+fname.substr(2,4)+"년 "+fname.substr(6,2)+"월 "+fname.substr(8,2)+"일 구매물품";
					$("#ViewItemDetail #detail #spanGubun").html(vBuyYn);//구매여부, 구매일자
					
					$("#ViewItemDetail #img_b_horizon img").attr("src",gImgPath); //이미지
					$("#ViewItemDetail #con_horizon span").eq(0).html("제품명:"+gProduct);
					$("#ViewItemDetail #con_horizon span").eq(1).html("가격:"+putComma(gMoney)+"원");
					$("#ViewItemDetail #con_horizon span").eq(2).html("쇼핑장소:"+gPlace);
					$("#ViewItemDetail #con_horizon span").eq(3).html("기타:"+gEtc);
					
				}, function(e){
					alert("Error " + e.message);
				}, "UTF-8"
			);
		}
	}
	
	try{
		deviceapis.filesystem.resolve(
		    function(dir){
		        documentsDir = dir;
		        dir.listFiles(successCBr,errorCB);
		    }, 
		    function(e){ alert("Error" + e.message);  }, 
		    'documents/iwix/mytravel',  
		    "rw"
		);
	}catch(e){
		console.log(e);
	}	
}

/**
 * 관심물품->구매물품
 * @param {Object} nm
 */
function fChangeFlag(nm){
	
	tname = nm;
	/*
	 * 파일저장 성공 프로세스
	 */
	function successCBw(files) {
		if(tname!=""){ //기존파일이 있는경우 삭제후 저장
			var len = files.length;
			for(var j=0; j<len; j++)
			{
				if("documents/iwix/mytravel/"+tname==files[j].fullPath) //선택파일만 삭제
				{
					if (false) {}
					else documentsDir.deleteFile(
						
						function(){
							console.log(tname+" delete!");
							var sFile = documentsDir.createFile(fname);
							// 생성된 파일 내용 작성
							if (sFile != null) {
								sFile.openStream(
									function(fs){
										fs.write(encodeURL(fileContents));
										fs.close();
										console.log(fname+" saved!");
										
										fnReadOne(fname); //파일 다시 읽기
										flist();//파일리스트 재호출하여 어레이를 재확인
										
									}, function(e){
										alert("Error " + e.message);
									}, "w", "UTF-8"
								);
							}
							
						}, function(e) {
							alert("Error" + e.message);
						},files[j].fullPath
					);
				}
			}
		}
	}
	
	
	try {
		//파일명과 파일내용은 각 앱의 환경에 맞게 변경
		deviceapis.filesystem.resolve(
		    function(dir){
		        documentsDir = dir;
		        dir.listFiles(successCBw,errorCB);
		    }, 
		    function(e){ alert("Error" + e.message);  }, 
		    //'documents',
		    'documents/iwix/mytravel',  
		    "rw"
		);	
	} catch(e){
		console.log(e);
	}
}

/**
 * 파일삭제 호출함수
 * @param {Object} fpath //파일 풀경로 ex)documents/iwix/stroynote/test.txt
 */
function fdelete(){
	//console.log(delFileArr.join());
	/*
	 * 파일삭제 성공 프로세스
	 */
	function successCBd(files) {
		var len = files.length;
		for(var j=0; j<len; j++)
		{
			for(var k=0; k<delFileArr.length; k++)
			{
				//console.log(delFileArr[k]+"::::"+files[j].fullPath);
				if("documents/iwix/mytravel/"+delFileArr[k]==files[j].fullPath) //선택파일만 삭제
				{
					if (false) {}
					else documentsDir.deleteFile(
						
						function(){
							console.log(delFileArr[k]+" delete!");
						}, function(e) {
							alert("Error" + e.message);
						},files[j].fullPath
					);
				}
			}
		}
		flist2();
		document.getElementById("ViewPopup1").style.display="none";
	}
	
	try{
		deviceapis.filesystem.resolve(
		    function(dir){
		        documentsDir = dir;
		        dir.listFiles(successCBd,errorCB);
		    }, 
		    function(e){ alert("Error" + e.message);  }, 
		    'documents/iwix/mytravel',  
		    "rw"
		);
	} catch(e){
		console.log(e);
	}
}


/**
 * 갤러리 파일리스트 호출함수
 */
function fGalleryList(){
	
	galleryList = new Array();
	
//	/*
//	 * 파일 리스트 성공 프로세스
//	 */
//	function successCBl(files) {
//	
//		var len = files.length;
//		for(var j=0; j<len; j++)
//		{
////20110725수정
//			galleryList.push(files[j].toURI());
//			//galleryList.push(files[j].name);
//		}
//		galleryList.sort(); //오름차순으로 정렬
//		
//		//console.log("galleryList.join()="+galleryList.join());
//		var ghtml = "";
//		for(var i=0; i<galleryList.length;i++)
//		{
////20110725수정
//			ghtml += "<li onClick=\"fnSelectPhoto('"+galleryList[i]+"');\"><img src='"+galleryList[i]+"' width='133' height='100' /></li>\n";
//			//ghtml += "<li onClick=\"fnSelectPhoto('"+galleryList[i]+"');\"><img src='/mnt/sdcard/images/mytravel/"+galleryList[i]+"' width='133' height='100' /></li>\n";
//		}
//		//console.log(ghtml);
//		document.getElementById("scroller4").innerHTML=ghtml;
//		/* i스크롤 enable */
//		var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
//			loaded4();
//			clearTimeout(tmp);
//		}, 500);
//		
//		/*
//		for(var i=0; i<galleryList.length;i++)
//		{
//			$("#ViewGallery .galleryList img").eq(i).css('webkitTransform','rotate(90deg)');
//		}
//		*/
//	} 
//	
//	try{
//		deviceapis.filesystem.resolve(
//		    function(dir){
//		        documentsDir = dir;
//		        dir.listFiles(successCBl,errorCB);
//		    }, 
//		    function(e){ alert("Error" + e.message);  }, 
//		    'images/mytravel',  
//		    "r"
//		);
//	} catch(e){
//		console.log(e);
//	}
	
	
	//[20120831][chisu]test
	function onResolveSuccess(dirEntry) {
		console.log(dirEntry.name);
		console.log(dirEntry.fullPath);
		
		function success(files) {
			var len = files.length;
			for(var j=0; j<len; j++)
			{
				galleryList.push(files[j].fullPath);
			}
			galleryList.sort(); //오름차순으로 정렬
			
			var ghtml = "";
			for(var i=0; i<galleryList.length;i++)
			{
				ghtml += "<li onClick=\"fnSelectPhoto('"+galleryList[i]+"');\"><img src='"+galleryList[i]+"' width='133' height='100' /></li>\n";
			}
			document.getElementById("scroller4").innerHTML=ghtml;
			/* i스크롤 enable */
			var tmp = setTimeout(function(){ //interval 함수 호출. 딜레이를 준다.
				loaded4();
				clearTimeout(tmp);
			}, 500);
		}

		function fail(error) {
		    alert("Failed to list directory contents: " + error.code);
		}

		// Get a directory reader
		var directoryReader = dirEntry.createReader();
		// Get a list of all the entries in the directory
		directoryReader.readEntries(success,fail);

	}

	function fail(error) {
		console.log(error.message);
	}

	window.resolveLocalFileSystemURI("file://sdcard/skruntime/meeting",onResolveSuccess, fail);
	
}




/**
 * 이미지를 삭제한다.
 * @param {Object} arr //이미지파일 절대경로 ex)documents/iwix/stroynote/test.txt를 ,로 구분한 string
 * @param {Object} layer //삭제후 이동할 layer
 */
function imgDelete(arr,layer){
	
	var fArr = arr.split(",");
	//console.log("fArr.length="+fArr.length);
	
//	/*
//	 * 파일삭제 성공 프로세스
//	 */
//	function successCBd(files) {
//		
//		var len = files.length;
//	
//		for(var j=0; j<len; j++)
//		{
//			for(var k=0; k<fArr.length; k++)
//			{
////20110725수정
//				if(fArr[k]==files[j].toURI()) //선택파일만 삭제
//				//if("images/mytravel/"+fArr[k]==files[j].fullPath) //선택파일만 삭제
//				{
//					if (false) {}
//					else documentsDir.deleteFile(
//						
//						function(){
//							console.log(delFileArr[k]+" delete!");
//						}, function(e) {
//							alert("Error" + e.message);
//						},files[j].fullPath
//					);
//				}
//			}
//		}
////20100725수정 gallery를 재 호출하는데 삭제과정보다 먼저 이루어져서 시간을 줬음
//	var temp = setTimeout(function() {
//		
//		if(layer=="ViewCamera"){
//			gLayerNm.pop();
//			fnPageOnOff("ViewPreview", layer);
//		}
//		else if (layer=="ViewGallery"){
//			document.getElementById("ViewPopup3").style.display="none";
//			fnGetGallery2(); //삭제후 갤러리페이지로 재이동
//		}
//		clearTimeout(temp);
//	},300);
//	}
//	
//	try{
//		deviceapis.filesystem.resolve(
//		    function(dir){
//		        documentsDir = dir;
//		        dir.listFiles(successCBd,errorCB);
//		    }, 
//		    function(e){ alert("Error" + e.message);  }, 
//		    'images/mytravel',  
//		    "rw"
//		);
//	} catch(e){
//		console.log(e);
//	}
	
	//[20120831][chisu]이걸 사용한다. 
	function onResolveSuccess(dirEntry) {
		
		function success(files) {
			var len = files.length;
			
			for(var j=0; j<len; j++)
			{
				for(var k=0; k<fArr.length; k++)
				{
	//20110725수정
					if(fArr[k]==files[j].fullPath) //선택파일만 삭제
					//if("images/mytravel/"+fArr[k]==files[j].fullPath) //선택파일만 삭제
					{
						if (false) {}
						else {
							//[20120831][chisu]file 지우자
							function successFileRemove() {
							    console.log("Removal succeeded");
							}
							function failFileRemove(error) {
							        console.log(error.code);
							}
							
							//remove file
							files[j].remove(successFileRemove,failFileRemove);
						}
					}
				}
			}
			
		//20100725수정 gallery를 재 호출하는데 삭제과정보다 먼저 이루어져서 시간을 줬음
		var temp = setTimeout(function() {
			
			if(layer=="ViewCamera"){
				gLayerNm.pop();
				fnPageOnOff("ViewPreview", layer);
			}
			else if (layer=="ViewGallery"){
				document.getElementById("ViewPopup3").style.display="none";
				fnGetGallery2(); //삭제후 갤러리페이지로 재이동
			}
			clearTimeout(temp);
		},300);
		}

		function fail(error) {
		    alert("Failed to list directory contents: " + error.code);
		}

		// Get a directory reader
		var directoryReader = dirEntry.createReader();
		// Get a list of all the entries in the directory
		directoryReader.readEntries(success,fail);

	}

	function fail(error) {
		console.log(error.message);
	}

	window.resolveLocalFileSystemURI("file://sdcard/skruntime/meeting",onResolveSuccess, fail);
}


function errorCB(error) {
	alert("The error " + error.message + " occurred when listing the files in the selected folder");
}



//===================================================================
// JAVA에서 URLDecoder.decode() 로 받을수 있게 인코딩하기
//===================================================================
function encodeURL(str){
     var s0, i, s, u;
     s0 = "";
     for (var i = 0; i < str.length; i++){
         s = str.charAt(i);
         u = str.charCodeAt(i);
         if (s == " "){s0 += "+";}
         else {
             if ( u == 0x2a || u == 0x2d || u == 0x2e || u == 0x5f || ((u >= 0x30) && (u <= 0x39)) || ((u >= 0x41) && (u <= 0x5a)) || ((u >= 0x61) && (u <= 0x7a))){
                 s0 = s0 + s;
             }else {
                 if ((u >= 0x0) && (u <= 0x7f)){
                     s = "0"+u.toString(16);
                     s0 += "%"+ s.substr(s.length-2);
                 } else if (u > 0x1fffff){
                     s0 += "%" + (oxf0 + ((u & 0x1c0000) >> 18)).toString(16);
                     s0 += "%" + (0x80 + ((u & 0x3f000) >> 12)).toString(16);
                     s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
                     s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                 } else if (u > 0x7ff){
                     s0 += "%" + (0xe0 + ((u & 0xf000) >> 12)).toString(16);
                     s0 += "%" + (0x80 + ((u & 0xfc0) >> 6)).toString(16);
                     s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                 } else {
                     s0 += "%" + (0xc0 + ((u & 0x7c0) >> 6)).toString(16);
                     s0 += "%" + (0x80 + (u & 0x3f)).toString(16);
                 }
             }
         }
     }
     return s0;
 }

//===================================================================
// JAVA에서 URLEncoder.encode() 로 인코딩된 Str 디코딩하기
//===================================================================
function decodeURL(str){
	var s0, i, j, s, ss, u, n, f;
	s0 = "";

	for (var i = 0; i < str.length; i++){
		s = str.charAt(i);
		if (s == "+"){
			s0 += " ";
		}else {
			if (s != "%"){
				s0 += s;
			}else{
				u = 0;
				f = 1;
				while (true) {
					ss = "";
					for (var j = 0; j < 2; j++ ) {
						sss = str.charAt(++i);
						if (((sss >= "0") && (sss <= "9")) || ((sss >= "a") && (sss <= "f"))  || ((sss >= "A") && (sss <= "F"))) {
							ss += sss;
						} else {
							--i;
							break;
						}
					}
					n = parseInt(ss, 16);
					if (n <= 0x7f){u = n; f = 1;}
					if ((n >= 0xc0) && (n <= 0xdf)){u = n & 0x1f; f = 2;}
					if ((n >= 0xe0) && (n <= 0xef)){u = n & 0x0f; f = 3;}
					if ((n >= 0xf0) && (n <= 0xf7)){u = n & 0x07; f = 4;}
					if ((n >= 0x80) && (n <= 0xbf)){u = (u << 6) + (n & 0x3f); --f;}
					if (f <= 1){break;}
					if (str.charAt(i + 1) == "%"){ i++ ;}
					else {break;}
				}
				s0 += String.fromCharCode(u);
			}
		}
	}
	return s0;
} 
