var id = 0;
var gLatitude = "37.49300905665308"; //위도
var gLongitude = "127.01066493988037"; //경도
//37.49325592033368, 127.01053619384766

var map;
var searcher;
var currentPosition = null;

var	geocoder ;
var gAddress = "";//"서울시 강남구 역삼동 834-26";

function MAPAPI_LOAD(addr) {
	var script = document.createElement("script");
	script.src = "http://www.google.com/jsapi?key=ABQIAAAA1wKp7VJ2Ptq1bShzkQ4XRxRl9efwHBaE_81Cb07yiOqd_nIfWhRRLKMr-nc0Ry4-DMPJ7vpMDG5Khw&callback=fnLoadMaps&sensor=true";
	script.type = "text/javascript";
	script.charset = 'utf-8';
	document.getElementsByTagName("head")[0].appendChild(script);
	
	//gAddress = (document.getElementById("iGrouploc").value).trim();
	gAddress = addr;
	
	//구글맵 호출
	var tmp = setTimeout(function(){ //interval 함수 호출
		if(fileApplyFlag) fnGetCurrentPosition(); //단말에서 현위치정보가져오기
		else{
			fnAddress(); //주소검색 시작
		}
	}, 10000);
}
/*
function start()
{
	google.load("maps", "2", {"callback" : fnMapsLoaded});
}
*/

/**
 * google api 호출시 로딩1
 */
function fnLoadMaps(){
	google.load("maps", "2", {"callback" : fnMapsLoaded});
}

/**
 * google api 호출시 로딩2
 */
function fnMapsLoaded()
{
	map = new GMap2(document.getElementById("mapArea"));
	map.disableDoubleClickZoom();

}

/**
 * 현 위치정보 보여주기
 */
function fnSetCenter() {
	console.log('fnSetCenter');
	
	try{
		currentPosition = new GLatLng(gLatitude, gLongitude);
		geocoder = new GClientGeocoder();
		
		map.setCenter(currentPosition, 16);
		//map.setUIToDefault(); //지도컨트롤 넣기 
		
		var hearIcon = new GIcon();
		hearIcon.image = 'img/pin.png';
		hearIcon.iconAnchor = new GPoint(11, 45);
		
		var currentMarker = new GMarker(currentPosition, hearIcon);
		map.addOverlay(currentMarker);
		//alert("1==>"+currentPosition)
		
		
		GEvent.addListener(currentMarker, 'click', function() {
			geocoder.getLocations(currentPosition, function(response){
				
				fnPoiReset();
				/*
				var marker = new GMarker(currentPosition);
				//alert("2==>"+currentPosition);
				map.addOverlay(marker);
				var lhtml = "<div id=\"mapPopup2\"><table width=\"248\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
				lhtml += "<tr><td height=\"75\" valign=\"middle\">"+response.Placemark[0].address+"</td></tr>";
				lhtml += "<tr><td height=\"36\"><img src=\"img/btn_map_pop1.png\" onClick=\"document.getElementById('iGrouploc').value='"+response.Placemark[0].address+"';fnBack('ViewMap');\" /><img src=\"img/btn_map_pop2.png\" onClick=\"fnPoiReset();\" /></td></tr></table></div>";
				marker.openInfoWindowHtml(lhtml);
				*/
				fnSetCenter2(response.Placemark[0].address);
			});
		});
	/*
	
	*/	
		//구글서치
		//google.load("search", "1", {"callback" : fnSearchLoaded});
		
		/* 클릭이벤트 리스너 호출
		var tmp = setTimeout(function(){ //interval 함수 호출
			fnClickEvt();
		}, 1000);
		*/
		
	}
	catch(e){
		console.log("Error!="+e);
		document.getElementById("tmdiv").style.display="none";
		fnErrPop("구글맵에서 해당 주소를 로딩하지 못했습니다. 다시 시도해주세요.");
	}
}


/**
 * 현 위치정보 보여주기
 */
function fnSetCenter2(addrs) {
	console.log(addrs);
	
	try{
		var hearIcon = new GIcon();
		hearIcon.image = 'img/pin.png';
		hearIcon.iconAnchor = new GPoint(11, 45);
		
		var currentMarker = new GMarker(currentPosition,hearIcon);
		map.addOverlay(currentMarker);
		//alert("1==>"+currentPosition);
		var lhtml = "<div id=\"mapPopup2\"><table width=\"248\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
		lhtml += "<tr><td height=\"75\" valign=\"middle\">"+addrs+"</td></tr>";
		lhtml += "<tr><td height=\"36\"><img src=\"img/btn_map_pop1.png\" onClick=\"document.getElementById('iGrouploc').value='"+addrs+"';fnBack('ViewMap');\" /><img src=\"img/btn_map_pop2.png\" onClick=\"map.closeInfoWindow();\" /></td></tr></table></div>";
		//currentMarker.openInfoWindowHtml(lhtml,currentPosition);
		map.openInfoWindowHtml(currentPosition,lhtml);
		//map.openInfoWindowHtml(map.getCenter(),lhtml); 

		
		GEvent.addListener(currentMarker, 'click', function() {
			geocoder.getLocations(currentPosition, function(response){
				fnPoiReset();
				fnSetCenter2(response.Placemark[0].address);
			});
		});
	}
	catch(e){
		console.log("Error!="+e);
		document.getElementById("tmdiv").style.display="none";
		fnErrPop("구글맵에서 해당 주소를 로딩하지 못했습니다. 다시 시도해주세요.");
	}
}

/**
 * 구글서치 콜백함수
 */
function fnSearchLoaded()
{
	searcher = new google.search.LocalSearch();
	searcher.setCenterPoint(currentPosition);
	searcher.setResultSetSize(8);

	var bloodIcon = new GIcon();
	bloodIcon.image = 'http://gmaps-samples.googlecode.com/svn/trunk/markers/green/blank.png';
	bloodIcon.iconAnchor = new GPoint(31, 80);

	searcher.setSearchCompleteCallback(this, function() {
		alert('구글 서치 콜백함수');
		
		var results = searcher.results;

		function createMarker(point, index) {
			var marker = new GMarker(point, {icon: bloodIcon});
			marker.value = {title: result.title, phone: result.phoneNumbers[0].number, url: result.url};

			GEvent.addListener(marker, 'click', function() {
				alert(marker.value.title+"/"+marker.value.phone);
				//UDAPP.Gear.setText('.tellNmberLay .txt1', marker.value.title.replace('<b>', '').replace('</b>', ''));
				//UDAPP.Gear.setText('.tellNmberLay .txt2', '연락처 : <span>' + marker.value.phone + '</span>');
			});

			return marker;
		}

		for (var i = 0; i < results.length; i++) {
			var result = results[i];
			var markerLatLng = new GLatLng(parseFloat(result.lat), parseFloat(result.lng));

			map.addOverlay(createMarker(markerLatLng, i));
		}
		
	}, null);

	searcher.execute("삼성전자");

}

/**
 * poi 리셋버튼
 */
function fnPoiReset()
{
	map.clearOverlays();
}

/**
 * 줌인
 */
function fnZoomIn()
{
	if(map.isLoaded() == true) {
		map.zoomIn(currentPosition);
	}
	fnRestoreBtnImg();
}

/**
 * 줌아웃
 */
function fnZoomOut()
{
	if(map.isLoaded() == true) {
		map.zoomOut(currentPosition);
	}
	fnRestoreBtnImg();
}

/**
 * 단말에서 현위치정보 가져오기
 */
function fnGetCurrentPosition()
{
	getCurrentPosition();
}

/**
 * 주소검색
 */
function fnAddress()
{
	//console.log('gAddress='+gAddress);
	if(gAddress==""){
		fnSetCenter();
	}
	else{
		try{
			geocoder = new GClientGeocoder();
			geocoder.getLatLng(gAddress,
				function(point) {
					if (!point) {
						fnErrPop(gAddress + " 주소를 검색하지 못했습니다");
						console.log(gAddress+" not found.");
					} else {
						var hearIcon = new GIcon();
						hearIcon.image = 'img/pin.png';
						hearIcon.iconAnchor = new GPoint(11, 45);
		
						map.setCenter(point, 16);
						var marker = new GMarker(point,hearIcon);
						map.addOverlay(marker);
						var lhtml = "<div id=\"mapPopup2\"><table width=\"248\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
						lhtml += "<tr><td height=\"75\" valign=\"middle\">"+gAddress+"</td></tr>";
						lhtml += "<tr><td height=\"36\"><img src=\"img/btn_map_pop3.png\" onClick=\"fnMain0(ggGroupseq);\"/><img src=\"img/btn_map_pop2.png\" onClick=\"map.closeInfoWindow();\" /></td></tr></table></div>";
						//marker.openInfoWindowHtml(lhtml);
						map.openInfoWindowHtml(point,lhtml);
						//console.log(gAddress);
					}
				}
			);
		}
		catch(e){
			console.log("Error!="+e);
			document.getElementById("tmdiv").style.display="none";
			fnErrPop("구글맵에서 해당 주소를 로딩하지 못했습니다. 다시 시도해주세요.");
		}

	}
	
	document.getElementById("tmdiv").style.display="none"; //로딩창 비활성화

}
var clickflag = true;
var gListener;
/**
 * 직접선택 이벤트
 */
function fnClickEvt()
{
	if(clickflag){
		gListener = GEvent.addListener(map, "click", function(overlay, point) {
			if (point) {
				fnPoiReset();
				//좌표값으로 지역값으로 변환 getLocations
				geocoder.getLocations(point, function(response){
					left_btn = point;
					place = response.Placemark[0];
					
					var hearIcon = new GIcon();
					hearIcon.image = 'img/pin.png';
					hearIcon.iconAnchor = new GPoint(11, 45);
					
					//아이콘 마크업
					var lmarker = new GMarker(point, hearIcon);
					map.addOverlay(lmarker);
					//lmarker.setImage("http://maps.google.com/mapfiles/ms/icons/red-pushpin.png");
					//lmarker.openInfoWindowHtml("좌표 : " + point + "<br/>"+ "지역 : " + place.address);
					var lhtml = "<div id=\"mapPopup2\"><table width=\"248\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\">";
					lhtml += "<tr><td height=\"75\" valign=\"middle\">"+place.address+"</td></tr>";
					lhtml += "<tr><td height=\"36\"><img src=\"img/btn_map_pop1.png\" onClick=\"document.getElementById('iGrouploc').value='"+place.address+"';fnBack('ViewMap');\" /><img src=\"img/btn_map_pop2.png\" onClick=\"map.closeInfoWindow();\" /></td></tr></table></div>";
					//lmarker.openInfoWindowHtml(lhtml);
					map.openInfoWindowHtml(point,lhtml);
					
					var center = point.y + ", " + point.x;
					console.log("center="+center);
					//console.log("place.address ="+place.address);
					
					//document.getElementById("start").innerHTML = center.toString(); //좌표
					
					/*
					GEvent.addListener(lmarker, "mouseover", function(){
						//var myHtml = "좌표" +"[" + point.lat().toFixed(6) + ", " + point.lng().toFixed(6) + "] <br/>" + "지역" + "[" + place.address + "]";
						var myHtml = "주소" + "[" + place.address + "] <br/><input type=button value='닫 기' onClick='fnPoiReset();'/> ";
						map.openInfoWindow(point, myHtml);
					});
					*/
					//GPolyline을 이용하여 오른쪽클릭과 왼쪽 클릭 마크업된곳 선으로 연결
					//var polyOptions = {geodesic:true};
					//var polyline = new GPolyline([left_btn, ringt_btn], "#ff0000", 5, 1, polyOptions);
					//map.addOverlay(polyline);
				});
			}
		});
		$("#ViewMap #mapBottomMenu img").eq(2).attr("src","img/map_btn3_on.jpg");
		clickflag = false;
	}
	else{
		//fnPoiReset();
		GEvent.removeListener(gListener);
		$("#ViewMap #mapBottomMenu img").eq(2).attr("src","img/map_btn3.jpg");
		clickflag = true;
	}

}









/************************************************************************************/

function errorCallback(response) {
	//alert("errorCallback called");
	console.log("response.code="+response.code);
	document.getElementById("tmdiv").style.display="none";
	fnErrPop("["+response.code+"]단말에서 현재좌표를 가져오지 못했습니다. 다시 시도해주세요.");
}

function getCurrentPosition(){
	//alert("getCurrentPosion called");
	try{
		navigator.geolocation.getCurrentPosition(successCallback,errorCallback, {timeout:10000, enableHighAccuracy:true});		
	}
	catch(e){
		console.log(e);
		fnAddress();
	}
}

function getCurrentPosition_navigation(){
	 try{
	 	navigator.geolocation.getCurrentPosition(successCallback, errorCallback, {timeout:5000, enableHighAccuracy:true});
	 }
	 catch(e){
	 	console.log(e);
	 }
}

function watchPosition(){
	//alert("watchPosition called");
	try{
		id = navigator.geolocation.watchPosition(successCallback, errorCallback, {timeout:5000, enableHighAccuracy:true} ) ;	
	}
	catch(e){
		console.log(e);
	}
	
}
function clearWatch(){
	try{
		navigator.geolocation.clearWatch(id);
	}
	catch(e){
		console.log(e);
	}
}

function watchPosition_navigation(){
	//alert("watchPosition called");
	try{
		id = navigator.geolocation.watchPosition(successCallback, errorCallback, {timeout:5000, enableHighAccuracy:true} ) ;
	}
	catch(e){
		console.log(e);
	}
}
function clearWatch_navigation(){
	try{
		navigator.geolocation.clearWatch(id);	
	}
	catch(e){
		console.log(e);
	}
}

function successCallback(response) {
	gLatitude = response.coords.latitude;
	gLongitude = response.coords.longitude;
	console.log("gPoint:::"+gLatitude+","+gLongitude);
	
	fnAddress(); //주소검색 시작

	/*
	document.getElementById('text1').innerHTML += "latitude:"+response.coords.latitude+"</br>";
	document.getElementById('text1').innerHTML+= "longitude:"+response.coords.longitude+"</br>";
	document.getElementById('text1').innerHTML += "altitude:"+response.coords.altitude+"</br>";
	document.getElementById('text1').innerHTML += "accuracy:"+response.coords.accuracy+"</br>";
	document.getElementById('text1').innerHTML += "altitudeAccuracy:"+response.coords.altitudeAccuracy+"</br>";
	document.getElementById('text1').innerHTML += "heading:"+response.coords.heading+"</br>";
	document.getElementById('text1').innerHTML += "speed:"+response.coords.speed+"</br>";
	document.getElementById('text1').innerHTML+= "timestamp:"+response.timestamp+"</br>";
	*/
}