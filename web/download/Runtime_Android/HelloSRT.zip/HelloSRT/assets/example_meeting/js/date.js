/*요일에 따른 매핑 */ 
var dayofweek = {
	"1": new Object("Mon"),
	"2": new Object("Tue"),
	"3": new Object("Wed"),
	"4": new Object("Thr"),
	"5": new Object("Fri"),
	"6": new Object("Sat"),
	"0": new Object("Sun")
}

var d = new Date(); //현재날짜객체
//console.log('현재 년: ' + d.getFullYear());
//console.log('현재 월: ' + (d.getMonth() + 1) );
//console.log('현재 일: ' + d.getDate() );
//console.log('현재 시: ' + d.getHours() );
//console.log('현재 분: ' + d.getMinutes() );
//console.log('현재 초: ' + d.getSeconds() );
//console.log('오늘 요일: ' + d.getDay() ); // 일요일 = 0
var syear = d.getFullYear();
var smonth = fnPutZeroStr(d.getMonth()+1);
var sday = fnPutZeroStr(d.getDate());
var sdaynm = dayofweek[d.getDay()];
var stoday = syear+"."+smonth+"."+sday;

var dd = new Date(); //바뀔 날짜객체
var gyear = dd.getFullYear();
var gmonth = fnPutZeroStr(dd.getMonth()+1);
var gday = fnPutZeroStr(dd.getDate());

var startWeek;
var endDay;
var countDay;
var prevYear;
var prevMonth;
var nextYear;
var nextMonth;

function fnDispCalendar(startYear, startMonth) {
	var calendarArr = ["","","","","","","","","","","","","","","","","","","","","","","","","","","","","","","",""];
	startWeek		= 0;	// 월의	시작 요일
	endDay			= 0;	// 월의	날짜
	countDay		= 0;	// 날짜	카운트
	prevYear		= 0;	// 이전	년도 
	prevMonth		= 0;	// 이전	월	 
	nextYear		= 0;	// 다음	년도 
	nextMonth		= 0;	// 다음	월	 

	// 현재	월이 12월일	경우
	if (startMonth >= 12) {
		endDay	= 31;
		prevYear = startYear;	   
		prevMonth  = startMonth	- 1;   
		nextYear = startYear + 1;  
		nextMonth  = 1;			   
	}
	else {
		var	month_days = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		
		// 윤년	체크
		if (startYear%4	== 0 ||	startYear%100 == 0)	{
			month_days[1] =	29;
		}
		else{
			month_days[1] =	28;
		}
		
		endDay	= month_days[startMonth-1];	// 마지막 날짜
		
		// 현재	월이 1월인 경우
		if (startMonth == 1) {
			prevYear	= startYear	- 1;	// 이전	년도
			prevMonth	= 12;				// 이전	월
		}
		else {
			prevYear	= startYear;		// 이전	년도
			prevMonth	= startMonth - 1;	// 이전	월
		}
		nextYear		= startYear;		// 다음	년도
		nextMonth		= startMonth + 1;	// 다음	월
	}

	// Date	객체를 생성하여	주어진 년/월을 할당
	var	nowDate	= new Date();
	nowDate.setYear(startYear);
	nowDate.setMonth(startMonth-1);
	nowDate.setDate(1);
	startWeek =	nowDate.getDay()+1;	
	if (startWeek == 0)	{
		startWeek =	7;
	}

	
	var	dateStr	= "";
	var	lineCount =	0;
	
	var mensCnt = 0;
	var ldate = "";

	// 날짜를 계산하여 요일별로 표시
	for	(var i=1; i<=6;	i++) {
		lineCount += 1;
		for	(var j=1; j<=7;	j++) {
			if (i==1 &&	j<startWeek) {
				dateStr	+= "<li>&nbsp;</li>\n"; //빈칸출력용
			}
			else {
				countDay +=	1;
				//ldate = startYear+"-"+fnPutZeroStr(startMonth)+"-"+fnPutZeroStr(countDay);
				ldate = startYear+fnPutZeroStr(startMonth)+fnPutZeroStr(countDay);
				if (countDay > endDay) {
					dateStr	+= "<li>&nbsp;</li>\n"; //빈칸출력용
				}
				else {
					var todaySpan = "";
					//console.log(ldate+"::::"+syear+"-"+fnPutZeroStr(smonth)+"-"+fnPutZeroStr(sday));
					if(ldate == syear+fnPutZeroStr(smonth)+fnPutZeroStr(sday)) {
						/*오늘체크*/
						console.log("today is "+ldate);
						todaySpan = "class='today'";
						//dateStr += "<li><span class=\"today\">"+countDay+"</span></li>";
					}
					var vCnt = 0;
					var vTmp;
					var vHtml = "";
					var vClass = "";
					if(gGubun=="I"){ //관심물품
						for(var k=0; k<fileListArr.length; k++){
							vTmp = fileListArr[k].split("_");
							//console.log(vTmp[0]+"/"+vTmp[1]+"/"+ldate);
							if(vTmp[0]==gGubun && vTmp[1]==ldate) vCnt++; 
						}
						if(vCnt>0) vHtml = "<br/><span class=\"num\" onClick=\"fnItemList('I','"+ldate+"');\" >"+vCnt+"</span>";
						vClass = "cart";
					}
					else if (gGubun=="B"){ //구매물품
						for(var k=0; k<fileListArr.length; k++){
							vTmp = fileListArr[k].split("_");
							if(vTmp[0]==gGubun && vTmp[1]==ldate) vCnt++; 
						}
						if(vCnt>0) vHtml = "<br/><span class=\"num\" onClick=\"fnItemList('B','"+ldate+"');\" >"+vCnt+"</span>";
						vClass = "bag";
					}

					
					if (j==1) {
						if(vHtml!="") dateStr += "<li class='sun "+vClass+"'><span onClick=\"fnCreate('"+fnPutZeroStr(countDay)+"')\">"+countDay+"</span>"+vHtml+"</li>";
						else dateStr += "<li class='sun'><span onClick=\"fnCreate('"+fnPutZeroStr(countDay)+"')\">"+countDay+"</span></li>";
					}
					else if	(j==7) {
						if(vHtml!="") dateStr += "<li class='sat "+vClass+"'><span onClick=\"fnCreate('"+fnPutZeroStr(countDay)+"')\">"+countDay+"</span>"+vHtml+"</li>";
						else dateStr += "<li class=\"sat\"><span onClick=\"fnCreate('"+fnPutZeroStr(countDay)+"')\">"+countDay+"</span></li>";
					}
					else {
						if(vHtml!="") dateStr += "<li class='"+vClass+"'><span onClick=\"fnCreate('"+fnPutZeroStr(countDay)+"')\">"+countDay+"</span>"+vHtml+"</li>";
						else dateStr += "<li><span onClick=\"fnCreate('"+fnPutZeroStr(countDay)+"')\">"+countDay+"</span></li>";
					}
					
					
				}
			}
		}
		if (countDay >=	endDay)	{
			break;
		}
	}
	//console.log(dateStr);
	return dateStr;
}

/* 백업용도
function displayCalendar(startYear,	startMonth)	{
	startWeek		= 0;	// 월의	시작 요일
	endDay			= 0;	// 월의	날짜
	countDay		= 0;	// 날짜	카운트
	prevYear		= 0;	// 이전	년도 
	prevMonth		= 0;	// 이전	월	 
	nextYear		= 0;	// 다음	년도 
	nextMonth		= 0;	// 다음	월	 

	// 현재	월이 12월일	경우
	if (startMonth >= 12) {
		endDay	= 31;
		prevYear = startYear;	   
		prevMonth  = startMonth	- 1;   
		nextYear = startYear + 1;  
		nextMonth  = 1;			   
	}
	else {
		var	month_days = new Array(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);
		
		// 윤년	체크
		if (startYear%4	== 0 ||	startYear%100 == 0)	{
			month_days[1] =	29;
		}
		else{
			month_days[1] =	28;
		}
		
		endDay	= month_days[startMonth-1];	// 마지막 날짜
		
		// 현재	월이 1월인 경우
		if (startMonth == 1) {
			prevYear	= startYear	- 1;	// 이전	년도
			prevMonth	= 12;				// 이전	월
		}
		else {
			prevYear	= startYear;		// 이전	년도
			prevMonth	= startMonth - 1;	// 이전	월
		}
		nextYear		= startYear;		// 다음	년도
		nextMonth		= startMonth + 1;	// 다음	월
	}

	// Date	객체를 생성하여	주어진 년/월을 할당
	var	nowDate	= new Date();
	nowDate.setYear(startYear);
	nowDate.setMonth(startMonth-1);
	nowDate.setDate(1);
	startWeek =	nowDate.getDay()+1;	
	if (startWeek == 0)	{
		startWeek =	7;
	}

	var	dateStr	= "<table border=0 cellspacing=0 cellpadding=0 width=100%>\n";

	var	lineCount =	0;
	// 날짜를 계산하여 요일별로	표시
	for	(var i=1; i<=6;	i++) {
		lineCount += 1;
		dateStr	+= "<tr>\n";
		for	(var j=1; j<=7;	j++) {
			if (i==1 &&	j<startWeek) {
				dateStr	+= "<td>&nbsp;</td>\n";
			}
			else {
				countDay +=	1;
				if (countDay > endDay) {
					dateStr	+= "<td>&nbsp;</td>\n";
				}
				else {
					var	a_class	 = "";

					if (a_class	== "") {
						if (j==1) {
							a_class	= "red";
						}
						else if	(j==7) {
							a_class	= "blue";
						}
						else {
							a_class	= "black";
						}
					}
					
					dateStr	+= "<td><font	color="+a_class+">"+countDay+"</font></td>\n";
				}
			}
		}
		dateStr	+= "</tr>\n";
		if (countDay >=	endDay)	{
			break;
		}
	}
	dateStr	+= "</table>\n";
}

*/



/* ----------------------------------------------------------------------------
 * 특정 날짜에 대해 지정한 값만큼 가감(+-)한 날짜를 반환, 데이트객체로 반환하게 변경
 *
 * ----입력 파라미터 -----
 * pInterval : "yyyy" 는 연도 가감, "m" 은 월 가감, "d" 는 일 가감
 * pAddVal  : 가감 하고자 하는 값 (정수형)
 * pYyyymmdd : 가감의 기준이 되는 날짜
 * pDelimiter : pYyyymmdd 값에 사용된 구분자를 설정 (없으면 "" 입력)
 * 
 * ----반환값 ----
 * yyyymmdd 또는 함수 입력시 지정된 구분자를 가지는 yyyy?mm?dd 값
 * 
 * ----사용예 ---
 * 2008-01-01 에 3 일 더하기 ==> addDate("d", 3, "2008-08-01", "-");
 * 20080301 에 8 개월 더하기 ==> addDate("m", 8, "20080301", "");
 --------------------------------------------------------------------------- */
function addDate(pInterval, pAddVal, pYyyymmdd, pDelimiter)
{
	var yyyy;
	var mm;
	var dd;
	var cDate;
	var oDate;
	var cYear, cMonth, cDay;
	
	if (pDelimiter != "") {
		pYyyymmdd = pYyyymmdd.replace(eval("/\\" + pDelimiter + "/g"), "");
	}
	
	yyyy = pYyyymmdd.substr(0, 4);
	mm  = pYyyymmdd.substr(4, 2);
	dd  = pYyyymmdd.substr(6, 2);
	
	if (pInterval == "yyyy") {
		yyyy = (yyyy * 1) + (pAddVal * 1);
	} else if (pInterval == "m") {
		mm  = (mm * 1) + (pAddVal * 1);
	} else if (pInterval == "d") {
		dd  = (dd * 1) + (pAddVal * 1);
	}
	
	cDate = new Date(yyyy, mm - 1, dd) // 12월, 31일을 초과하는 입력값에 대해 자동으로 계산된 날짜가 만들어짐.
	cYear = cDate.getFullYear();
	cMonth = cDate.getMonth() + 1;
	cDay = cDate.getDate();
	
	cMonth = cMonth < 10 ? "0" + cMonth : cMonth;
	cDay = cDay < 10 ? "0" + cDay : cDay;
	
	if (pDelimiter != "") {
		return cYear + pDelimiter + cMonth + pDelimiter + cDay;
	} else {
		//return cYear + cMonth + cDay;
		return new Date(cYear, cMonth - 1, cDay);
	}
}




/**
 * 한자리숫자일경우 "0"을 붙여서 리턴. ex) 1->01, 10->10
 * @param {Object} val
 */
function fnPutZeroStr(val){
	var ttt = val+"";
	//alert(ttt.length);
	if( Number(val) < 10 && ttt.length==1 ) return "0"+ttt;
	else return ttt;
}

