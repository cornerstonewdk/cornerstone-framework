document.addEventListener("deviceready", onDeviceReady, false);

function onDeviceReady(){
	asyncTest( "Accelerometer-getCurrentAcceleration", function() {
		
		onAccelerationSuccess = function (acceleration)
        {
            if( isNaN(acceleration.x) 
            		|| isNaN(acceleration.y) 
            		|| isNaN(acceleration.z) )
            {
            	ok(false,"getCurrentAcceleration() failed.");
            	start();
            }				
            else {
          	   ok(true, "getCurrentAcceleration pass!" + "[x: "+acceleration.x+", y: "+acceleration.y+", z: "+acceleration.z+"]");
          	   start();
			}
        }
		
		navigator.accelerometer.getCurrentAcceleration(onAccelerationSuccess,expectedError);

	});
	
	
	test( "hello test", function() {
	  ok( 2 == "2", "Passed!" );
	});
	
	/*
	module("Module A");
	 
	test("first test within module", function() {
	ok( true, "all pass" );
	});
	 
	test("second test within module", function() {
	ok( true, "all pass" );
	});
	
	module("Module B");
	 
	test("some other test", function() {
	expect(2);
	equal( true, true, "failing test" );
	equal( true, true, "passing test" );
	});
	*/
}
