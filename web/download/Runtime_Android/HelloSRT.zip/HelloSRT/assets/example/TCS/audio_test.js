document.addEventListener("deviceready", onDeviceReady_AD, false);

var invalidSC_AD = "successCallback";
var invalidarg_AD = {filepath:"file:///android_asset/example/TCS/audio.mp3"};

var gAudio;
var gAudioPath = "file:///android_asset/example/TCS/audio.mp3";

function validSuccessCalback_AD(response) {
	ok(true,"SuccessCallback이 성공적으로 호출됨");
	start();
}

function validCreateAudioSuccessCallback_AD(audio){
	gAudio = audio;
	ok(true,"SuccessCallback이 성공적으로 호출됨");
	ok(true, gAudio.src + " 가 성공적으로 생성됨")
	start();
}

function invalidSuccessCalback_AD(reponse) {
	ok(false,"SuccessCallback이 호출되어선 안됨");
	start();
}

function invalidErrorCallback_AD(response){
	ok(false,"errorCallback이 아닌 exception이 발생하여야 함");
	start();
}

function validErrorCallback_AD(response){
	ok(false,"다음 error: " +  response.message + ", 발생");
	start();
}

function onDeviceReady_AD(){

	module("Audio");

	//test 1
	asyncTest("createAudio-모든 매개변수가 올바른 경우", function() {
		navigator.mediamanager.createAudio(validCreateAudioSuccessCallback_AD,validErrorCallback_AD,gAudioPath);
	});

	//test 2
	asyncTest("createAudio-SuccessCallback 이 null인 경우", function() {		
		 try{
			 navigator.mediamanager.createAudio(null, invalidErrorCallback_AD,gAudioPath);			 
		 }
		 catch(e){
			 ok(true,e);
			 start();
		 }
	});
	
	//test 3
	asyncTest("createAudio-SuccessCallback 이 funtion이 아닌경우", function() {
		 try{
			 navigator.mediamanager.createAudio(invalidSC_AD, invalidErrorCallback_AD,gAudioPath);			 
		 }
		 catch(e){
			 ok(true,e);
			 start();
		 }
	});
	
	//test 4
	asyncTest("createAudio-filePath 가 String 이 아닌경우", function() {
		 try{
			 navigator.mediamanager.createAudio(invalidSuccessCalback_AD, invalidErrorCallback_AD,invalidarg_AD);			 
		 }
		 catch(e){
			 ok(true,e);
			 start();
		 }
	});
	
	//test 5
	asyncTest("play-모든 매개변수가 올바른 경우", function() {

		gAudio.play();

		if(confirm("Audio가 정상적으로 play됨을 확인 하셨습니까?")){
			ok(true,"정상적으로 audio가 play됨")
			start();
		}
		else{
			ok(false,"정상적으로 audio가 play되지 않음")
			start();			
		}
	});

	//test 6
	asyncTest("pause-3초뒤에 현재 play중인 audio가 pause됨", function() {
		setTimeout(function(){
			console.log("test");
			gAudio.pause();
			
			if(confirm("Audio가 정상적으로 pause됨을 확인 하셨습니까?")){
				ok(true,"정상적으로 audio가 pause됨")
				start();
			}
			else{
				ok(false,"정상적으로 audio가 pause되지 않음")
				start();
			}
		},3000)
	});
	
	
	//test 7
	asyncTest("stop-3초뒤에 현재 play중인 audio가 stop됨", function() {
		gAudio.play();
		
		setTimeout(function(){
			gAudio.stop();	
			if(confirm("Audio가 정상적으로 stop됨을 확인 하셨습니까?")){
				ok(true,"정상적으로 audio가stop됨");
				start();
			}
			else{
				ok(false,"정상적으로 audio가 stop되지 않음");
				start();
			}
		},3000)	
	});
	
	
	//test 8
	asyncTest("getDuration-모든 매개변수가 올바른 경우", function() {
		var duration = gAudio.getDuration();		
		notEqual(-1,duration,"daration(s) = " + duration);
		start();
	});
	
	
	//test 9
	asyncTest("seekTo-사용자가 입력한 m/s로 audio를 이동", function() {
		gAudio.play();
		
		var position= prompt("seekTo api를 테스트 합니다.\n이동할 위치를 입력해 주세요.\n" + "(0 ~ " + gAudio.getDuration() + " m/s)" );
		
		gAudio.seekTo(position*1000);
		
		if(confirm("Audio가 정상적으로 이동됨을 확인 하셨습니까?")){
			ok(true,"seekTo api가 정상적으로 동작함");
			start();
		}
		else{
			ok(false,"seekTo api가 정상적으로 동작하지 않음");
			start();
		}
	});
	
	//test 10
	asyncTest("setVolume-모든 매개변수가 올바른 경우", function() {
		gAudio.setVolume(10);		
		ok(true,"setVolume(10%)가 정상적으로 동작함");
		
		setTimeout(function(){
			gAudio.setVolume(100);
			ok(true,"setVolume(100%)가 정상적으로 동작함");
			start();
		},5000);
	});
	
	//test 11
	asyncTest("getCurrentPosition-모든 매개변수가 올바른 경우", function() {
		gAudio.getCurrentPosition(
	            function(position) {
	                if (position > -1) {
	                	ok(true,"현재 재생되고 있는 위치::" + position);
	                	start();
	                }
	            },validErrorCallback_AD);
	});
	
	//test 12
	asyncTest("release-모든 매개변수가 올바른 경우", function() {
		setTimeout(function() {
			gAudio.release();
			gAudio = null;
			ok(true,"정상적으로 audio object를 release함");
	    	start();
	    }, 5000);
	});
}
