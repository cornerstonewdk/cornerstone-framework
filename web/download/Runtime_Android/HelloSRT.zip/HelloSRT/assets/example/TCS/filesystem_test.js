document.addEventListener("deviceready", onDeviceReady_FS, false);

var gTestUrl = null;

var invalidSC_FS = "successCallback";
var invalidarg_FS = {};

function invalidErrorCallback_FS(response){
	ok(false,"errorCallback이 아닌 exception이 발생하여야 함");
	start();
}

function validErrorCallback_FS(response){
	ok(false,"다음 error: " +  response.message + ", 발생");
	start();
}

function onDeviceReady_FS(){
	
	module("FileSystem");
	
	//precondition 1
	asyncTest("FileSystem TCS precondition", function() {
		function onFileSystemSuccess(rootDir) {
			ok(true,"rootDir.name::"+rootDir.name);
			ok(true,"rootDir.root.name::"+rootDir.root.name);
			
			function dirmakesuccess(direntry) {
				ok(true,"direntry Name: " + direntry.name);
				ok(true,"direntry fullpath: " + direntry.fullPath);
				
				gTestUrl = direntry.fullPath
				
				function filemakesuccess(fileentry) {
					ok(true,"fileentry Name: " + fileentry.name);
				}
				
				function subdirmakesuccess(direntry){
					ok(true,"subdirentry Name: " + direntry.name);
					direntry.getFile("subdirFile.txt", {create: true, exclusive: false}, filemakesuccess, validErrorCallback_FS);
				}
				
				function finalsuccess(fileentry){
					ok(true,"fileentry Name: " + fileentry.name);
					start();
				}
				
				direntry.getDirectory("moveDirTest", {create: true, exclusive: false}, subdirmakesuccess, validErrorCallback_FS);
				direntry.getDirectory("copyDirTest", {create: true, exclusive: false}, subdirmakesuccess, validErrorCallback_FS);
				
				direntry.getFile("writeTestFile.txt", {create: true, exclusive: false}, filemakesuccess, validErrorCallback_FS);
				direntry.getFile("moveTestFile.txt", {create: true, exclusive: false}, filemakesuccess, validErrorCallback_FS);
				direntry.getFile("copyTestFile.txt", {create: true, exclusive: false}, filemakesuccess, validErrorCallback_FS);
				direntry.getFile("deleteTestFile.txt", {create: true, exclusive: false}, finalsuccess, validErrorCallback_FS);
				
			}

			// Retrieve an existing directory, or create it if it does not already exist
			rootDir.root.getDirectory("srtfiletest", {create: true, exclusive: false}, dirmakesuccess, validErrorCallback_FS);
			
		}
		
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0,	onFileSystemSuccess, validErrorCallback_FS);
	});
	
	//test 1
	asyncTest("requestFileSystem-PERSISTENT", function() {
		function onFileSystemSuccess(fileSystem) {
			ok(true,"fileSystem.name::"+fileSystem.name);
			ok(true,"fileSystem.root.name::"+fileSystem.root.name);
			start();
		}
		
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0,	onFileSystemSuccess, validErrorCallback_FS);
	});
	
	//test 2
	asyncTest("requestFileSystem-PERSISTENT", function() {
		function onFileSystemSuccess(fileSystem) {
			ok(true,"fileSystem.name::"+fileSystem.name);
			ok(true,"fileSystem.root.name::"+fileSystem.root.name);

			start();
		}	
		window.requestFileSystem(LocalFileSystem.TEMPORARY, 1024 * 1024, onFileSystemSuccess, validErrorCallback_FS);
	});
	
	//test 3
	asyncTest("resolveLocalFileSystemURI-모든 매개변수가 올바른 경우", function() {
		function onResolveSuccess(fileEntry) {
			ok(true,"fileEntry.name::"+fileEntry.name);
			ok(true,"fileEntry.fullPath::"+ fileEntry.fullPath);

			start();
		}
		
		window.resolveLocalFileSystemURI(gTestUrl+"/writeTestFile.txt",onResolveSuccess, validErrorCallback_FS);
	});
	
	//test 4
	asyncTest("getMetadata-모든 매개변수가 올바른 경우", function() {
		function success(metadata) {
			ok(true,"Last Modified: " + metadata.modificationTime);
			ok(true,"Size: " + metadata.size);
			
			start();
		}	
		
		function onResolveSuccess(fileSystem) {
			ok(true,"fileSystem.name::"+fileSystem.name);
			ok(true,"fileSystem.root.name::"+fileSystem.root.name);

			 // Request the metadata object for this entry
	        fileSystem.root.getMetadata(success, validErrorCallback_FS);
		}	
		
		window.requestFileSystem(LocalFileSystem.PERSISTENT, 0, onResolveSuccess, validErrorCallback_FS);
	});
	
	//test 5
	asyncTest("moveTo-file 이동", function() {
		function onResolveSuccess(fileEntry) {
			ok(true,"fileEntry.name::"+fileEntry.name);
			ok(true,"fileEntry.fullPath::"+ fileEntry.fullPath);
			
			function success(entry) {
				ok(true,"move success,New Path: " + entry.fullPath);
				start();
			}

			var parentEntry = new DirectoryEntry("srtfiletest",gTestUrl);
			
			fileEntry.moveTo(parentEntry,"movedfile.txt",success,validErrorCallback_FS);
		}
		
		window.resolveLocalFileSystemURI(gTestUrl + "/moveTestFile.txt",onResolveSuccess, validErrorCallback_FS);
	});
	
	//test 6
	asyncTest("moveTo-dir 이동", function() {
		function onResolveSuccess(dirEntry) {
			ok(true,"dirEntry.name::"+dirEntry.name);
			ok(true,"dirEntry.fullPath::"+ dirEntry.fullPath);
			
			function success(entry) {
				ok(true,"move success, New Path: " + entry.fullPath);
				start();
			}

			var parentEntry = new DirectoryEntry("srtfiletest",gTestUrl);
			
			dirEntry.moveTo(parentEntry,"movedDir",success,validErrorCallback_FS);
		}
		
		window.resolveLocalFileSystemURI(gTestUrl + "/moveDirTest",onResolveSuccess, validErrorCallback_FS);
	});
	
	//test 7
	asyncTest("copyTo-file 복사", function() {
		function onResolveSuccess(fileEntry) {
			ok(true,"fileEntry.name::"+fileEntry.name);
			ok(true,"fileEntry.fullPath::"+ fileEntry.fullPath);
			
			function success(entry) {
				ok(true,"copy success,New Path: " + entry.fullPath);
				start();
			}

			var parentEntry = new DirectoryEntry("srtfiletest",gTestUrl);
			
			fileEntry.copyTo(parentEntry,"copiedfile.txt",success,validErrorCallback_FS);
		}
		
		window.resolveLocalFileSystemURI(gTestUrl + "/copyTestFile.txt",onResolveSuccess, validErrorCallback_FS);
	});
	
	//test 8
	asyncTest("copyTo-dir 복사", function() {
		function onResolveSuccess(dirEntry) {
			ok(true,"dirEntry.name::"+dirEntry.name);
			ok(true,"dirEntry.fullPath::"+ dirEntry.fullPath);
			
			function success(entry) {
				ok(true,"copy success, New Path: " + entry.fullPath);
				start();
			}

			var parentEntry = new DirectoryEntry("srtfiletest",gTestUrl);
			
			dirEntry.copyTo(parentEntry,"copiedDir",success,validErrorCallback_FS);
		}
		
		window.resolveLocalFileSystemURI(gTestUrl + "/copyDirTest",onResolveSuccess, validErrorCallback_FS);
	});
}
