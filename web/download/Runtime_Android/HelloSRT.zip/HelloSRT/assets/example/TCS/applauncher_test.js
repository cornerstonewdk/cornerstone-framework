document.addEventListener("deviceready", onDeviceReady_AL, false);

var invalidSC_AL = "successCallback";
var invalidarg_AL = {};

var gApps = {};
var gAppNum;

function validSuccessCalback_AL(response) {
	
	ok(true, response.length + " app is installed");
	
	for(var i = 0 ; i < response.length ; i ++){
		ok(true, response[i] + " is installed");
	}
	
	ok(true,"SuccessCallback이 성공적으로 호출됨");
	
	gApps = response;
	
	start();
}

function validLaunchSuccessCallback_AL(){
	ok(true, gApps[gAppNum] + "이 정상적으로 호출됨");
	ok(true,"SuccessCallback이 성공적으로 호출됨");
	start();
}

function invalidSuccessCalback_AL(reponse) {
	ok(false,"SuccessCallback이 호출되어선 안됨");
	start();
}

function invalidErrorCallback_AL(response){
	ok(false,"errorCallback이 아닌 exception이 발생하여야 함");
	start();
}

function validErrorCallback_AL(response){
	ok(false,"다음 error: " +  response.message + ", 발생");
	start();
}

function onDeviceReady_AL(){

	module("AppLauncher");

	//test 1
	asyncTest("getInstalledApplications-모든 매개변수가 올바른 경우", function() {
		navigator.applauncher.getInstalledApplications(validSuccessCalback_AL, validErrorCallback_AL);
	});

	//test 2
	asyncTest("getInstalledApplications-SuccessCallback 이 null인 경우", function() {		
		 try{
			 navigator.applauncher.getInstalledApplications(null, invalidErrorCallback_AL);			 
		 }
		 catch(e){
			 ok(true,e);
			 start();
		 }
	});
	
	//test 3
	asyncTest("getInstalledApplications-SuccessCallback 이 funtion이 아닌경우", function() {
		 try{
			 navigator.applauncher.getInstalledApplications(invalidSC_AL, invalidErrorCallback_AL);			 
		 }
		 catch(e){
			 ok(true,e);
			 start();
		 }
	});
	
	//test 4
	asyncTest("launchApplication-모든 매개변수가 올바른 경우", function() {
		gAppNum = prompt("launchApplication api를 테스트 합니다.\n실행 시킬 App의 번호를 입력하세요.\n" + "(0 ~ " + gApps.length + ")" );
		navigator.applauncher.launchApplication(validLaunchSuccessCallback_AL,validErrorCallback_AL, gApps[gAppNum]);	
	});
	
	//test 5
	asyncTest("launchApplication-SuccessCallback 이 null인 경우", function() {		
		 try{
			 navigator.applauncher.launchApplication(null, invalidErrorCallback_AL,gApps[gAppNum]);			 
		 }
		 catch(e){
			 ok(true,e);
			 start();
		 }
	});
	
	//test 6
	asyncTest("getInstalledApplications-SuccessCallback 이 function이 아닌경우", function() {
		 try{
			 navigator.applauncher.launchApplication(invalidSC_AL, invalidErrorCallback_AL,gApps[gAppNum]);			 
		 }
		 catch(e){
			 ok(true,e);
			 start();
		 }
	});

	//test 6
	asyncTest("getInstalledApplications-app url이 String이 아닌경우", function() {
		 try{
			 navigator.applauncher.launchApplication(invalidSuccessCalback_AL, invalidErrorCallback_AL,invalidarg_AL);			 
		 }
		 catch(e){
			 ok(true,e);
			 start();
		 }
	});
}
