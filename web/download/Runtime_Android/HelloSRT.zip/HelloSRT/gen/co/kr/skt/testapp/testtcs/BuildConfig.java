/** Automatically generated file. DO NOT MODIFY */
package co.kr.skt.testapp.testtcs;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}