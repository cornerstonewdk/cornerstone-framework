/** Automatically generated file. DO NOT MODIFY */
package co.kr.skt.testapp.minutes;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}