// commit ac0a3990438f4a89faa993316fb5614f61cf3be6

// File generated at :: Tue Jun 05 2012 14:14:16 GMT-0700 (PDT)

/*
 Licensed to the Apache Software Foundation (ASF) under one
 or more contributor license agreements.  See the NOTICE file
 distributed with this work for additional information
 regarding copyright ownership.  The ASF licenses this file
 to you under the Apache License, Version 2.0 (the
 "License"); you may not use this file except in compliance
 with the License.  You may obtain a copy of the License at
 
     http://www.apache.org/licenses/LICENSE-2.0
 
 Unless required by applicable law or agreed to in writing,
 software distributed under the License is distributed on an
 "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 KIND, either express or implied.  See the License for the
 specific language governing permissions and limitations
 under the License.
*/

;(function() {

// file: lib/scripts/sktrequire.js
var sktrequire,
    sktdefine;

(function () {
    var modules = {};

    function build(module) {
        var factory = module.factory;
        module.exports = {};
        delete module.factory;
        factory(sktrequire, module.exports, module);
        return module.exports;
    }

    sktrequire = function (id) {
        if (!modules[id]) {
            throw "module " + id + " not found";
        }
        return modules[id].factory ? build(modules[id]) : modules[id].exports;
    };

    sktdefine = function (id, factory) {
        if (modules[id]) {
            throw "module " + id + " already defined";
        }

        modules[id] = {
            id: id,
            factory: factory
        };
    };

    sktdefine.remove = function (id) {
        delete modules[id];
    };

})();

//Export for use in node
if (typeof module === "object" && typeof sktrequire === "function") {
    module.exports.sktrequire = sktrequire;
    module.exports.sktdefine = sktdefine;
}
// file: lib/srt.js
sktdefine("srt", function(sktrequire, exports, module) {
var channel = sktrequire('srt/channel');

/**
 * Listen for DOMContentLoaded and notify our channel subscribers.
 */
document.addEventListener('DOMContentLoaded', function() {
    channel.onDOMContentLoaded.fire();
}, false);
if (document.readyState == 'complete' || document.readyState == 'interactive') {
    channel.onDOMContentLoaded.fire();
}

/**
 * Intercept calls to addEventListener + removeEventListener and handle deviceready,
 * resume, and pause events.
 */
var m_document_addEventListener = document.addEventListener;
var m_document_removeEventListener = document.removeEventListener;
var m_window_addEventListener = window.addEventListener;
var m_window_removeEventListener = window.removeEventListener;

/**
 * Houses custom event handlers to intercept on document + window event listeners.
 */
var documentEventHandlers = {},
    windowEventHandlers = {};

document.addEventListener = function(evt, handler, capture) {
    var e = evt.toLowerCase();
    if (typeof documentEventHandlers[e] != 'undefined') {
        if (evt === 'deviceready') {
            documentEventHandlers[e].subscribeOnce(handler);
        } else {
            documentEventHandlers[e].subscribe(handler);
        }
    } else {
        m_document_addEventListener.call(document, evt, handler, capture);
    }
};

window.addEventListener = function(evt, handler, capture) {
    var e = evt.toLowerCase();
    if (typeof windowEventHandlers[e] != 'undefined') {
        windowEventHandlers[e].subscribe(handler);
    } else {
        m_window_addEventListener.call(window, evt, handler, capture);
    }
};

document.removeEventListener = function(evt, handler, capture) {
    var e = evt.toLowerCase();
    // If unsubcribing from an event that is handled by a plugin
    if (typeof documentEventHandlers[e] != "undefined") {
        documentEventHandlers[e].unsubscribe(handler);
    } else {
        m_document_removeEventListener.call(document, evt, handler, capture);
    }
};

window.removeEventListener = function(evt, handler, capture) {
    var e = evt.toLowerCase();
    // If unsubcribing from an event that is handled by a plugin
    if (typeof windowEventHandlers[e] != "undefined") {
        windowEventHandlers[e].unsubscribe(handler);
    } else {
        m_window_removeEventListener.call(window, evt, handler, capture);
    }
};

function createEvent(type, data) {
    var event = document.createEvent('Events');
    event.initEvent(type, false, false);
    if (data) {
        for (var i in data) {
            if (data.hasOwnProperty(i)) {
                event[i] = data[i];
            }
        }
    }
    return event;
}

if(typeof window.console === "undefined") {
    window.console = {
        log:function(){}
    };
}

var srt = {
    sktdefine:sktdefine,
    sktrequire:sktrequire,
    /**
     * Methods to add/remove your own addEventListener hijacking on document + window.
     */
    addWindowEventHandler:function(event, opts) {
        return (windowEventHandlers[event] = channel.create(event, opts));
    },
    addDocumentEventHandler:function(event, opts) {
        return (documentEventHandlers[event] = channel.create(event, opts));
    },
    removeWindowEventHandler:function(event) {
        delete windowEventHandlers[event];
    },
    removeDocumentEventHandler:function(event) {
        delete documentEventHandlers[event];
    },
    /**
     * Retreive original event handlers that were replaced by srt
     *
     * @return object
     */
    getOriginalHandlers: function() {
        return {'document': {'addEventListener': m_document_addEventListener, 'removeEventListener': m_document_removeEventListener},
        'window': {'addEventListener': m_window_addEventListener, 'removeEventListener': m_window_removeEventListener}};
    },
    /**
     * Method to fire event from native code
     */
    fireDocumentEvent: function(type, data) {
        var evt = createEvent(type, data);
        if (typeof documentEventHandlers[type] != 'undefined') {
            documentEventHandlers[type].fire(evt);
        } else {
            document.dispatchEvent(evt);
        }
    },
    fireWindowEvent: function(type, data) {
        var evt = createEvent(type,data);
        if (typeof windowEventHandlers[type] != 'undefined') {
            windowEventHandlers[type].fire(evt);
        } else {
            window.dispatchEvent(evt);
        }
    },
    // TODO: this is Android only; think about how to do this better
    shuttingDown:false,
    UsePolling:false,
    // END TODO

    // TODO: iOS only
    // This queue holds the currently executing command and all pending
    // commands executed with srt.exec().
    commandQueue:[],
    // Indicates if we're currently in the middle of flushing the command
    // queue on the native side.
    commandQueueFlushing:false,
    // END TODO
    /**
     * Plugin callback mechanism.
     */
    callbackId: 0,
    callbacks:  {},
    callbackStatus: {
        NO_RESULT: 0,
        OK: 1,
        CLASS_NOT_FOUND_EXCEPTION: 2,
        ILLEGAL_ACCESS_EXCEPTION: 3,
        INSTANTIATION_EXCEPTION: 4,
        MALFORMED_URL_EXCEPTION: 5,
        IO_EXCEPTION: 6,
        INVALID_ACTION: 7,
        JSON_EXCEPTION: 8,
        ERROR: 9
    },

    /**
     * Called by native code when returning successful result from an action.
     *
     * @param callbackId
     * @param args
     */
    callbackSuccess: function(callbackId, args) {
        if (srt.callbacks[callbackId]) {

            // If result is to be sent to callback
            if (args.status == srt.callbackStatus.OK) {
                try {
                    if (srt.callbacks[callbackId].success) {
                        srt.callbacks[callbackId].success(args.message);
                    }
                }
                catch (e) {
                    console.log("Error in success callback: "+callbackId+" = "+e);
                }
            }

            // Clear callback if not expecting any more results
            if (!args.keepCallback) {
                delete srt.callbacks[callbackId];
            }
        }
    },

    /**
     * Called by native code when returning error result from an action.
     *
     * @param callbackId
     * @param args
     */
    callbackError: function(callbackId, args) {
        if (srt.callbacks[callbackId]) {
            try {
                if (srt.callbacks[callbackId].fail) {
                    srt.callbacks[callbackId].fail(args.message);
                }
            }
            catch (e) {
                console.log("Error in error callback: "+callbackId+" = "+e);
            }

            // Clear callback if not expecting any more results
            if (!args.keepCallback) {
                delete srt.callbacks[callbackId];
            }
        }
    },
    // TODO: remove in 2.0.
    addPlugin: function(name, obj) {
        console.log("[DEPRECATION NOTICE] window.addPlugin and window.plugins will be removed in version 2.0.");
        if (!window.plugins[name]) {
            window.plugins[name] = obj;
        }
        else {
            console.log("Error: Plugin "+name+" already exists.");
        }
    },

    addConstructor: function(func) {
        channel.onSKTRuntimeReady.subscribeOnce(function() {
            try {
                func();
            } catch(e) {
                console.log("Failed to run constructor: " + e);
            }
        });
    }
};

// Register pause, resume and deviceready channels as events on document.
channel.onPause = srt.addDocumentEventHandler('pause');
channel.onResume = srt.addDocumentEventHandler('resume');
channel.onDeviceReady = srt.addDocumentEventHandler('deviceready');

/**
 * Plugins object
 * TODO: remove in 2.0.
 */
if (!window.plugins) {
    window.plugins = {};
}

module.exports = srt;

});

// file: lib/common/builder.js
sktdefine("srt/builder", function(sktrequire, exports, module) {
var utils = sktrequire('srt/utils');

function each(objects, func, context) {
    for (var prop in objects) {
        if (objects.hasOwnProperty(prop)) {
            func.apply(context, [objects[prop], prop]);
        }
    }
}

function include(parent, objects, clobber, merge) {
    each(objects, function (obj, key) {
        try {
          var result = obj.path ? sktrequire(obj.path) : {};

          if (clobber) {
              // Clobber if it doesn't exist.
              if (typeof parent[key] === 'undefined') {
                  parent[key] = result;
              } else if (typeof obj.path !== 'undefined') {
                  // If merging, merge properties onto parent, otherwise, clobber.
                  if (merge) {
                      recursiveMerge(parent[key], result);
                  } else {
                      parent[key] = result;
                  }
              }
              result = parent[key];
          } else {
            // Overwrite if not currently defined.
            if (typeof parent[key] == 'undefined') {
              parent[key] = result;
            } else if (merge && typeof obj.path !== 'undefined') {
              // If merging, merge parent onto result
              recursiveMerge(result, parent[key]);
              parent[key] = result;
            } else {
              // Set result to what already exists, so we can build children into it if they exist.
              result = parent[key];
            }
          }

          if (obj.children) {
            include(result, obj.children, clobber, merge);
          }
        } catch(e) {
          utils.alert('Exception building srt JS globals: ' + e + ' for key "' + key + '"');
        }
    });
}

/**
 * Merge properties from one object onto another recursively.  Properties from
 * the src object will overwrite existing target property.
 *
 * @param target Object to merge properties into.
 * @param src Object to merge properties from.
 */
function recursiveMerge(target, src) {
    for (var prop in src) {
        if (src.hasOwnProperty(prop)) {
            if (typeof target.prototype !== 'undefined' && target.prototype.constructor === target) {
                // If the target object is a constructor override off prototype.
                target.prototype[prop] = src[prop];
            } else {
                target[prop] = typeof src[prop] === 'object' ? recursiveMerge(
                        target[prop], src[prop]) : src[prop];
            }
        }
    }
    return target;
}

module.exports = {
    build: function (objects) {
        return {
            intoButDontClobber: function (target) {
                include(target, objects, false, false);
            },
            intoAndClobber: function(target) {
                include(target, objects, true, false);
            },
            intoAndMerge: function(target) {
                include(target, objects, true, true);
            }
        };
    }
};

});

// file: lib/common/channel.js
sktdefine("srt/channel", function(sktrequire, exports, module) {
var utils = sktrequire('srt/utils');

/**
 * Custom pub-sub "channel" that can have functions subscribed to it
 * This object is used to define and control firing of events for
 * cordova initialization.
 *
 * The order of events during page load and Cordova startup is as follows:
 *
 * onDOMContentLoaded         Internal event that is received when the web page is loaded and parsed.
 * onNativeReady              Internal event that indicates the Cordova native side is ready.
 * onSKTRuntimeReady          Internal event fired when all SKTRuntime JavaScript objects have been created.
 * onCordovaInfoReady         Internal event fired when device properties are available.
 * onCordovaConnectionReady   Internal event fired when the connection property has been set.
 * onDeviceReady              User event fired to indicate that Cordova is ready
 * onResume                   User event fired to indicate a start/resume lifecycle event
 * onPause                    User event fired to indicate a pause lifecycle event
 * onDestroy                  Internal event fired when app is being destroyed (User should use window.onunload event, not this one).
 *
 * The only Cordova events that user code should register for are:
 *      deviceready           Cordova native code is initialized and Cordova APIs can be called from JavaScript
 *      pause                 App has moved to background
 *      resume                App has returned to foreground
 *
 * Listeners can be registered as:
 *      document.addEventListener("deviceready", myDeviceReadyListener, false);
 *      document.addEventListener("resume", myResumeListener, false);
 *      document.addEventListener("pause", myPauseListener, false);
 *
 * The DOM lifecycle events should be used for saving and restoring state
 *      window.onload
 *      window.onunload
 *
 */

/**
 * Channel
 * @constructor
 * @param type  String the channel name
 * @param opts  Object options to pass into the channel, currently
 *                     supports:
 *                     onSubscribe: callback that fires when
 *                       something subscribes to the Channel. Sets
 *                       context to the Channel.
 *                     onUnsubscribe: callback that fires when
 *                       something unsubscribes to the Channel. Sets
 *                       context to the Channel.
 */
var Channel = function(type, opts) {
    this.type = type;
    this.handlers = {};
    this.numHandlers = 0;
    this.guid = 1;
    this.fired = false;
    this.enabled = true;
    this.events = {
        onSubscribe:null,
        onUnsubscribe:null
    };
    if (opts) {
        if (opts.onSubscribe) this.events.onSubscribe = opts.onSubscribe;
        if (opts.onUnsubscribe) this.events.onUnsubscribe = opts.onUnsubscribe;
    }
},
    channel = {
        /**
         * Calls the provided function only after all of the channels specified
         * have been fired.
         */
        join: function (h, c) {
            var i = c.length;
            var len = i;
            var f = function() {
                if (!(--i)) h();
            };
            for (var j=0; j<len; j++) {
                !c[j].fired?c[j].subscribeOnce(f):i--;
            }
            if (!i) h();
        },
        create: function (type, opts) {
            channel[type] = new Channel(type, opts);
            return channel[type];
        },

        /**
         * cordova Channels that must fire before "deviceready" is fired.
         */
        deviceReadyChannelsArray: [],
        deviceReadyChannelsMap: {},

        /**
         * Indicate that a feature needs to be initialized before it is ready to be used.
         * This holds up Cordova's "deviceready" event until the feature has been initialized
         * and Cordova.initComplete(feature) is called.
         *
         * @param feature {String}     The unique feature name
         */
        waitForInitialization: function(feature) {
            if (feature) {
                var c = null;
                if (this[feature]) {
                    c = this[feature];
                }
                else {
                    c = this.create(feature);
                }
                this.deviceReadyChannelsMap[feature] = c;
                this.deviceReadyChannelsArray.push(c);
            }
        },

        /**
         * Indicate that initialization code has completed and the feature is ready to be used.
         *
         * @param feature {String}     The unique feature name
         */
        initializationComplete: function(feature) {
            var c = this.deviceReadyChannelsMap[feature];
            if (c) {
                c.fire();
            }
        }
    };

function forceFunction(f) {
    if (f === null || f === undefined || typeof f != 'function') throw "Function required as first argument!";
}

/**
 * Subscribes the given function to the channel. Any time that
 * Channel.fire is called so too will the function.
 * Optionally specify an execution context for the function
 * and a guid that can be used to stop subscribing to the channel.
 * Returns the guid.
 */
Channel.prototype.subscribe = function(f, c, g) {
    // need a function to call
    forceFunction(f);

    var func = f;
    if (typeof c == "object") { func = utils.close(c, f); }

    g = g || func.observer_guid || f.observer_guid;
    if (!g) {
        // first time we've seen this subscriber
        g = this.guid++;
    }
    else {
        // subscriber already handled; dont set it twice
        return g;
    }
    func.observer_guid = g;
    f.observer_guid = g;
    this.handlers[g] = func;
    this.numHandlers++;
    if (this.events.onSubscribe) this.events.onSubscribe.call(this);
    if (this.fired) func.call(this);
    return g;
};

/**
 * Like subscribe but the function is only called once and then it
 * auto-unsubscribes itself.
 */
Channel.prototype.subscribeOnce = function(f, c) {
    // need a function to call
    forceFunction(f);

    var g = null;
    var _this = this;
    var m = function() {
        f.apply(c || null, arguments);
        _this.unsubscribe(g);
    };
    if (this.fired) {
        if (typeof c == "object") { f = utils.close(c, f); }
        f.apply(this, this.fireArgs);
    } else {
        g = this.subscribe(m);
    }
    return g;
};

/**
 * Unsubscribes the function with the given guid from the channel.
 */
Channel.prototype.unsubscribe = function(g) {
    // need a function to unsubscribe
    if (g === null || g === undefined) { throw "You must pass _something_ into Channel.unsubscribe"; }

    if (typeof g == 'function') { g = g.observer_guid; }
    var handler = this.handlers[g];
    if (handler) {
        if (handler.observer_guid) handler.observer_guid=null;
        this.handlers[g] = null;
        delete this.handlers[g];
        this.numHandlers--;
        if (this.events.onUnsubscribe) this.events.onUnsubscribe.call(this);
    }
};

/**
 * Calls all functions subscribed to this channel.
 */
Channel.prototype.fire = function(e) {
    if (this.enabled) {
        var fail = false;
        this.fired = true;
        for (var item in this.handlers) {
            var handler = this.handlers[item];
            if (typeof handler == 'function') {
                var rv = (handler.apply(this, arguments)===false);
                fail = fail || rv;
            }
        }
        this.fireArgs = arguments;
        return !fail;
    }
    return true;
};

// defining them here so they are ready super fast!
// DOM event that is received when the web page is loaded and parsed.
channel.create('onDOMContentLoaded');

// Event to indicate the Cordova native side is ready.
channel.create('onNativeReady');

// Event to indicate that all Cordova JavaScript objects have been created
// and it's time to run plugin constructors.
channel.create('onSKTRuntimeReady');

// Event to indicate that device properties are available
channel.create('onCordovaInfoReady');

// Event to indicate that the connection property has been set.
channel.create('onCordovaConnectionReady');

// Event to indicate that Cordova is ready
channel.create('onDeviceReady');

// Event to indicate a resume lifecycle event
channel.create('onResume');

// Event to indicate a pause lifecycle event
channel.create('onPause');

// Event to indicate a destroy lifecycle event
channel.create('onDestroy');

// Channels that must fire before "deviceready" is fired.
channel.waitForInitialization('onSKTRuntimeReady');
channel.waitForInitialization('onCordovaInfoReady');
channel.waitForInitialization('onCordovaConnectionReady');

module.exports = channel;

});

// file: lib/common/common.js
sktdefine("srt/common", function(sktrequire, exports, module) {
module.exports = {
    objects: {
        srt: {
            path: 'srt',
            children: {
                exec: {
                    path: 'srt/exec'
                },
                logger: {
                    path: 'srt/plugin/logger'
                }
            }
        },
        navigator: {
            children: {
                notification: {
                    path: 'srt/plugin/notification'
                },
                accelerometer: {
                    path: 'srt/plugin/accelerometer'
                },
                //[20120822][chisu]applauncher
                applauncher: {
                    path: 'srt/plugin/applauncher'
                },
                //[20120613][chisu]add orientation
                orientation: {
                	path: 'srt/plugin/orientation'
                },
                //[20120618][chisu]add battery
                battery: {
                    path: 'srt/plugin/battery'
                },
                //[20120625][chisu]add calendar
                calendar:{
                    path: 'srt/plugin/calendar'
                },
                //[20120719][chisu]add capture
                capture:{
                    path: 'srt/plugin/capture'
                },
                camera:{
                    path: 'srt/plugin/Camera'
                },
                compass:{
                    path: 'srt/plugin/compass'
                },
                contacts: {
                    path: 'srt/plugin/contacts'
                },
                //[20120823][chisu]childbrowser
                childBrowser: {
                    path: 'srt/plugin/childbrowser'
                },
                device:{
                    children:{
                        capture: {
                            path: 'srt/plugin/capture'
                        }
                    }
                },
                //[20120702][chisu]devicesensor
                devicesensor: {
                	path: 'srt/plugin/devicesensor'
                },
                //[20120820][chisu]deviceinteraction
                deviceinteraction: {
                	path: 'srt/plugin/deviceinteraction'
                },
                //[20120814][chisu]devicestatus
                devicestatus: {
                	path: 'srt/plugin/devicestatus'
                },
                geolocation: {
                    path: 'srt/plugin/geolocation'
                },
                //[20120619][chisu]connection
                connection: {   
                    path: 'srt/plugin/connection'
                },
                //[20120619][chisu]add messaging
                messaging:{
                	path: 'srt/plugin/messaging'
                },
                //[20120821][chisu]add mediamanager
                mediamanager:{
                	path: 'srt/plugin/mediamanager'
                },
                //[20120827][chisu]add localNotification
                localNotification:{
                	path: 'srt/plugin/localnotification'
                },
                splashscreen: {
                    path: 'srt/plugin/splashscreen'
                }, 
                //[20120821][chisu]add screenshot
                screenshot: {
                    path: 'srt/plugin/screenshot'
                }, 
                //[20120613][chisu]add vibrate
                vibrate:{
                	path: 'srt/plugin/vibrate'
                }
            }
        },
        Acceleration: {
            path: 'srt/plugin/Acceleration'
        },
        //[20120613][chisu]add Rotation
        Rotation: {
        	path : 'srt/plugin/Rotation'
        },
        //[20120625][chisu]add CalendarEvent
        CalendarEvent:{
            path: 'srt/plugin/CalendarEvent'
        },
        CalendarRepeatRule:{
            path: 'srt/plugin/CalendarRepeatRule'
        },
        CalendarEventFilter:{
            path: 'srt/plugin/CalendarEventFilter'
        },
        CalendarFindOptions:{
            path: 'srt/plugin/CalendarFindOptions'
        },
        CalendarError:{
            path: 'srt/plugin/CalendarError'
        },
        Camera:{
            path: 'srt/plugin/CameraConstants'
        },
        CameraPopoverOptions: {
            path: 'srt/plugin/CameraPopoverOptions'
        },
        CaptureError: {
            path: 'srt/plugin/CaptureError'
        },
        CaptureAudioOptions:{
            path: 'srt/plugin/CaptureAudioOptions'
        },
        CaptureImageOptions: {
            path: 'srt/plugin/CaptureImageOptions'
        },
        CaptureVideoOptions: {
            path: 'srt/plugin/CaptureVideoOptions'
        },
        CompassHeading:{
            path: 'srt/plugin/CompassHeading'
        },
        CompassError:{
            path: 'srt/plugin/CompassError'
        },
        ConfigurationData: {
            path: 'srt/plugin/ConfigurationData'
        },
        //[20120619][chisu]remove Connection used in Cordova
        //Connection: {
        //    path: 'srt/plugin/Connection'
        //},
        Contact: {
            path: 'srt/plugin/Contact'
        },
        ContactAddress: {
            path: 'srt/plugin/ContactAddress'
        },
        ContactError: {
            path: 'srt/plugin/ContactError'
        },
        ContactField: {
            path: 'srt/plugin/ContactField'
        },
        ContactFindOptions: {
            path: 'srt/plugin/ContactFindOptions'
        },
        ContactName: {
            path: 'srt/plugin/ContactName'
        },
        ContactOrganization: {
            path: 'srt/plugin/ContactOrganization'
        },
        Coordinates: {
            path: 'srt/plugin/Coordinates'
        },
        DirectoryEntry: {
            path: 'srt/plugin/DirectoryEntry'
        },
        DirectoryReader: {
            path: 'srt/plugin/DirectoryReader'
        },
        //[20120702][chisu]DeviceSensor
        DeviceSensor: {
        	path : 'srt/plugin/DeviceSensor'
        },
        Entry: {
            path: 'srt/plugin/Entry'
        },
        File: {
            path: 'srt/plugin/File'
        },
        FileEntry: {
            path: 'srt/plugin/FileEntry'
        },
        FileError: {
            path: 'srt/plugin/FileError'
        },
        FileReader: {
            path: 'srt/plugin/FileReader'
        },
        FileSystem: {
            path: 'srt/plugin/FileSystem'
        },
        FileTransfer: {
            path: 'srt/plugin/FileTransfer'
        },
        FileTransferError: {
            path: 'srt/plugin/FileTransferError'
        },
        FileUploadOptions: {
            path: 'srt/plugin/FileUploadOptions'
        },
        FileUploadResult: {
            path: 'srt/plugin/FileUploadResult'
        },
        FileWriter: {
            path: 'srt/plugin/FileWriter'
        },
        Flags: {
            path: 'srt/plugin/Flags'
        },
        //[20120724][chisu]IndexedDB
        indexedDB: {
            path: 'srt/plugin/indexedDB'
        },
        //[20120724][chisu]IDBRequest
        IDBRequest: {
            path: 'srt/plugin/IDBRequest'
        },
        //[20120724][chisu]IDBDatabase
        IDBDatabase: {
            path: 'srt/plugin/IDBDatabase'
        },
        //[20120724][chisu]Transaction
        Transaction: {
            path: 'srt/plugin/Transaction'
        },
        //[20120724][chisu]IDBTransaction
        IDBTransaction: {
        path: 'srt/plugin/IDBTransaction'
        },
        //[20120724][chisu]IDBObjectStoreParameters
        IDBObjectStoreParameters: {
            path: 'srt/plugin/IDBObjectStoreParameters'
        },
        //[20120724][chisu]IDBCursor
        IDBCursor: {
            path: 'srt/plugin/IDBCursor'
        },
        //[20120724][chisu]IDBObjectStore
        IDBObjectStore: {
            path: 'srt/plugin/IDBObjectStore'
        },
        //[20120730][chisu]IDBIndex
        IDBIndex: {
            path: 'srt/plugin/IDBIndex'
        },
        //[20120730][chisu]IDBKeyRange
        IDBKeyRange: {
            path: 'srt/plugin/IDBKeyRange'
        },
        LocalFileSystem: {
            path: 'srt/plugin/LocalFileSystem'
        },
        Media: {
            path: 'srt/plugin/Media'
        },
        MediaError: {
            path: 'srt/plugin/MediaError'
        },
        MediaFile: {
            path: 'srt/plugin/MediaFile'
        },
        MediaFileData:{
            path: 'srt/plugin/MediaFileData'
        },
        Metadata:{
            path: 'srt/plugin/Metadata'
        },
        //[20120619][chisu]Messaging
        Messaging:{
        	path: 'srt/plugin/Messaging'
        },
        //[20120619][chisu]Message;
        Message:{
        	path:'srt/plugin/Message'
        },
      //[20120619][chisu]MessageError;
        MessagingError:{
        	path:'srt/plugin/MessagingError'
        },
        Position: {
            path: 'srt/plugin/Position'
        },
        PositionError: {
            path: 'srt/plugin/PositionError'
        },
        ProgressEvent: {
            path: 'srt/plugin/ProgressEvent'
        },
        requestFileSystem:{
            path: 'srt/plugin/requestFileSystem'
        },
        resolveLocalFileSystemURI:{
            path: 'srt/plugin/resolveLocalFileSystemURI'
        }
        //[2010709][chisu]Worker
        //Worker:{
        //    path: 'srt/plugin/Worker'
        //}
    }
};

});

// file: lib/ios/exec.js
sktdefine("srt/exec", function(sktrequire, exports, module) {
    /**
     * Creates a gap bridge iframe used to notify the native code about queued
     * commands.
     *
     * @private
     */
var srt = sktrequire('srt'),
    utils = sktrequire('srt/utils'),
    gapBridge,
    createGapBridge = function() {
        gapBridge = document.createElement("iframe");
        gapBridge.setAttribute("style", "display:none;");
        gapBridge.setAttribute("height","0px");
        gapBridge.setAttribute("width","0px");
        gapBridge.setAttribute("frameborder","0");
        document.documentElement.appendChild(gapBridge);
    },
    channel = sktrequire('srt/channel');

module.exports = function() {
    if (!channel.onCordovaInfoReady.fired) {
        utils.alert("ERROR: Attempting to call cordova.exec()" +
              " before 'deviceready'. Ignoring.");
        return;
    }

    var successCallback, failCallback, service, action, actionArgs, splitCommand;
    var callbackId = null;
    if (typeof arguments[0] !== "string") {
        // FORMAT ONE
        successCallback = arguments[0];
        failCallback = arguments[1];
        service = arguments[2];
        action = arguments[3];
        actionArgs = arguments[4];

        // Since we need to maintain backwards compatibility, we have to pass
        // an invalid callbackId even if no callback was provided since plugins
        // will be expecting it. The Cordova.exec() implementation allocates
        // an invalid callbackId and passes it even if no callbacks were given.
        callbackId = 'INVALID';
    } else {
        // FORMAT TWO
        splitCommand = arguments[0].split(".");
        action = splitCommand.pop();
        service = splitCommand.join(".");
        actionArgs = Array.prototype.splice.call(arguments, 1);
    }

    // Start building the command object.
    var command = {
        className: service,
        methodName: action,
        "arguments": []
    };

    // Register the callbacks and add the callbackId to the positional
    // arguments if given.
    if (successCallback || failCallback) {
        callbackId = service + srt.callbackId++;
        srt.callbacks[callbackId] =
            {success:successCallback, fail:failCallback};
    }
    if (callbackId !== null) {
        command["arguments"].push(callbackId);
    }

    for (var i = 0; i < actionArgs.length; ++i) {
        var arg = actionArgs[i];
        if (arg === undefined || arg === null) { // nulls are pushed to the args now (becomes NSNull)
            command["arguments"].push(arg);
        } else if (typeof(arg) == 'object' && !(utils.isArray(arg))) {
            command.options = arg;
        } else {
            command["arguments"].push(arg);
        }
    }

    // Stringify and queue the command. We stringify to command now to
    // effectively clone the command arguments in case they are mutated before
    // the command is executed.
    srt.commandQueue.push(JSON.stringify(command));

    // If the queue length is 1, then that means it was empty before we queued
    // the given command, so let the native side know that we have some
    // commands to execute, unless the queue is currently being flushed, in
    // which case the command will be picked up without notification.
    if (srt.commandQueue.length == 1 && !srt.commandQueueFlushing) {
        if (!gapBridge) {
            createGapBridge();
        }
        gapBridge.src = "gap://ready";
    }
};

});

// file: lib/ios/platform.js
sktdefine("srt/platform", function(sktrequire, exports, module) {
module.exports = {
    id: "ios",
    initialize:function() {
        // iOS doesn't allow reassigning / overriding navigator.geolocation object.
        // So clobber its methods here instead :)
        var geo = sktrequire('srt/plugin/geolocation');

        navigator.geolocation.getCurrentPosition = geo.getCurrentPosition;
        navigator.geolocation.watchPosition = geo.watchPosition;
        navigator.geolocation.clearWatch = geo.clearWatch;
    },
    objects: {
        File: { // exists natively, override
            path: "srt/plugin/File"
        },
        MediaError: { // exists natively, override
            path: "srt/plugin/MediaError"
        },
        device: {
            path: 'srt/plugin/ios/device'
        },
        console: {
            path: 'srt/plugin/ios/console'
        }
    },
    merges:{
        Contact:{
            path: "srt/plugin/ios/Contact"
        },
        Entry:{
            path: "srt/plugin/ios/Entry"
        },
        FileReader:{
            path: "srt/plugin/ios/FileReader"
        },
        navigator:{
            children:{
                notification:{
                    path:"srt/plugin/ios/notification"
                },
                contacts:{
                    path:"srt/plugin/ios/contacts"
                }
            }
        }
    }
};

});

//file: lib/common/plugin/DeviceSensor.js
sktdefine("srt/plugin/DeviceSensor", function(sktrequire, exports, module) {
	module.exports = {
			TYPE_DEVICETEMPERATURE:   1,
			TYPE_DEVICEPRESSURE:   2,
			TYPE_DEVICEHUMIDITY: 3,
			TYPE_DEVICELIGHT: 4,
			TYPE_DEVICEPROXIMITY: 5
	};
});

//file: lib/common/plugin/devicesensor.js
sktdefine("srt/plugin/devicesensor", function(sktrequire, exports, module) {
/**
 * This class contains information about the current devicesensor status.
 * @constructor
 */
var srt = sktrequire('srt'),
    exec = sktrequire('srt/exec');

function devicetemperaturehandlers() {
	return devicesensor.channels.devicetemperature.numHandlers;
}

function devicepressurehandlers() {
	return devicesensor.channels.devicepressure.numHandlers;
}

function devicehumidityhandlers() {
	return devicesensor.channels.devicehumidity.numHandlers;
}

function devicelighthandlers() {
	return devicesensor.channels.devicelight.numHandlers;
}

function deviceproximityhandlers() {
	return devicesensor.channels.deviceproximity.numHandlers;
}

var DeviceSensor = function() {
	
	this.temperature = null;
	this.pressure = null;
	this.humidity = null;
	this.light = null;
	this.proximity = null;
	
    // Create new event handlers on the window (returns a channel instance)
	var devicetemperaturesubscriptionEvents = {
			onSubscribe:this.devicetemperatureonSubscribe,
			onUnsubscribe:this.devicetemperatureonUnsubscribe
	};
	var devicepressuresubscriptionEvents = {
			onSubscribe:this.devicepressureonSubscribe,
			onUnsubscribe:this.devicepressureonUnsubscribe
	};
	var devicehumiditysubscriptionEvents = {
			onSubscribe:this.devicehumidityonSubscribe,
			onUnsubscribe:this.devicehumidityonUnsubscribe
	};
	var devicelightsubscriptionEvents = {
			onSubscribe:this.devicelightonSubscribe,
			onUnsubscribe:this.devicelightonUnsubscribe
	};
	var deviceproximitysubscriptionEvents = {
			onSubscribe:this.deviceproximityonSubscribe,
			onUnsubscribe:this.deviceproximityonUnsubscribe
	};
    
    this.channels = {
      devicetemperature:srt.addWindowEventHandler("devicetemperature", devicetemperaturesubscriptionEvents),
      devicepressure:srt.addWindowEventHandler("devicepressure", devicepressuresubscriptionEvents),
      devicehumidity:srt.addWindowEventHandler("devicehumidity", devicehumiditysubscriptionEvents),
      devicelight:srt.addWindowEventHandler("devicelight", devicelightsubscriptionEvents),
      deviceproximity:srt.addWindowEventHandler("deviceproximity", deviceproximitysubscriptionEvents)
    };
};

//temperature
DeviceSensor.prototype.devicetemperatureonSubscribe = function() {
  var me = devicesensor;
  // If we just registered the first handler, make sure native listener is started.
  if (devicetemperaturehandlers() === 1) {
    exec(me._status, me._error, "TemperatureSensor", "start", []);
  }
};

DeviceSensor.prototype.devicetemperatureonUnsubscribe = function() {
  var me = devicesensor;
  // If we just unregistered the last handler, make sure native listener is stopped.
  if (devicetemperaturehandlers() === 0) {
      exec(null, null, "TemperatureSensor", "stop", []);
  }
};

//pressure
DeviceSensor.prototype.devicepressureonSubscribe = function() {
	var me = devicesensor;
	// If we just registered the first handler, make sure native listener is started.
	if (devicepressurehandlers() === 1) {
		exec(me._status, me._error, "PressureSensor", "start", []);
	}
};

DeviceSensor.prototype.devicepressureonUnsubscribe = function() {
	var me = devicesensor;

	// If we just unregistered the last handler, make sure native listener is stopped.
	if (devicepressurehandlers() === 0) {
		exec(null, null, "PressureSensor", "stop", []);
	}
};

//humidity
DeviceSensor.prototype.devicehumidityonSubscribe = function() {
	var me = devicesensor;
	// If we just registered the first handler, make sure native listener is started.
	if (devicehumidityhandlers() === 1) {
		exec(me._status, me._error, "HumiditySensor", "start", []);
	}
};

DeviceSensor.prototype.devicehumidityonUnsubscribe = function() {
	var me = devicesensor;

	// If we just unregistered the last handler, make sure native listener is stopped.
	if (devicehumidityhandlers() === 0) {
		exec(null, null, "HumiditySensor", "stop", []);
	}
};

//light
DeviceSensor.prototype.devicelightonSubscribe = function() {
	var me = devicesensor;
	// If we just registered the first handler, make sure native listener is started.
	if (devicelighthandlers() === 1) {
		exec(me._status, me._error, "LightSensor", "start", []);
	}
};

DeviceSensor.prototype.devicelightonUnsubscribe = function() {
	var me = devicesensor;

	// If we just unregistered the last handler, make sure native listener is stopped.
	if (devicelighthandlers() === 0) {
		exec(null, null, "LightSensor", "stop", []);
	}
};

//Proximity
DeviceSensor.prototype.deviceproximityonSubscribe = function() {
	var me = devicesensor;
	// If we just registered the first handler, make sure native listener is started.
	if (deviceproximityhandlers() === 1) {
		exec(me._status, me._error, "ProximitySensor", "start", []);
	}
};

DeviceSensor.prototype.deviceproximityonUnsubscribe = function() {
	var me = devicesensor;

	// If we just unregistered the last handler, make sure native listener is stopped.
	if (deviceproximityhandlers() === 0) {
		exec(null, null, "ProximitySensor", "stop", []);
	}
};
/**
 * Callback for DeviceSensor status
 */
DeviceSensor.prototype._status = function(info) {
	if (info) {
		var me = devicesensor;		
		
//		DeviceSensor.TYPE_DEVICETEMPERATURE:   1,
//		DeviceSensorTYPE_DEVICEPRESSURE:   2,
//		DeviceSensorTYPE_DEVICEHUMIDITY: 3,
//		DeviceSensorTYPE_DEVICELIGHT: 4,
//		DeviceSensorTYPE_DEVICEPROXIMITY: 5
		
		if((info.type == 1) && (info.value != me.temperature)){
			me.temperature = info.value;
			srt.fireWindowEvent("devicetemperature", info);
		}
		else if((info.type == 2) && (info.value != me.pressure)){
			me.pressure = info.value;
			srt.fireWindowEvent("devicepressure", info);
		}
		else if((info.type == 3) && (info.value != me.humidity)){
			me.humidity = info.value;
			srt.fireWindowEvent("devicehumidity", info);
		}
		else if((info.type == 4) && (info.value != me.light)){
			me.light = info.value;
			srt.fireWindowEvent("devicelight", info);
		}
		else if((info.type == 5) && (info.value != me.proximity)){
			me.proximity = info.value;
			srt.fireWindowEvent("deviceproximity", info);
		}
	}
};

/**
 * Error callback for devicesensor start
 */
DeviceSensor.prototype._error = function(e) {
    console.log("Error initializing DeviceSensor: " + e.message);
};

var devicesensor = new DeviceSensor();

module.exports = devicesensor;

});

// file: lib/common/plugin/Acceleration.js
sktdefine("srt/plugin/Acceleration", function(sktrequire, exports, module) {
var Acceleration = function(x, y, z, timestamp) {
    this.x = x;
    this.y = y;
    this.z = z;
    this.timestamp = timestamp || (new Date()).getTime();
};

module.exports = Acceleration;

});

//[20120613][chisu]Rotation
//file: lib/common/plugin/Rotation.js
sktdefine("srt/plugin/Rotation", function(sktrequire, exports, module) {
var Rotation = function(alpha, beta, gamma) {
    this.alpha = alpha;
    this.beta = beta;
    this.gamma = gamma;
    this.timestamp = (new Date()).getTime();
};

module.exports = Rotation;

});


//file: lib/common/plugin/orientation.js
sktdefine("srt/plugin/orientation", function(sktrequire, exports, module) {
/**
 * This class provides access to device orientation data.
 * @constructor
 */
var utils = sktrequire("srt/utils"),
    exec = sktrequire("srt/exec"),
    Rotation = sktrequire('srt/plugin/Rotation');

// Is the orientation sensor running?
var running = false;

// Keeps reference to watchOrientation calls.
var timers = {};

// Array of listeners; used to keep track of when we should call start and stop.
var listeners = [];

// Last returned rotation object from native
var ori = null;
       
var successCB = null;
       
// Tells native to start.
function start() {
    exec(function(a) {
        var tempListeners = listeners.slice(0);
        ori = new Rotation(a.alpha, a.beta, a.gamma, a.timestamp);
        for (var i = 0, l = tempListeners.length; i < l; i++) {
            tempListeners[i].win(ori);
        }
    }, function(e) {
        var tempListeners = listeners.slice(0);
        for (var i = 0, l = tempListeners.length; i < l; i++) {
            tempListeners[i].fail(e);
        }
    }, "Orientation", "start", []);
    running = true;
}

// Tells native to stop.
function stop() {
    exec(null, null, "Orientation", "stop", []);
    running = false;
}

// Adds a callback pair to the listeners array
function createCallbackPair(win, fail) {
    return {win:win, fail:fail};
}

// Removes a win/fail listener pair from the listeners array
function removeListeners(l) {
    var idx = listeners.indexOf(l);
    if (idx > -1) {
        listeners.splice(idx, 1);
        if (listeners.length === 0) {
            stop();
        }
    }
}
       
function orientationCB(event) {

       if(event.alpha == 360 && event.beta == 0 && event.gamma == 0) {
       //
       } else {
        if(ori != null && typeof ori !== 'undefined') {
            if(event.alpha == ori.alpha && event.beta == ori.beta && event.gamma == ori.gamma) {
       //
                return;
            }
        } 
        ori = new Rotation(event.alpha, event.beta, event.gamma);
        //console.log("alpha = " + event.alpha);
        //console.log("beta = " + event.beta);
        //console.log("gamma = " + event.gamma);
        successCB(ori);
        window.removeEventListener("deviceorientation", orientationCB,false);
    }       
};

var orientation = {
    /**
     * Asynchronously aquires the current rotation.
     *
     * @param {Function} successCallback    The function to call when the rotation data is available
     * @param {Function} errorCallback      The function to call when there is an error getting the rotation data. (OPTIONAL)
     * @param {OrientationOptions} options The options for getting the rotation data such as timeout. (OPTIONAL)
     */
    getCurrentOrientation: function(successCallback, errorCallback, options) {
        // successCallback required
        if (typeof successCallback !== "function") {
            throw "getCurrentOrientation must be called with at least a success callback function as first parameter.";
        }
       

       successCB = successCallback;       
       window.addEventListener("deviceorientation", orientationCB, false);

    },
    /**
     * Asynchronously aquires the rotation repeatedly at a given interval.
     *
     * @param {Function} successCallback    The function to call each time the rotation data is available
     * @param {Function} errorCallback      The function to call when there is an error getting the rotation data. (OPTIONAL)
     * @param {OrientationOptions} options The options for getting the rotation data such as timeout. (OPTIONAL)
     * @return String                       The watch id that must be passed to #clearWatch to stop watching.
     */
    watchOrientation: function(successCallback, errorCallback, options) {
        // Default interval (10 sec)
        var frequency = (options && options.frequency && typeof options.frequency == 'number') ? options.frequency : 10000;

        // successCallback required
        if (typeof successCallback !== "function") {
            throw "watchOrientation must be called with at least a success callback function as first parameter.";
        }

        // Keep reference to watch id, and report accel readings as often as defined in frequency
        var id = utils.createUUID();

        var p = createCallbackPair(function(){}, function(e) {
            errorCallback(e);
            removeListeners(p);
        });
        listeners.push(p);

        timers[id] = {
            timer:window.setInterval(function() {
                if (ori) {
                    successCallback(ori);
                }
            }, frequency),
            listeners:p
        };

        if (running) {
            // If we're already running then immediately invoke the success callback
            successCallback(accel);
        } else {
            start();
        }

        return id;
    },

    /**
     * Clears the specified accelerometer watch.
     *
     * @param {String} id       The id of the watch returned from #watchAcceleration.
     */
    clearWatch: function(id) {
        // Stop javascript timer & remove from timer list
        if (id && timers[id]) {
            window.clearInterval(timers[id].timer);
            removeListeners(timers[id].listeners);
            delete timers[id];
        }
    }

};

module.exports = orientation;

});

// file: lib/common/plugin/Camera.js
sktdefine("srt/plugin/Camera", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    Camera = sktrequire('srt/plugin/CameraConstants');

var cameraExport = {};

// Tack on the Camera Constants to the base camera plugin.
for (var key in Camera) {
    cameraExport[key] = Camera[key];
}

/**
 * Gets a picture from source defined by "options.sourceType", and returns the
 * image as defined by the "options.destinationType" option.

 * The defaults are sourceType=CAMERA and destinationType=FILE_URI.
 *
 * @param {Function} successCallback
 * @param {Function} errorCallback
 * @param {Object} options
 */
cameraExport.getPicture = function(successCallback, errorCallback, options) {
    // successCallback required
    if (typeof successCallback != "function") {
        console.log("Camera Error: successCallback is not a function");
        return;
    }

    // errorCallback optional
    if (errorCallback && (typeof errorCallback != "function")) {
        console.log("Camera Error: errorCallback is not a function");
        return;
    }

    var quality = 50;
    if (options && typeof options.quality == "number") {
        quality = options.quality;
    } else if (options && typeof options.quality == "string") {
        var qlity = parseInt(options.quality, 10);
        if (isNaN(qlity) === false) {
            quality = qlity.valueOf();
        }
    }

    var destinationType = Camera.DestinationType.FILE_URI;
    if (typeof options.destinationType == "number") {
        destinationType = options.destinationType;
    }

    var sourceType = Camera.PictureSourceType.CAMERA;
    if (typeof options.sourceType == "number") {
        sourceType = options.sourceType;
    }

    var targetWidth = -1;
    if (typeof options.targetWidth == "number") {
        targetWidth = options.targetWidth;
    } else if (typeof options.targetWidth == "string") {
        var width = parseInt(options.targetWidth, 10);
        if (isNaN(width) === false) {
            targetWidth = width.valueOf();
        }
    }

    var targetHeight = -1;
    if (typeof options.targetHeight == "number") {
        targetHeight = options.targetHeight;
    } else if (typeof options.targetHeight == "string") {
        var height = parseInt(options.targetHeight, 10);
        if (isNaN(height) === false) {
            targetHeight = height.valueOf();
        }
    }

    var encodingType = Camera.EncodingType.JPEG;
    if (typeof options.encodingType == "number") {
        encodingType = options.encodingType;
    }

    var mediaType = Camera.MediaType.PICTURE;
    if (typeof options.mediaType == "number") {
        mediaType = options.mediaType;
    }
    var allowEdit = false;
    if (typeof options.allowEdit == "boolean") {
        allowEdit = options.allowEdit;
    } else if (typeof options.allowEdit == "number") {
        allowEdit = options.allowEdit <= 0 ? false : true;
    }
    var correctOrientation = false;
    if (typeof options.correctOrientation == "boolean") {
        correctOrientation = options.correctOrientation;
    } else if (typeof options.correctOrientation == "number") {
        correctOrientation = options.correctOrientation <=0 ? false : true;
    }
    var saveToPhotoAlbum = false;
    if (typeof options.saveToPhotoAlbum == "boolean") {
        saveToPhotoAlbum = options.saveToPhotoAlbum;
    } else if (typeof options.saveToPhotoAlbum == "number") {
        saveToPhotoAlbum = options.saveToPhotoAlbum <=0 ? false : true;
    }
    var popoverOptions = null;
    if (typeof options.popoverOptions == "object") {
        popoverOptions = options.popoverOptions;
    }

    exec(successCallback, errorCallback, "Camera", "takePicture", [quality, destinationType, sourceType, targetWidth, targetHeight, encodingType, mediaType, allowEdit, correctOrientation, saveToPhotoAlbum, popoverOptions]);
};

module.exports = cameraExport;
});

// file: lib/common/plugin/CameraConstants.js
sktdefine("srt/plugin/CameraConstants", function(sktrequire, exports, module) {
module.exports = {
  DestinationType:{
    DATA_URL: 0,         // Return base64 encoded string
    FILE_URI: 1          // Return file uri (content://media/external/images/media/2 for Android)
  },
  EncodingType:{
    JPEG: 0,             // Return JPEG encoded image
    PNG: 1               // Return PNG encoded image
  },
  MediaType:{
    PICTURE: 0,          // allow selection of still pictures only. DEFAULT. Will return format specified via DestinationType
    VIDEO: 1,            // allow selection of video only, ONLY RETURNS URL
    ALLMEDIA : 2         // allow selection from all media types
  },
  PictureSourceType:{
    PHOTOLIBRARY : 0,    // Choose image from picture library (same as SAVEDPHOTOALBUM for Android)
    CAMERA : 1,          // Take picture from camera
    SAVEDPHOTOALBUM : 2  // Choose image from picture library (same as PHOTOLIBRARY for Android)
  },
  PopoverArrowDirection:{
      ARROW_UP : 1,        // matches iOS UIPopoverArrowDirection constants to specify arrow location on popover
      ARROW_DOWN : 2,
      ARROW_LEFT : 4,
      ARROW_RIGHT : 8,
      ARROW_ANY : 15
  }
};
});

// file: lib/common/plugin/CameraPopoverOptions.js
sktdefine("srt/plugin/CameraPopoverOptions", function(sktrequire, exports, module) {
var Camera = sktrequire('srt/plugin/CameraConstants');

/**
 * Encapsulates options for iOS Popover image picker
 */
var CameraPopoverOptions = function(x,y,width,height,arrowDir){
    // information of rectangle that popover should be anchored to
    this.x = x || 0;
    this.y = y || 32;
    this.width = width || 320;
    this.height = height || 480;
    // The direction of the popover arrow
    this.arrowDir = arrowDir || Camera.PopoverArrowDirection.ARROW_ANY;
};

module.exports = CameraPopoverOptions;
});

// file: lib/common/plugin/CaptureAudioOptions.js
sktdefine("srt/plugin/CaptureAudioOptions", function(sktrequire, exports, module) {
/**
 * Encapsulates all audio capture operation configuration options.
 */
var CaptureAudioOptions = function(){
    // Upper limit of sound clips user can record. Value must be equal or greater than 1.
    this.limit = 1;
    // Maximum duration of a single sound clip in seconds.
    this.duration = 0;
    // The selected audio mode. Must match with one of the elements in supportedAudioModes array.
    this.mode = null;
};

module.exports = CaptureAudioOptions;
});

// file: lib/common/plugin/CaptureError.js
sktdefine("srt/plugin/CaptureError", function(sktrequire, exports, module) {
/**
 * The CaptureError interface encapsulates all errors in the Capture API.
 */
var CaptureError = function(c) {
   this.code = c || null;
};

// Camera or microphone failed to capture image or sound.
CaptureError.CAPTURE_INTERNAL_ERR = 0;
// Camera application or audio capture application is currently serving other capture request.
CaptureError.CAPTURE_APPLICATION_BUSY = 1;
// Invalid use of the API (e.g. limit parameter has value less than one).
CaptureError.CAPTURE_INVALID_ARGUMENT = 2;
// User exited camera application or audio capture application before capturing anything.
CaptureError.CAPTURE_NO_MEDIA_FILES = 3;
// The requested capture operation is not supported.
CaptureError.CAPTURE_NOT_SUPPORTED = 20;

module.exports = CaptureError;
});

// file: lib/common/plugin/CaptureImageOptions.js
sktdefine("srt/plugin/CaptureImageOptions", function(sktrequire, exports, module) {
/**
 * Encapsulates all image capture operation configuration options.
 */
var CaptureImageOptions = function(){
    // Upper limit of images user can take. Value must be equal or greater than 1.
    this.limit = 1;
    // The selected image mode. Must match with one of the elements in supportedImageModes array.
    this.mode = null;
};

module.exports = CaptureImageOptions;
});

// file: lib/common/plugin/CaptureVideoOptions.js
sktdefine("srt/plugin/CaptureVideoOptions", function(sktrequire, exports, module) {
/**
 * Encapsulates all video capture operation configuration options.
 */
var CaptureVideoOptions = function(){
    // Upper limit of videos user can record. Value must be equal or greater than 1.
    this.limit = 1;
    // Maximum duration of a single video clip in seconds.
    this.duration = 0;
    // The selected video mode. Must match with one of the elements in supportedVideoModes array.
    this.mode = null;
};

module.exports = CaptureVideoOptions;
});

// file: lib/common/plugin/CompassError.js
sktdefine("srt/plugin/CompassError", function(sktrequire, exports, module) {
/**
 *  CompassError.
 *  An error code assigned by an implementation when an error has occured
 * @constructor
 */
var CompassError = function(err) {
    this.code = (err !== undefined ? err : null);
};

CompassError.COMPASS_INTERNAL_ERR = 0;
CompassError.COMPASS_NOT_SUPPORTED = 20;

module.exports = CompassError;
});

// file: lib/common/plugin/CompassHeading.js
sktdefine("srt/plugin/CompassHeading", function(sktrequire, exports, module) {
var CompassHeading = function(magneticHeading, trueHeading, headingAccuracy, timestamp) {
  this.magneticHeading = (magneticHeading !== undefined ? magneticHeading : null);
  this.trueHeading = (trueHeading !== undefined ? trueHeading : null);
  this.headingAccuracy = (headingAccuracy !== undefined ? headingAccuracy : null);
  this.timestamp = (timestamp !== undefined ? timestamp : new Date().getTime());
};

module.exports = CompassHeading;
});

// file: lib/common/plugin/ConfigurationData.js
sktdefine("srt/plugin/ConfigurationData", function(sktrequire, exports, module) {
/**
 * Encapsulates a set of parameters that the capture device supports.
 */
function ConfigurationData() {
    // The ASCII-encoded string in lower case representing the media type.
    this.type = null;
    // The height attribute represents height of the image or video in pixels.
    // In the case of a sound clip this attribute has value 0.
    this.height = 0;
    // The width attribute represents width of the image or video in pixels.
    // In the case of a sound clip this attribute has value 0
    this.width = 0;
}

module.exports = ConfigurationData;
});

//[20120619][chisu]remove Connection used in Cordova
// file: lib/common/plugin/Connection.js
//sktdefine("srt/plugin/Connection", function(sktrequire, exports, module) {
///**
// * Network status
// */
//module.exports = {
//        UNKNOWN: "unknown",
//        ETHERNET: "ethernet",
//        WIFI: "wifi",
//        CELL_2G: "2g",
//        CELL_3G: "3g",
//        CELL_4G: "4g",
//        NONE: "none"
//};
//});

// file: lib/common/plugin/Contact.js
sktdefine("srt/plugin/Contact", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    ContactError = sktrequire('srt/plugin/ContactError'),
    utils = sktrequire('srt/utils');

/**
* Converts primitives into Complex Object
* Currently only used for Date fields
*/
function convertIn(contact) {
    var value = contact.birthday;
    try {
      contact.birthday = new Date(parseFloat(value));
    } catch (exception){
      console.log("Cordova Contact convertIn error: exception creating date.");
    }
    return contact;
}

/**
* Converts Complex objects into primitives
* Only conversion at present is for Dates.
**/

function convertOut(contact) {
    var value = contact.birthday;
    if (value !== null) {
        // try to make it a Date object if it is not already
        if (!utils.isDate(value)){
            try {
                value = new Date(value);
            } catch(exception){
                value = null;
            }
        }
        if (utils.isDate(value)){
            value = value.valueOf(); // convert to milliseconds
        }
        contact.birthday = value;
    }
    return contact;
}

/**
* Contains information about a single contact.
* @constructor
* @param {DOMString} id unique identifier
* @param {DOMString} displayName
* @param {ContactName} name
* @param {DOMString} nickname
* @param {Array.<ContactField>} phoneNumbers array of phone numbers
* @param {Array.<ContactField>} emails array of email addresses
* @param {Array.<ContactAddress>} addresses array of addresses
* @param {Array.<ContactField>} ims instant messaging user ids
* @param {Array.<ContactOrganization>} organizations
* @param {DOMString} birthday contact's birthday
* @param {DOMString} note user notes about contact
* @param {Array.<ContactField>} photos
* @param {Array.<ContactField>} categories
* @param {Array.<ContactField>} urls contact's web sites
*/
var Contact = function (id, displayName, name, nickname, phoneNumbers, emails, addresses,
    ims, organizations, birthday, note, photos, categories, urls) {
    this.id = id || null;
    this.rawId = null;
    this.displayName = displayName || null;
    this.name = name || null; // ContactName
    this.nickname = nickname || null;
    this.phoneNumbers = phoneNumbers || null; // ContactField[]
    this.emails = emails || null; // ContactField[]
    this.addresses = addresses || null; // ContactAddress[]
    this.ims = ims || null; // ContactField[]
    this.organizations = organizations || null; // ContactOrganization[]
    this.birthday = birthday || null;
    this.note = note || null;
    this.photos = photos || null; // ContactField[]
    this.categories = categories || null; // ContactField[]
    this.urls = urls || null; // ContactField[]
};

//[20120622][chisu]not used in SKT Runtime
///**
//* Removes contact from device storage.
//* @param successCB success callback
//* @param errorCB error callback
//*/
//Contact.prototype.remove = function(successCB, errorCB) {
//    var fail = function(code) {
//        errorCB(new ContactError(code));
//    };
//    if (this.id === null) {
//        fail(ContactError.UNKNOWN_ERROR);
//    }
//    else {
//        exec(successCB, fail, "Contacts", "remove", [this.id]);
//    }
//};

/**
* Creates a deep copy of this Contact.
* With the contact ID set to null.
* @return copy of this Contact
*/
Contact.prototype.clone = function() {
    var clonedContact = utils.clone(this);
    var i;
    clonedContact.id = null;
    clonedContact.rawId = null;
    // Loop through and clear out any id's in phones, emails, etc.
    if (clonedContact.phoneNumbers) {
        for (i = 0; i < clonedContact.phoneNumbers.length; i++) {
            clonedContact.phoneNumbers[i].id = null;
        }
    }
    if (clonedContact.emails) {
        for (i = 0; i < clonedContact.emails.length; i++) {
            clonedContact.emails[i].id = null;
        }
    }
    if (clonedContact.addresses) {
        for (i = 0; i < clonedContact.addresses.length; i++) {
            clonedContact.addresses[i].id = null;
        }
    }
    if (clonedContact.ims) {
        for (i = 0; i < clonedContact.ims.length; i++) {
            clonedContact.ims[i].id = null;
        }
    }
    if (clonedContact.organizations) {
        for (i = 0; i < clonedContact.organizations.length; i++) {
            clonedContact.organizations[i].id = null;
        }
    }
    if (clonedContact.categories) {
        for (i = 0; i < clonedContact.categories.length; i++) {
            clonedContact.categories[i].id = null;
        }
    }
    if (clonedContact.photos) {
        for (i = 0; i < clonedContact.photos.length; i++) {
            clonedContact.photos[i].id = null;
        }
    }
    if (clonedContact.urls) {
        for (i = 0; i < clonedContact.urls.length; i++) {
            clonedContact.urls[i].id = null;
        }
    }
    return clonedContact;
};

//[20120622][chisu]not used in SKT Runtime
///**
//* Persists contact to device storage.
//* @param successCB success callback
//* @param errorCB error callback
//*/
//Contact.prototype.save = function(successCB, errorCB) {
//  var fail = function(code) {
//      errorCB(new ContactError(code));
//  };
//    var success = function(result) {
//      if (result) {
//          if (typeof successCB === 'function') {
//              var fullContact = sktrequire('srt/plugin/contacts').create(result);
//              successCB(convertIn(fullContact));
//          }
//      }
//      else {
//          // no Entry object returned
//          fail(ContactError.UNKNOWN_ERROR);
//      }
//  };
//    var dupContact = convertOut(utils.clone(this));
//    exec(success, fail, "Contacts", "save", [dupContact]);
//};


module.exports = Contact;

});

// file: lib/common/plugin/ContactAddress.js
sktdefine("srt/plugin/ContactAddress", function(sktrequire, exports, module) {
/**
* Contact address.
* @constructor
* @param {DOMString} id unique identifier, should only be set by native code
* @param formatted // NOTE: not a W3C standard
* @param streetAddress
* @param locality
* @param region
* @param postalCode
* @param country
*/

var ContactAddress = function(pref, type, formatted, streetAddress, locality, region, postalCode, country) {
    this.id = null;
    this.pref = (typeof pref != 'undefined' ? pref : false);
    this.type = type || null;
    this.formatted = formatted || null;
    this.streetAddress = streetAddress || null;
    this.locality = locality || null;
    this.region = region || null;
    this.postalCode = postalCode || null;
    this.country = country || null;
};

module.exports = ContactAddress;
});

// file: lib/common/plugin/ContactError.js
sktdefine("srt/plugin/ContactError", function(sktrequire, exports, module) {
/**
 *  ContactError.
 *  An error code assigned by an implementation when an error has occured
 * @constructor
 */
var ContactError = function(err) {
    this.code = (typeof err != 'undefined' ? err : null);
};

/**
 * Error codes
 */
ContactError.UNKNOWN_ERROR = 0;
ContactError.INVALID_ARGUMENT_ERROR = 1;
ContactError.TIMEOUT_ERROR = 2;
ContactError.PENDING_OPERATION_ERROR = 3;
ContactError.IO_ERROR = 4;
ContactError.NOT_SUPPORTED_ERROR = 5;
ContactError.PERMISSION_DENIED_ERROR = 20;

module.exports = ContactError;
});

// file: lib/common/plugin/ContactField.js
sktdefine("srt/plugin/ContactField", function(sktrequire, exports, module) {
/**
* Generic contact field.
* @constructor
* @param {DOMString} id unique identifier, should only be set by native code // NOTE: not a W3C standard
* @param type
* @param value
* @param pref
*/
var ContactField = function(type, value, pref) {
    this.id = null;
    this.type = (type && type.toString()) || null;
    this.value = (value && value.toString()) || null;
    this.pref = (typeof pref != 'undefined' ? pref : false);
};

module.exports = ContactField;
});

// file: lib/common/plugin/ContactFindOptions.js
sktdefine("srt/plugin/ContactFindOptions", function(sktrequire, exports, module) {
/**
 * ContactFindOptions.
 * @constructor
 * @param filter used to match contacts against
 * @param multiple boolean used to determine if more than one contact should be returned
 */

var ContactFindOptions = function(filter, multiple) {
    this.filter = filter || '';
    this.multiple = (typeof multiple != 'undefined' ? multiple : false);
};

module.exports = ContactFindOptions;
});

// file: lib/common/plugin/ContactName.js
sktdefine("srt/plugin/ContactName", function(sktrequire, exports, module) {
/**
* Contact name.
* @constructor
* @param formatted // NOTE: not part of W3C standard
* @param familyName
* @param givenName
* @param middle
* @param prefix
* @param suffix
*/
var ContactName = function(formatted, familyName, givenName, middle, prefix, suffix) {
    this.formatted = formatted || null;
    this.familyName = familyName || null;
    this.givenName = givenName || null;
    this.middleName = middle || null;
    this.honorificPrefix = prefix || null;
    this.honorificSuffix = suffix || null;
};

module.exports = ContactName;
});

// file: lib/common/plugin/ContactOrganization.js
sktdefine("srt/plugin/ContactOrganization", function(sktrequire, exports, module) {
/**
* Contact organization.
* @constructor
* @param {DOMString} id unique identifier, should only be set by native code // NOTE: not a W3C standard
* @param name
* @param dept
* @param title
* @param startDate
* @param endDate
* @param location
* @param desc
*/

var ContactOrganization = function(pref, type, name, dept, title) {
    this.id = null;
    this.pref = (typeof pref != 'undefined' ? pref : false);
    this.type = type || null;
    this.name = name || null;
    this.department = dept || null;
    this.title = title || null;
};

module.exports = ContactOrganization;
});

// file: lib/common/plugin/Coordinates.js
sktdefine("srt/plugin/Coordinates", function(sktrequire, exports, module) {
/**
 * This class contains position information.
 * @param {Object} lat
 * @param {Object} lng
 * @param {Object} alt
 * @param {Object} acc
 * @param {Object} head
 * @param {Object} vel
 * @param {Object} altacc
 * @constructor
 */
var Coordinates = function(lat, lng, alt, acc, head, vel, altacc) {
    /**
     * The latitude of the position.
     */
    this.latitude = lat;
    /**
     * The longitude of the position,
     */
    this.longitude = lng;
    /**
     * The accuracy of the position.
     */
    this.accuracy = acc;
    /**
     * The altitude of the position.
     */
    this.altitude = (alt !== undefined ? alt : null);
    /**
     * The direction the device is moving at the position.
     */
    this.heading = (head !== undefined ? head : null);
    /**
     * The velocity with which the device is moving at the position.
     */
    this.speed = (vel !== undefined ? vel : null);

    if (this.speed === 0 || this.speed === null) {
        this.heading = NaN;
    }

    /**
     * The altitude accuracy of the position.
     */
    this.altitudeAccuracy = (altacc !== undefined) ? altacc : null;
};

module.exports = Coordinates;

});

// file: lib/common/plugin/DirectoryEntry.js
sktdefine("srt/plugin/DirectoryEntry", function(sktrequire, exports, module) {
var utils = sktrequire('srt/utils'),
    exec = sktrequire('srt/exec'),
    Entry = sktrequire('srt/plugin/Entry'),
    FileError = sktrequire('srt/plugin/FileError'),
    DirectoryReader = sktrequire('srt/plugin/DirectoryReader');

/**
 * An interface representing a directory on the file system.
 *
 * {boolean} isFile always false (readonly)
 * {boolean} isDirectory always true (readonly)
 * {DOMString} name of the directory, excluding the path leading to it (readonly)
 * {DOMString} fullPath the absolute full path to the directory (readonly)
 * {FileSystem} filesystem on which the directory resides (readonly)
 */
var DirectoryEntry = function(name, fullPath) {
     DirectoryEntry.__super__.constructor.apply(this, [false, true, name, fullPath]);
};

utils.extend(DirectoryEntry, Entry);

/**
 * Creates a new DirectoryReader to read entries from this directory
 */
DirectoryEntry.prototype.createReader = function() {
    return new DirectoryReader(this.fullPath);
};

/**
 * Creates or looks up a directory
 *
 * @param {DOMString} path either a relative or absolute path from this directory in which to look up or create a directory
 * @param {Flags} options to create or excluively create the directory
 * @param {Function} successCallback is called with the new entry
 * @param {Function} errorCallback is called with a FileError
 */
DirectoryEntry.prototype.getDirectory = function(path, options, successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var entry = new DirectoryEntry(result.name, result.fullPath);
        successCallback(entry);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, "File", "getDirectory", [this.fullPath, path, options]);
};

/**
 * Deletes a directory and all of it's contents
 *
 * @param {Function} successCallback is called with no parameters
 * @param {Function} errorCallback is called with a FileError
 */
DirectoryEntry.prototype.removeRecursively = function(successCallback, errorCallback) {
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(successCallback, fail, "File", "removeRecursively", [this.fullPath]);
};

/**
 * Creates or looks up a file
 *
 * @param {DOMString} path either a relative or absolute path from this directory in which to look up or create a file
 * @param {Flags} options to create or excluively create the file
 * @param {Function} successCallback is called with the new entry
 * @param {Function} errorCallback is called with a FileError
 */
DirectoryEntry.prototype.getFile = function(path, options, successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var FileEntry = sktrequire('srt/plugin/FileEntry');
        var entry = new FileEntry(result.name, result.fullPath);
        successCallback(entry);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, "File", "getFile", [this.fullPath, path, options]);
};

module.exports = DirectoryEntry;

});

// file: lib/common/plugin/DirectoryReader.js
sktdefine("srt/plugin/DirectoryReader", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    FileError = sktrequire('srt/plugin/FileError') ;

/**
 * An interface that lists the files and directories in a directory.
 */
function DirectoryReader(path) {
    this.path = path || null;
}

/**
 * Returns a list of entries from a directory.
 *
 * @param {Function} successCallback is called with a list of entries
 * @param {Function} errorCallback is called with a FileError
 */
DirectoryReader.prototype.readEntries = function(successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var retVal = [];
        for (var i=0; i<result.length; i++) {
            var entry = null;
            if (result[i].isDirectory) {
                entry = new (sktrequire('srt/plugin/DirectoryEntry'))();
            }
            else if (result[i].isFile) {
                entry = new (sktrequire('srt/plugin/FileEntry'))();
            }
            entry.isDirectory = result[i].isDirectory;
            entry.isFile = result[i].isFile;
            entry.name = result[i].name;
            entry.fullPath = result[i].fullPath;
            retVal.push(entry);
        }
        successCallback(retVal);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, "File", "readEntries", [this.path]);
};

module.exports = DirectoryReader;

});

// file: lib/common/plugin/Entry.js
sktdefine("srt/plugin/Entry", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    FileError = sktrequire('srt/plugin/FileError'),
    Metadata = sktrequire('srt/plugin/Metadata');

/**
 * Represents a file or directory on the local file system.
 *
 * @param isFile
 *            {boolean} true if Entry is a file (readonly)
 * @param isDirectory
 *            {boolean} true if Entry is a directory (readonly)
 * @param name
 *            {DOMString} name of the file or directory, excluding the path
 *            leading to it (readonly)
 * @param fullPath
 *            {DOMString} the absolute full path to the file or directory
 *            (readonly)
 */
function Entry(isFile, isDirectory, name, fullPath, fileSystem) {
    this.isFile = (typeof isFile != 'undefined'?isFile:false);
    this.isDirectory = (typeof isDirectory != 'undefined'?isDirectory:false);
    this.name = name || '';
    this.fullPath = fullPath || '';
    this.filesystem = fileSystem || null;
}

/**
 * Look up the metadata of the entry.
 *
 * @param successCallback
 *            {Function} is called with a Metadata object
 * @param errorCallback
 *            {Function} is called with a FileError
 */
Entry.prototype.getMetadata = function(successCallback, errorCallback) {
  var success = typeof successCallback !== 'function' ? null : function(metadata) {
	  //[20120703][chisu]modify metadata size 
      var metadata = new Metadata(metadata.lastModified,metadata.size);
      successCallback(metadata);
  };
  var fail = typeof errorCallback !== 'function' ? null : function(code) {
      errorCallback(new FileError(code));
  };

  exec(success, fail, "File", "getMetadata", [this.fullPath]);
};

/**
 * Set the metadata of the entry.
 *
 * @param successCallback
 *            {Function} is called with a Metadata object
 * @param errorCallback
 *            {Function} is called with a FileError
 * @param metadataObject
 *            {Object} keys and values to set
 */
Entry.prototype.setMetadata = function(successCallback, errorCallback, metadataObject) {

  exec(successCallback, errorCallback, "File", "setMetadata", [this.fullPath, metadataObject]);
};

/**
 * Move a file or directory to a new location.
 *
 * @param parent
 *            {DirectoryEntry} the directory to which to move this entry
 * @param newName
 *            {DOMString} new name of the entry, defaults to the current name
 * @param successCallback
 *            {Function} called with the new DirectoryEntry object
 * @param errorCallback
 *            {Function} called with a FileError
 */
Entry.prototype.moveTo = function(parent, newName, successCallback, errorCallback) {
    var fail = function(code) {
        if (typeof errorCallback === 'function') {
            errorCallback(new FileError(code));
        }
    };
    // user must specify parent Entry
    if (!parent) {
        fail(FileError.NOT_FOUND_ERR);
        return;
    }
    // source path
    var srcPath = this.fullPath,
        // entry name
        name = newName || this.name,
        success = function(entry) {
            if (entry) {
                if (typeof successCallback === 'function') {
                    // create appropriate Entry object
                    var result = (entry.isDirectory) ? new (sktrequire('srt/plugin/DirectoryEntry'))(entry.name, entry.fullPath) : new (sktrequire('srt/plugin/FileEntry'))(entry.name, entry.fullPath);
                    try {
                        successCallback(result);
                    }
                    catch (e) {
                        console.log('Error invoking callback: ' + e);
                    }
                }
            }
            else {
                // no Entry object returned
                fail(FileError.NOT_FOUND_ERR);
            }
        };

    // copy
    exec(success, fail, "File", "moveTo", [srcPath, parent.fullPath, name]);
};

/**
 * Copy a directory to a different location.
 *
 * @param parent
 *            {DirectoryEntry} the directory to which to copy the entry
 * @param newName
 *            {DOMString} new name of the entry, defaults to the current name
 * @param successCallback
 *            {Function} called with the new Entry object
 * @param errorCallback
 *            {Function} called with a FileError
 */
Entry.prototype.copyTo = function(parent, newName, successCallback, errorCallback) {
    var fail = function(code) {
        if (typeof errorCallback === 'function') {
            errorCallback(new FileError(code));
        }
    };

    // user must specify parent Entry
    if (!parent) {
        fail(FileError.NOT_FOUND_ERR);
        return;
    }

        // source path
    var srcPath = this.fullPath,
        // entry name
        name = newName || this.name,
        // success callback
        success = function(entry) {
            if (entry) {
                if (typeof successCallback === 'function') {
                    // create appropriate Entry object
                    var result = (entry.isDirectory) ? new (sktrequire('srt/plugin/DirectoryEntry'))(entry.name, entry.fullPath) : new (sktrequire('srt/plugin/FileEntry'))(entry.name, entry.fullPath);
                    try {
                        successCallback(result);
                    }
                    catch (e) {
                        console.log('Error invoking callback: ' + e);
                    }
                }
            }
            else {
                // no Entry object returned
                fail(FileError.NOT_FOUND_ERR);
            }
        };

    // copy
    exec(success, fail, "File", "copyTo", [srcPath, parent.fullPath, name]);
};

/**
 * Return a URL that can be used to identify this entry.
 */
Entry.prototype.toURL = function() {
    // fullPath attribute contains the full URL
    return this.fullPath;
};

/**
 * Returns a URI that can be used to identify this entry.
 *
 * @param {DOMString} mimeType for a FileEntry, the mime type to be used to interpret the file, when loaded through this URI.
 * @return uri
 */
Entry.prototype.toURI = function(mimeType) {
    console.log("DEPRECATED: Update your code to use 'toURL'");
    // fullPath attribute contains the full URI
    return this.toURL();
};

/**
 * Remove a file or directory. It is an error to attempt to delete a
 * directory that is not empty. It is an error to attempt to delete a
 * root directory of a file system.
 *
 * @param successCallback {Function} called with no parameters
 * @param errorCallback {Function} called with a FileError
 */
Entry.prototype.remove = function(successCallback, errorCallback) {
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(successCallback, fail, "File", "remove", [this.fullPath]);
};

/**
 * Look up the parent DirectoryEntry of this entry.
 *
 * @param successCallback {Function} called with the parent DirectoryEntry object
 * @param errorCallback {Function} called with a FileError
 */
Entry.prototype.getParent = function(successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(result) {
        var DirectoryEntry = sktrequire('srt/plugin/DirectoryEntry');
        var entry = new DirectoryEntry(result.name, result.fullPath);
        successCallback(entry);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, "File", "getParent", [this.fullPath]);
};

module.exports = Entry;
});

// file: lib/common/plugin/File.js
sktdefine("srt/plugin/File", function(sktrequire, exports, module) {
/**
 * Constructor.
 * name {DOMString} name of the file, without path information
 * fullPath {DOMString} the full path of the file, including the name
 * type {DOMString} mime type
 * lastModifiedDate {Date} last modified date
 * size {Number} size of the file in bytes
 */

var File = function(name, fullPath, type, lastModifiedDate, size){
    this.name = name || '';
    this.fullPath = fullPath || null;
    this.type = type || null;
    this.lastModifiedDate = lastModifiedDate || null;
    this.size = size || 0;
};

module.exports = File;
});

// file: lib/common/plugin/FileEntry.js
sktdefine("srt/plugin/FileEntry", function(sktrequire, exports, module) {
var utils = sktrequire('srt/utils'),
    exec = sktrequire('srt/exec'),
    Entry = sktrequire('srt/plugin/Entry'),
    FileWriter = sktrequire('srt/plugin/FileWriter'),
    File = sktrequire('srt/plugin/File'),
    FileError = sktrequire('srt/plugin/FileError');

/**
 * An interface representing a file on the file system.
 *
 * {boolean} isFile always true (readonly)
 * {boolean} isDirectory always false (readonly)
 * {DOMString} name of the file, excluding the path leading to it (readonly)
 * {DOMString} fullPath the absolute full path to the file (readonly)
 * {FileSystem} filesystem on which the file resides (readonly)
 */
var FileEntry = function(name, fullPath) {
     FileEntry.__super__.constructor.apply(this, [true, false, name, fullPath]);
};

utils.extend(FileEntry, Entry);

/**
 * Creates a new FileWriter associated with the file that this FileEntry represents.
 *
 * @param {Function} successCallback is called with the new FileWriter
 * @param {Function} errorCallback is called with a FileError
 */
FileEntry.prototype.createWriter = function(successCallback, errorCallback) {
    this.file(function(filePointer) {
        var writer = new FileWriter(filePointer);

        if (writer.fileName === null || writer.fileName === "") {
            if (typeof errorCallback === "function") {
                errorCallback(new FileError(FileError.INVALID_STATE_ERR));
            }
        } else {
            if (typeof successCallback === "function") {
                successCallback(writer);
            }
        }
    }, errorCallback);
};

/**
 * Returns a File that represents the current state of the file that this FileEntry represents.
 *
 * @param {Function} successCallback is called with the new File object
 * @param {Function} errorCallback is called with a FileError
 */
FileEntry.prototype.file = function(successCallback, errorCallback) {
    var win = typeof successCallback !== 'function' ? null : function(f) {
        var file = new File(f.name, f.fullPath, f.type, f.lastModifiedDate, f.size);
        successCallback(file);
    };
    var fail = typeof errorCallback !== 'function' ? null : function(code) {
        errorCallback(new FileError(code));
    };
    exec(win, fail, "File", "getFileMetadata", [this.fullPath]);
};


module.exports = FileEntry;
});

// file: lib/common/plugin/FileError.js
sktdefine("srt/plugin/FileError", function(sktrequire, exports, module) {
/**
 * FileError
 */
function FileError(error) {
  this.code = error || null;
}

// File error codes
// Found in DOMException
FileError.NOT_FOUND_ERR = 1;
FileError.SECURITY_ERR = 2;
FileError.ABORT_ERR = 3;

// Added by File API specification
FileError.NOT_READABLE_ERR = 4;
FileError.ENCODING_ERR = 5;
FileError.NO_MODIFICATION_ALLOWED_ERR = 6;
FileError.INVALID_STATE_ERR = 7;
FileError.SYNTAX_ERR = 8;
FileError.INVALID_MODIFICATION_ERR = 9;
FileError.QUOTA_EXCEEDED_ERR = 10;
FileError.TYPE_MISMATCH_ERR = 11;
FileError.PATH_EXISTS_ERR = 12;

module.exports = FileError;
});

// file: lib/common/plugin/FileReader.js
sktdefine("srt/plugin/FileReader", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    FileError = sktrequire('srt/plugin/FileError'),
    ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

/**
 * This class reads the mobile device file system.
 *
 * For Android:
 *      The root directory is the root of the file system.
 *      To read from the SD card, the file name is "sdcard/my_file.txt"
 * @constructor
 */
var FileReader = function() {
    this.fileName = "";

    this.readyState = 0; // FileReader.EMPTY

    // File data
    this.result = null;

    // Error
    this.error = null;

    // Event handlers
    this.onloadstart = null;    // When the read starts.
    this.onprogress = null;     // While reading (and decoding) file or fileBlob data, and reporting partial file data (progess.loaded/progress.total)
    this.onload = null;         // When the read has successfully completed.
    this.onerror = null;        // When the read has failed (see errors).
    this.onloadend = null;      // When the request has completed (either in success or failure).
    this.onabort = null;        // When the read has been aborted. For instance, by invoking the abort() method.
};

// States
FileReader.EMPTY = 0;
FileReader.LOADING = 1;
FileReader.DONE = 2;

/**
 * Abort reading file.
 */
FileReader.prototype.abort = function() {
    this.result = null;

    if (this.readyState == FileReader.DONE || this.readyState == FileReader.EMPTY) {
      return;
    }

    this.readyState = FileReader.DONE;

    // If abort callback
    if (typeof this.onabort === 'function') {
        this.onabort(new ProgressEvent('abort', {target:this}));
    }
    // If load end callback
    if (typeof this.onloadend === 'function') {
        this.onloadend(new ProgressEvent('loadend', {target:this}));
    }
};

/**
 * Read text file.
 *
 * @param file          {File} File object containing file properties
 * @param encoding      [Optional] (see http://www.iana.org/assignments/character-sets)
 */
FileReader.prototype.readAsText = function(file, encoding) {
    // Figure out pathing
    this.fileName = '';
    if (typeof file.fullPath === 'undefined') {
        this.fileName = file;
    } else {
        this.fileName = file.fullPath;
    }

    // Already loading something
    if (this.readyState == FileReader.LOADING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    // LOADING state
    this.readyState = FileReader.LOADING;

    // If loadstart callback
    if (typeof this.onloadstart === "function") {
        this.onloadstart(new ProgressEvent("loadstart", {target:this}));
    }

    // Default encoding is UTF-8
    var enc = encoding ? encoding : "UTF-8";

    var me = this;

    // Read file
    exec(
        // Success callback
        function(r) {
            // If DONE (cancelled), then don't do anything
            if (me.readyState === FileReader.DONE) {
                return;
            }

            // Save result
            me.result = r;

            // If onload callback
            if (typeof me.onload === "function") {
                me.onload(new ProgressEvent("load", {target:me}));
            }

            // DONE state
            me.readyState = FileReader.DONE;

            // If onloadend callback
            if (typeof me.onloadend === "function") {
                me.onloadend(new ProgressEvent("loadend", {target:me}));
            }
        },
        // Error callback
        function(e) {
            // If DONE (cancelled), then don't do anything
            if (me.readyState === FileReader.DONE) {
                return;
            }

            // DONE state
            me.readyState = FileReader.DONE;

            // null result
            me.result = null;

            // Save error
            me.error = new FileError(e);

            // If onerror callback
            if (typeof me.onerror === "function") {
                me.onerror(new ProgressEvent("error", {target:me}));
            }

            // If onloadend callback
            if (typeof me.onloadend === "function") {
                me.onloadend(new ProgressEvent("loadend", {target:me}));
            }
        }, "File", "readAsText", [this.fileName, enc]);
    
    //[20120706][chisu]add progress event
    // If progress callback
    if (typeof this.onprogress === "function") {
        this.onprogress(new ProgressEvent("progress", {target:this}));
    }
};


/**
 * Read file and return data as a base64 encoded data url.
 * A data url is of the form:
 *      data:[<mediatype>][;base64],<data>
 *
 * @param file          {File} File object containing file properties
 */
FileReader.prototype.readAsDataURL = function(file) {
    this.fileName = "";
    if (typeof file.fullPath === "undefined") {
        this.fileName = file;
    } else {
        this.fileName = file.fullPath;
    }

    // Already loading something
    if (this.readyState == FileReader.LOADING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    // LOADING state
    this.readyState = FileReader.LOADING;

    // If loadstart callback
    if (typeof this.onloadstart === "function") {
        this.onloadstart(new ProgressEvent("loadstart", {target:this}));
    }

    var me = this;

    // Read file
    exec(
        // Success callback
        function(r) {
            // If DONE (cancelled), then don't do anything
            if (me.readyState === FileReader.DONE) {
                return;
            }

            // DONE state
            me.readyState = FileReader.DONE;

            // Save result
            me.result = r;

            // If onload callback
            if (typeof me.onload === "function") {
                me.onload(new ProgressEvent("load", {target:me}));
            }

            // If onloadend callback
            if (typeof me.onloadend === "function") {
                me.onloadend(new ProgressEvent("loadend", {target:me}));
            }
        },
        // Error callback
        function(e) {
            // If DONE (cancelled), then don't do anything
            if (me.readyState === FileReader.DONE) {
                return;
            }

            // DONE state
            me.readyState = FileReader.DONE;

            me.result = null;

            // Save error
            me.error = new FileError(e);

            // If onerror callback
            if (typeof me.onerror === "function") {
                me.onerror(new ProgressEvent("error", {target:me}));
            }

            // If onloadend callback
            if (typeof me.onloadend === "function") {
                me.onloadend(new ProgressEvent("loadend", {target:me}));
            }
        }, "File", "readAsDataURL", [this.fileName]);
    //[20120706][chisu]add progress event
    // If progress callback
    if (typeof this.onprogress === "function") {
        this.onprogress(new ProgressEvent("progress", {target:this}));
    }
};

/**
 * Read file and return data as a binary data.
 *
 * @param file          {File} File object containing file properties
 */
FileReader.prototype.readAsBinaryString = function(file) {
    // TODO - Can't return binary data to browser.
    console.log('method "readAsBinaryString" is not supported at this time.');
};

/**
 * Read file and return data as a binary data.
 *
 * @param file          {File} File object containing file properties
 */
FileReader.prototype.readAsArrayBuffer = function(file) {
    // TODO - Can't return binary data to browser.
    console.log('This method is not supported at this time.');
};

module.exports = FileReader;
});

// file: lib/common/plugin/FileSystem.js
sktdefine("srt/plugin/FileSystem", function(sktrequire, exports, module) {
var DirectoryEntry = sktrequire('srt/plugin/DirectoryEntry');

/**
 * An interface representing a file system
 *
 * @constructor
 * {DOMString} name the unique name of the file system (readonly)
 * {DirectoryEntry} root directory of the file system (readonly)
 */
var FileSystem = function(name, root) {
    this.name = name || null;
    if (root) {
        this.root = new DirectoryEntry(root.name, root.fullPath);
    }
};

module.exports = FileSystem;
});

// file: lib/common/plugin/FileTransfer.js
sktdefine("srt/plugin/FileTransfer", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

/**
 * FileTransfer uploads a file to a remote server.
 * @constructor
 */
var FileTransfer = function() {};

/**
* Given an absolute file path, uploads a file on the device to a remote server
* using a multipart HTTP request.
* @param filePath {String}           Full path of the file on the device
* @param server {String}             URL of the server to receive the file
* @param successCallback (Function}  Callback to be invoked when upload has completed
* @param errorCallback {Function}    Callback to be invoked upon error
* @param options {FileUploadOptions} Optional parameters such as file name and mimetype
* @param trustAllHosts {Boolean} Optional trust all hosts (e.g. for self-signed certs), defaults to false
*/
FileTransfer.prototype.upload = function(filePath, server, successCallback, errorCallback, options, trustAllHosts) {
    // check for options
    var fileKey = null;
    var fileName = null;
    var mimeType = null;
    var params = null;
    var chunkedMode = true;
    if (options) {
        fileKey = options.fileKey;
        fileName = options.fileName;
        mimeType = options.mimeType;
        if (options.chunkedMode !== null || typeof options.chunkedMode != "undefined") {
            chunkedMode = options.chunkedMode;
        }
        if (options.params) {
            params = options.params;
        }
        else {
            params = {};
        }
    }

    exec(successCallback, errorCallback, 'FileTransfer', 'upload', [filePath, server, fileKey, fileName, mimeType, params, trustAllHosts, chunkedMode]);
};

/**
 * Downloads a file form a given URL and saves it to the specified directory.
 * @param source {String}          URL of the server to receive the file
 * @param target {String}         Full path of the file on the device
 * @param successCallback (Function}  Callback to be invoked when upload has completed
 * @param errorCallback {Function}    Callback to be invoked upon error
 */
FileTransfer.prototype.download = function(source, target, successCallback, errorCallback) {
    var win = function(result) {
        var entry = null;
        if (result.isDirectory) {
            entry = new (sktrequire('srt/plugin/DirectoryEntry'))();
        }
        else if (result.isFile) {
            entry = new (sktrequire('srt/plugin/FileEntry'))();
        }
        entry.isDirectory = result.isDirectory;
        entry.isFile = result.isFile;
        entry.name = result.name;
        entry.fullPath = result.fullPath;
        successCallback(entry);
    };
    exec(win, errorCallback, 'FileTransfer', 'download', [source, target]);
};

module.exports = FileTransfer;

});

// file: lib/common/plugin/FileTransferError.js
sktdefine("srt/plugin/FileTransferError", function(sktrequire, exports, module) {
/**
 * FileTransferError
 * @constructor
 */
var FileTransferError = function(code) {
    this.code = code || null;
};

FileTransferError.FILE_NOT_FOUND_ERR = 1;
FileTransferError.INVALID_URL_ERR = 2;
FileTransferError.CONNECTION_ERR = 3;

module.exports = FileTransferError;
});

// file: lib/common/plugin/FileUploadOptions.js
sktdefine("srt/plugin/FileUploadOptions", function(sktrequire, exports, module) {
/**
 * Options to customize the HTTP request used to upload files.
 * @constructor
 * @param fileKey {String}   Name of file request parameter.
 * @param fileName {String}  Filename to be used by the server. Defaults to image.jpg.
 * @param mimeType {String}  Mimetype of the uploaded file. Defaults to image/jpeg.
 * @param params {Object}    Object with key: value params to send to the server.
 */
var FileUploadOptions = function(fileKey, fileName, mimeType, params) {
    this.fileKey = fileKey || null;
    this.fileName = fileName || null;
    this.mimeType = mimeType || null;
    this.params = params || null;
};

module.exports = FileUploadOptions;
});

// file: lib/common/plugin/FileUploadResult.js
sktdefine("srt/plugin/FileUploadResult", function(sktrequire, exports, module) {
/**
 * FileUploadResult
 * @constructor
 */
var FileUploadResult = function() {
    this.bytesSent = 0;
    this.responseCode = null;
    this.response = null;
};

module.exports = FileUploadResult;
});

// file: lib/common/plugin/FileWriter.js
sktdefine("srt/plugin/FileWriter", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    FileError = sktrequire('srt/plugin/FileError'),
    ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

/**
 * This class writes to the mobile device file system.
 *
 * For Android:
 *      The root directory is the root of the file system.
 *      To write to the SD card, the file name is "sdcard/my_file.txt"
 *
 * @constructor
 * @param file {File} File object containing file properties
 * @param append if true write to the end of the file, otherwise overwrite the file
 */
var FileWriter = function(file) {
    this.fileName = "";
    this.length = 0;
    if (file) {
        this.fileName = file.fullPath || file;
        this.length = file.size || 0;
    }
    // default is to write at the beginning of the file
    this.position = 0;

    this.readyState = 0; // EMPTY

    this.result = null;

    // Error
    this.error = null;

    // Event handlers
    this.onwritestart = null;   // When writing starts
    this.onprogress = null;     // While writing the file, and reporting partial file data
    this.onwrite = null;        // When the write has successfully completed.
    this.onwriteend = null;     // When the request has completed (either in success or failure).
    this.onabort = null;        // When the write has been aborted. For instance, by invoking the abort() method.
    this.onerror = null;        // When the write has failed (see errors).
};

// States
FileWriter.INIT = 0;
FileWriter.WRITING = 1;
FileWriter.DONE = 2;

/**
 * Abort writing file.
 */
FileWriter.prototype.abort = function() {
    // check for invalid state
    if (this.readyState === FileWriter.DONE || this.readyState === FileWriter.INIT) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    // set error
    this.error = new FileError(FileError.ABORT_ERR);

    this.readyState = FileWriter.DONE;

    // If abort callback
    if (typeof this.onabort === "function") {
        this.onabort(new ProgressEvent("abort", {"target":this}));
    }

    // If write end callback
    if (typeof this.onwriteend === "function") {
        this.onwriteend(new ProgressEvent("writeend", {"target":this}));
    }
};

/**
 * Writes data to the file
 *
 * @param text to be written
 */
FileWriter.prototype.write = function(text) {
    // Throw an exception if we are already writing a file
    if (this.readyState === FileWriter.WRITING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    // WRITING state
    this.readyState = FileWriter.WRITING;

    var me = this;

    // If onwritestart callback
    if (typeof me.onwritestart === "function") {
        me.onwritestart(new ProgressEvent("writestart", {"target":me}));
    }

    // Write file
    exec(
        // Success callback
        function(r) {
            // If DONE (cancelled), then don't do anything
            if (me.readyState === FileWriter.DONE) {
                return;
            }

            // position always increases by bytes written because file would be extended
            me.position += r;
            // The length of the file is now where we are done writing.

            me.length = me.position;

            // DONE state
            me.readyState = FileWriter.DONE;

            // If onwrite callback
            if (typeof me.onwrite === "function") {
                me.onwrite(new ProgressEvent("write", {"target":me}));
            }

            // If onwriteend callback
            if (typeof me.onwriteend === "function") {
                me.onwriteend(new ProgressEvent("writeend", {"target":me}));
            }
        },
        // Error callback
        function(e) {
            // If DONE (cancelled), then don't do anything
            if (me.readyState === FileWriter.DONE) {
                return;
            }

            // DONE state
            me.readyState = FileWriter.DONE;

            // Save error
            me.error = new FileError(e);

            // If onerror callback
            if (typeof me.onerror === "function") {
                me.onerror(new ProgressEvent("error", {"target":me}));
            }

            // If onwriteend callback
            if (typeof me.onwriteend === "function") {
                me.onwriteend(new ProgressEvent("writeend", {"target":me}));
            }
        }, "File", "write", [this.fileName, text, this.position]);
    
    //[20120706][chisu]invoke progress callback
    // If onwritestart callback
    if (typeof me.onprogress === "function") {
        me.onprogress(new ProgressEvent("progress", {"target":me}));
    }
};

/**
 * Moves the file pointer to the location specified.
 *
 * If the offset is a negative number the position of the file
 * pointer is rewound.  If the offset is greater than the file
 * size the position is set to the end of the file.
 *
 * @param offset is the location to move the file pointer to.
 */
FileWriter.prototype.seek = function(offset) {
    // Throw an exception if we are already writing a file
    if (this.readyState === FileWriter.WRITING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    if (!offset && offset !== 0) {
        return;
    }

    // See back from end of file.
    if (offset < 0) {
        this.position = Math.max(offset + this.length, 0);
    }
    // Offset is bigger then file size so set position
    // to the end of the file.
    else if (offset > this.length) {
        this.position = this.length;
    }
    // Offset is between 0 and file size so set the position
    // to start writing.
    else {
        this.position = offset;
    }
};

/**
 * Truncates the file to the size specified.
 *
 * @param size to chop the file at.
 */
FileWriter.prototype.truncate = function(size) {
    // Throw an exception if we are already writing a file
    if (this.readyState === FileWriter.WRITING) {
        throw new FileError(FileError.INVALID_STATE_ERR);
    }

    // WRITING state
    this.readyState = FileWriter.WRITING;

    var me = this;

    // If onwritestart callback
    if (typeof me.onwritestart === "function") {
        me.onwritestart(new ProgressEvent("writestart", {"target":this}));
    }

    // Write file
    exec(
        // Success callback
        function(r) {
            // If DONE (cancelled), then don't do anything
            if (me.readyState === FileWriter.DONE) {
                return;
            }

            // DONE state
            me.readyState = FileWriter.DONE;

            // Update the length of the file
            me.length = r;
            me.position = Math.min(me.position, r);

            // If onwrite callback
            if (typeof me.onwrite === "function") {
                me.onwrite(new ProgressEvent("write", {"target":me}));
            }

            // If onwriteend callback
            if (typeof me.onwriteend === "function") {
                me.onwriteend(new ProgressEvent("writeend", {"target":me}));
            }
        },
        // Error callback
        function(e) {
            // If DONE (cancelled), then don't do anything
            if (me.readyState === FileWriter.DONE) {
                return;
            }

            // DONE state
            me.readyState = FileWriter.DONE;

            // Save error
            me.error = new FileError(e);

            // If onerror callback
            if (typeof me.onerror === "function") {
                me.onerror(new ProgressEvent("error", {"target":me}));
            }

            // If onwriteend callback
            if (typeof me.onwriteend === "function") {
                me.onwriteend(new ProgressEvent("writeend", {"target":me}));
            }
        }, "File", "truncate", [this.fileName, size]);
    //[20120706][chisu]invoke progress callback
    // If onwritestart callback
    if (typeof me.onprogress === "function") {
        me.onprogress(new ProgressEvent("progress", {"target":me}));
    }
};

module.exports = FileWriter;

});

// file: lib/common/plugin/Flags.js
sktdefine("srt/plugin/Flags", function(sktrequire, exports, module) {
/**
 * Supplies arguments to methods that lookup or create files and directories.
 *
 * @param create
 *            {boolean} file or directory if it doesn't exist
 * @param exclusive
 *            {boolean} used with create; if true the command will fail if
 *            target path exists
 */
function Flags(create, exclusive) {
    this.create = create || false;
    this.exclusive = exclusive || false;
}

module.exports = Flags;
});

// file: lib/common/plugin/LocalFileSystem.js
sktdefine("srt/plugin/LocalFileSystem", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

/**
 * Represents a local file system.
 */
var LocalFileSystem = function() {

};

LocalFileSystem.TEMPORARY = 0; //temporary, with no guarantee of persistence
LocalFileSystem.PERSISTENT = 1; //persistent

module.exports = LocalFileSystem;
});

//[20120822][chisu]add applauncher
//file: lib/common/plugin/applauncher.js
sktdefine("srt/plugin/applauncher", function(sktrequire, exports, module) {

	var utils = sktrequire("srt/utils"),
	exec = sktrequire("srt/exec");


	var applauncher = {
		
		/**
		 * Get Installed Application names in device
		 *
		 * @param {Function} successCallback 
		 * @param {Function} errorCallback 
		 */
		getInstalledApplications: function(successCallback, errorCallback) {
			// successCallback required
			if (typeof successCallback !== "function" ) {
				throw "getInstalledApplications must be called with at least a success callback function as first parameter.";
			}  
			// successCallback required
			else if (successCallback === null ) {
				throw "getInstalledApplications must be called with at least a success callback function as first parameter.";
			} 

			exec(successCallback, errorCallback, "AppLauncher", "getInstalledApplications", []);
		},

		/**
		 * Launch Application
		 *
		 * @param {Function} successCallback 
		 * @param {Function} errorCallback 
		 * @param String app URI
		 */
		launchApplication: function(successCallback, errorCallback, appURI) {
			// successCallback required
			if (typeof successCallback !== "function" ) {
				throw "launchApplication must be called with at least a success callback function as first parameter.";
			}  
			// successCallback required
			else if (successCallback === null ) {
				throw "launchApplication must be called with at least a success callback function as first parameter.";
			} 

			else if(appURI != null && typeof appURI != "string"){
				throw "3rd argument must be string Type.";
			}

			exec(successCallback, errorCallback, "AppLauncher", "launchApplication", [appURI]);
		}	
	};

	module.exports = applauncher;

});

//[20120821][chisu]add mediamanager
//file: lib/common/plugin/mediamanager.js
sktdefine("srt/plugin/mediamanager", function(sktrequire, exports, module) {

	var utils = sktrequire("srt/utils"),
	exec = sktrequire("srt/exec"),
	media = sktrequire("srt/plugin/Media");


	var mediamanager = {
		
		/**
		 * CreateAudio
		 *
		 * @param {Function} successCallback 
		 * @param {Function} errorCallback 
		 */
		createAudio: function(successCallback, errorCallback, filename) {
				// successCallback required
				if (typeof successCallback !== "function" ) {
					throw "createAudio must be called with at least a success callback function as first parameter.";
				}  
				// successCallback required
				else if (successCallback === null ) {
					throw "createAudio must be called with at least a success callback function as first parameter.";
				} 
				
				else if(filename != null && typeof filename != "string"){
					throw "3rd argument must be string Type.";
				}

				var returnMedia = new Media(filename,null, null);
				successCallback(returnMedia);
				
			}
	};

	module.exports = mediamanager;

});

// file: lib/common/plugin/Media.js
sktdefine("srt/plugin/Media", function(sktrequire, exports, module) {
var utils = sktrequire('srt/utils'),
    exec = sktrequire('srt/exec');

var mediaObjects = {};

/**
 * This class provides access to the device media, interfaces to both sound and video
 *
 * @constructor
 * @param src                   The file name or url to play
 * @param successCallback       The callback to be called when the file is done playing or recording.
 *                                  successCallback()
 * @param errorCallback         The callback to be called if there is an error.
 *                                  errorCallback(int errorCode) - OPTIONAL
 * @param statusCallback        The callback to be called when media status has changed.
 *                                  statusCallback(int statusCode) - OPTIONAL
 */
var Media = function(src, successCallback, errorCallback, statusCallback) {

    // successCallback optional
    if (successCallback && (typeof successCallback !== "function")) {
        console.log("Media Error: successCallback is not a function");
        return;
    }

    // errorCallback optional
    if (errorCallback && (typeof errorCallback !== "function")) {
        console.log("Media Error: errorCallback is not a function");
        return;
    }

    // statusCallback optional
    if (statusCallback && (typeof statusCallback !== "function")) {
        console.log("Media Error: statusCallback is not a function");
        return;
    }

    this.id = utils.createUUID();
    mediaObjects[this.id] = this;
    this.src = src;
    this.successCallback = successCallback;
    this.errorCallback = errorCallback;
    this.statusCallback = statusCallback;
    this._duration = -1;
    this._position = -1;
    exec(null, this.errorCallback, "Media", "create", [this.id, this.src]);
};

// Media messages
Media.MEDIA_STATE = 1;
Media.MEDIA_DURATION = 2;
Media.MEDIA_POSITION = 3;
Media.MEDIA_ERROR = 9;

// Media states
Media.MEDIA_NONE = 0;
Media.MEDIA_STARTING = 1;
Media.MEDIA_RUNNING = 2;
Media.MEDIA_PAUSED = 3;
Media.MEDIA_STOPPED = 4;
Media.MEDIA_MSG = ["None", "Starting", "Running", "Paused", "Stopped"];

// "static" function to return existing objs.
Media.get = function(id) {
    return mediaObjects[id];
};

/**
 * Start or resume playing audio file.
 */
Media.prototype.play = function(options) {
    exec(null, null, "Media", "startPlayingAudio", [this.id, this.src, options]);
};

/**
 * Stop playing audio file.
 */
Media.prototype.stop = function() {
    var me = this;
    exec(function() {
        me._position = 0;
        if(me.successCallback)
        	me.successCallback();
    }, this.errorCallback, "Media", "stopPlayingAudio", [this.id]);
};

/**
 * Seek or jump to a new time in the track..
 */
Media.prototype.seekTo = function(milliseconds) {
    var me = this;
    exec(function(p) {
        me._position = p;
    }, this.errorCallback, "Media", "seekToAudio", [this.id, milliseconds]);
};

/**
 * Pause playing audio file.
 */
Media.prototype.pause = function() {
    exec(null, this.errorCallback, "Media", "pausePlayingAudio", [this.id]);
};

/**
 * Get duration of an audio file.
 * The duration is only set for audio that is playing, paused or stopped.
 *
 * @return      duration or -1 if not known.
 */
Media.prototype.getDuration = function() {
	//[20120821][chisu]
	//this._duration = exec(null, this.errorCallback, "Media", "getDurationAudio", [this.id, this.src]);
    return this._duration;
};

/**
 * Get position of audio.
 */
Media.prototype.getCurrentPosition = function(success, fail) {
    var me = this;
    exec(function(p) {
        me._position = p;
        success(p);
    }, fail, "Media", "getCurrentPositionAudio", [this.id]);
};

/**
 * Start recording audio file.
 */
Media.prototype.startRecord = function() {
    exec(this.successCallback, this.errorCallback, "Media", "startRecordingAudio", [this.id, this.src]);
};

/**
 * Stop recording audio file.
 */
Media.prototype.stopRecord = function() {
    exec(this.successCallback, this.errorCallback, "Media", "stopRecordingAudio", [this.id]);
};

/**
 * Release the resources.
 */
Media.prototype.release = function() {
    exec(null, this.errorCallback, "Media", "release", [this.id]);
};

/**
 * Adjust the volume.
 */
Media.prototype.setVolume = function(volume) {
    exec(null, null, "Media", "setVolume", [this.id, volume]);
};

/**
 * Audio has status update.
 * PRIVATE
 *
 * @param id            The media object id (string)
 * @param status        The status code (int)
 * @param msg           The status message (string)
 */
Media.onStatus = function(id, msg, value) {
    var media = mediaObjects[id];
    // If state update
    if (msg === Media.MEDIA_STATE) {
        if (value === Media.MEDIA_STOPPED) {
            if (media.successCallback) {
                media.successCallback();
            }
        }
        if (media.statusCallback) {
            media.statusCallback(value);
        }
    }
    else if (msg === Media.MEDIA_DURATION) {
        media._duration = value;
    }
    else if (msg === Media.MEDIA_ERROR) {
        if (media.errorCallback) {
            // value should be a MediaError object when msg == MEDIA_ERROR
            media.errorCallback(value);
        }
    }
    else if (msg === Media.MEDIA_POSITION) {
        media._position = value;
    }
};

module.exports = Media;
});

// file: lib/common/plugin/MediaError.js
sktdefine("srt/plugin/MediaError", function(sktrequire, exports, module) {
/**
 * This class contains information about any Media errors.
 * @constructor
 */
var MediaError = function(code, msg) {
    this.code = (code !== undefined ? code : null);
    this.message = msg || "";
};

MediaError.MEDIA_ERR_NONE_ACTIVE    = 0;
MediaError.MEDIA_ERR_ABORTED        = 1;
MediaError.MEDIA_ERR_NETWORK        = 2;
MediaError.MEDIA_ERR_DECODE         = 3;
MediaError.MEDIA_ERR_NONE_SUPPORTED = 4;

module.exports = MediaError;
});

// file: lib/common/plugin/MediaFile.js
sktdefine("srt/plugin/MediaFile", function(sktrequire, exports, module) {
var utils = sktrequire('srt/utils'),
    exec = sktrequire('srt/exec'),
    File = sktrequire('srt/plugin/File'),
    CaptureError = sktrequire('srt/plugin/CaptureError');
/**
 * Represents a single file.
 *
 * name {DOMString} name of the file, without path information
 * fullPath {DOMString} the full path of the file, including the name
 * type {DOMString} mime type
 * lastModifiedDate {Date} last modified date
 * size {Number} size of the file in bytes
 */
var MediaFile = function(name, fullPath, type, lastModifiedDate, size){
    MediaFile.__super__.constructor.apply(this, arguments);
};

utils.extend(MediaFile, File);

/**
 * Request capture format data for a specific file and type
 *
 * @param {Function} successCB
 * @param {Function} errorCB
 */
MediaFile.prototype.getFormatData = function(successCallback, errorCallback) {
    if (typeof this.fullPath === "undefined" || this.fullPath === null) {
        errorCallback(new CaptureError(CaptureError.CAPTURE_INVALID_ARGUMENT));
    } else {
        exec(successCallback, errorCallback, "Capture", "getFormatData", [this.fullPath, this.type]);
    }
};

// TODO: can we axe this?
/**
 * Casts a PluginResult message property  (array of objects) to an array of MediaFile objects
 * (used in Objective-C and Android)
 *
 * @param {PluginResult} pluginResult
 */
MediaFile.cast = function(pluginResult) {
    var mediaFiles = [];
    for (var i=0; i<pluginResult.message.length; i++) {
        var mediaFile = new MediaFile();
        mediaFile.name = pluginResult.message[i].name;
        mediaFile.fullPath = pluginResult.message[i].fullPath;
        mediaFile.type = pluginResult.message[i].type;
        mediaFile.lastModifiedDate = pluginResult.message[i].lastModifiedDate;
        mediaFile.size = pluginResult.message[i].size;
        mediaFiles.push(mediaFile);
    }
    pluginResult.message = mediaFiles;
    return pluginResult;
};

module.exports = MediaFile;

});

// file: lib/common/plugin/MediaFileData.js
sktdefine("srt/plugin/MediaFileData", function(sktrequire, exports, module) {
/**
 * MediaFileData encapsulates format information of a media file.
 *
 * @param {DOMString} codecs
 * @param {long} bitrate
 * @param {long} height
 * @param {long} width
 * @param {float} duration
 */
var MediaFileData = function(codecs, bitrate, height, width, duration){
    this.codecs = codecs || null;
    this.bitrate = bitrate || 0;
    this.height = height || 0;
    this.width = width || 0;
    this.duration = duration || 0;
};

module.exports = MediaFileData;
});

// file: lib/common/plugin/Metadata.js
sktdefine("srt/plugin/Metadata", function(sktrequire, exports, module) {
/**
 * Information about the state of the file or directory
 *
 * {Date} modificationTime (readonly)
 */
var Metadata = function(time,size) {
    this.modificationTime = (typeof time != 'undefined'?new Date(time):null);
    this.size = size;
};

module.exports = Metadata;
});

// file: lib/common/plugin/Position.js
sktdefine("srt/plugin/Position", function(sktrequire, exports, module) {
var Coordinates = sktrequire('srt/plugin/Coordinates');

var Position = function(coords, timestamp) {
    if (coords) {
        this.coords = new Coordinates(coords.latitude, coords.longitude, coords.altitude, coords.accuracy, coords.heading, coords.velocity, coords.altitudeAccuracy);
    } else {
        this.coords = new Coordinates();
    }
    this.timestamp = (timestamp !== undefined) ? timestamp : new Date();
};

module.exports = Position;

});

// file: lib/common/plugin/PositionError.js
sktdefine("srt/plugin/PositionError", function(sktrequire, exports, module) {
/**
 * Position error object
 *
 * @constructor
 * @param code
 * @param message
 */
var PositionError = function(code, message) {
    this.code = code || null;
    this.message = message || '';
};

PositionError.PERMISSION_DENIED = 1;
PositionError.POSITION_UNAVAILABLE = 2;
PositionError.TIMEOUT = 3;

module.exports = PositionError;
});

// file: lib/common/plugin/ProgressEvent.js
sktdefine("srt/plugin/ProgressEvent", function(sktrequire, exports, module) {
// If ProgressEvent exists in global context, use it already, otherwise use our own polyfill
// Feature test: See if we can instantiate a native ProgressEvent;
// if so, use that approach,
// otherwise fill-in with our own implementation.
//
// NOTE: right now we always fill in with our own. Down the road would be nice if we can use whatever is native in the webview.
var ProgressEvent = (function() {
    /*
    var createEvent = function(data) {
        var event = document.createEvent('Events');
        event.initEvent('ProgressEvent', false, false);
        if (data) {
            for (var i in data) {
                if (data.hasOwnProperty(i)) {
                    event[i] = data[i];
                }
            }
            if (data.target) {
                // TODO: cannot call <some_custom_object>.dispatchEvent
                // need to first figure out how to implement EventTarget
            }
        }
        return event;
    };
    try {
        var ev = createEvent({type:"abort",target:document});
        return function ProgressEvent(type, data) {
            data.type = type;
            return createEvent(data);
        };
    } catch(e){
    */
        return function ProgressEvent(type, dict) {
            this.type = type;
            this.bubbles = false;
            this.cancelBubble = false;
            this.cancelable = false;
            this.lengthComputable = false;
            this.loaded = dict && dict.loaded ? dict.loaded : 0;
            this.total = dict && dict.total ? dict.total : 0;
            this.target = dict && dict.target ? dict.target : null;
        };
    //}
})();

module.exports = ProgressEvent;
});

// file: lib/common/plugin/accelerometer.js
sktdefine("srt/plugin/accelerometer", function(sktrequire, exports, module) {
/**
 * This class provides access to device accelerometer data.
 * @constructor
 */
var utils = sktrequire("srt/utils"),
    exec = sktrequire("srt/exec"),
    Acceleration = sktrequire('srt/plugin/Acceleration');

// Is the accel sensor running?
var running = false;

// Keeps reference to watchAcceleration calls.
var timers = {};

// Array of listeners; used to keep track of when we should call start and stop.
var listeners = [];

// Last returned acceleration object from native
var accel = null;

// Tells native to start.
function start() {
    exec(function(a) {
        var tempListeners = listeners.slice(0);
        accel = new Acceleration(a.x, a.y, a.z, a.timestamp);
        for (var i = 0, l = tempListeners.length; i < l; i++) {
            tempListeners[i].win(accel);
        }
    }, function(e) {
        var tempListeners = listeners.slice(0);
        for (var i = 0, l = tempListeners.length; i < l; i++) {
            tempListeners[i].fail(e);
        }
    }, "Accelerometer", "start", []);
    running = true;
}

// Tells native to stop.
function stop() {
    exec(null, null, "Accelerometer", "stop", []);
    running = false;
}

// Adds a callback pair to the listeners array
function createCallbackPair(win, fail) {
    return {win:win, fail:fail};
}

// Removes a win/fail listener pair from the listeners array
function removeListeners(l) {
    var idx = listeners.indexOf(l);
    if (idx > -1) {
        listeners.splice(idx, 1);
        if (listeners.length === 0) {
            stop();
        }
    }
}

var accelerometer = {
    /**
     * Asynchronously aquires the current acceleration.
     *
     * @param {Function} successCallback    The function to call when the acceleration data is available
     * @param {Function} errorCallback      The function to call when there is an error getting the acceleration data. (OPTIONAL)
     * @param {AccelerationOptions} options The options for getting the accelerometer data such as timeout. (OPTIONAL)
     */
    getCurrentAcceleration: function(successCallback, errorCallback, options) {
        // successCallback required
        if (typeof successCallback !== "function") {
            throw "getCurrentAcceleration must be called with at least a success callback function as first parameter.";
        }

        var p;
        var win = function(a) {
        	//[20120621][chisu]change function call order.
            removeListeners(p);
            successCallback(a);
        };
        var fail = function(e) {            
            removeListeners(p);
            errorCallback(e);
        };

        p = createCallbackPair(win, fail);
        listeners.push(p);

        if (!running) {
            start();
        }
    },

    /**
     * Asynchronously aquires the acceleration repeatedly at a given interval.
     *
     * @param {Function} successCallback    The function to call each time the acceleration data is available
     * @param {Function} errorCallback      The function to call when there is an error getting the acceleration data. (OPTIONAL)
     * @param {AccelerationOptions} options The options for getting the accelerometer data such as timeout. (OPTIONAL)
     * @return String                       The watch id that must be passed to #clearWatch to stop watching.
     */
    watchAcceleration: function(successCallback, errorCallback, options) {
        // Default interval (10 sec)
        var frequency = (options && options.frequency && typeof options.frequency == 'number') ? options.frequency : 10000;

        // successCallback required
        if (typeof successCallback !== "function") {
            throw "watchAcceleration must be called with at least a success callback function as first parameter.";
        }

        // Keep reference to watch id, and report accel readings as often as defined in frequency
        var id = utils.createUUID();

        var p = createCallbackPair(function(){}, function(e) {
            errorCallback(e);
            removeListeners(p);
        });
        listeners.push(p);

        timers[id] = {
            timer:window.setInterval(function() {
                if (accel) {
                    successCallback(accel);
                }
            }, frequency),
            listeners:p
        };

        if (running) {
            // If we're already running then immediately invoke the success callback
            successCallback(accel);
        } else {
            start();
        }

        return id;
    },

    /**
     * Clears the specified accelerometer watch.
     *
     * @param {String} id       The id of the watch returned from #watchAcceleration.
     */
    clearWatch: function(id) {
        // Stop javascript timer & remove from timer list
        if (id && timers[id]) {
            window.clearInterval(timers[id].timer);
            removeListeners(timers[id].listeners);
            delete timers[id];
        }
    }
};

module.exports = accelerometer;

});

//file: lib/common/plugin/Worker.js
sktdefine("srt/plugin/Worker", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var Worker = function(file) {
    this.fileName = "";
    
    if (file) {
        this.fileName = file;
        exec(null, null, "Worker", "makeworker", [this.fileName]);
    }
    
    // Event handlers
    this.onmessage = null;   
    this.onerror = null;      
};


/**
 * Abort writing file.
 */
Worker.prototype.postMessage = function(message,transfer) {
	exec(null,null, "Worker", "postMessage", [message,transfer]);
};


module.exports = Worker;

});

// file: lib/android/plugin/android/app.js
sktdefine("srt/plugin/android/app", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

module.exports = {
  /**
   * Clear the resource cache.
   */
  clearCache:function() {
    exec(null, null, "App", "clearCache", []);
  },

  /**
   * Load the url into the webview or into new browser instance.
   *
   * @param url           The URL to load
   * @param props         Properties that can be passed in to the activity:
   *      wait: int                           => wait msec before loading URL
   *      loadingDialog: "Title,Message"      => display a native loading dialog
   *      loadUrlTimeoutValue: int            => time in msec to wait before triggering a timeout error
   *      clearHistory: boolean              => clear webview history (default=false)
   *      openExternal: boolean              => open in a new browser (default=false)
   *
   * Example:
   *      navigator.app.loadUrl("http://server/myapp/index.html", {wait:2000, loadingDialog:"Wait,Loading App", loadUrlTimeoutValue: 60000});
   */
  loadUrl:function(url, props) {
    exec(null, null, "App", "loadUrl", [url, props]);
  },

  /**
   * Cancel loadUrl that is waiting to be loaded.
   */
  cancelLoadUrl:function() {
    exec(null, null, "App", "cancelLoadUrl", []);
  },

  /**
   * Clear web history in this web view.
   * Instead of BACK button loading the previous web page, it will exit the app.
   */
  clearHistory:function() {
    exec(null, null, "App", "clearHistory", []);
  },

  /**
   * Go to previous page displayed.
   * This is the same as pressing the backbutton on Android device.
   */
  backHistory:function() {
    exec(null, null, "App", "backHistory", []);
  },

  /**
   * Override the default behavior of the Android back button.
   * If overridden, when the back button is pressed, the "backKeyDown" JavaScript event will be fired.
   *
   * Note: The user should not have to call this method.  Instead, when the user
   *       registers for the "backbutton" event, this is automatically done.
   *
   * @param override        T=override, F=cancel override
   */
  overrideBackbutton:function(override) {
    exec(null, null, "App", "overrideBackbutton", [override]);
  },

  /**
   * Exit and terminate the application.
   */
  exitApp:function() {
    return exec(null, null, "App", "exitApp", []);
  }
};
});

// file: lib/android/plugin/android/callback.js
sktdefine("srt/plugin/android/callback", function(sktrequire, exports, module) {
var port = null,
    token = null,
    srt = sktrequire('srt'),
    polling = sktrequire('srt/plugin/android/polling'),
    callback = function() {
      // Exit if shutting down app
      if (srt.shuttingDown) {
          return;
      }

      // If polling flag was changed, start using polling from now on
      if (srt.UsePolling) {
          polling();
          return;
      }

      var xmlhttp = new XMLHttpRequest();

      // Callback function when XMLHttpRequest is ready
      xmlhttp.onreadystatechange=function(){
          if(xmlhttp.readyState === 4){

              // Exit if shutting down app
              if (srt.shuttingDown) {
                  return;
              }

              // If callback has JavaScript statement to execute
              if (xmlhttp.status === 200) {

                  // Need to url decode the response
                  var msg = decodeURIComponent(xmlhttp.responseText);
                  setTimeout(function() {
                      try {
                          var t = eval(msg);
                      }
                      catch (e) {
                          // If we're getting an error here, seeing the message will help in debugging
                          console.log("JSCallback: Message from Server: " + msg);
                          console.log("JSCallback Error: "+e);
                      }
                  }, 1);
                  setTimeout(callback, 1);
              }

              // If callback ping (used to keep XHR request from timing out)
              else if (xmlhttp.status === 404) {
                  setTimeout(callback, 10);
              }

              // If security error
              else if (xmlhttp.status === 403) {
                  console.log("JSCallback Error: Invalid token.  Stopping callbacks.");
              }

              // If server is stopping
              else if (xmlhttp.status === 503) {
                  console.log("JSCallback Server Closed: Stopping callbacks.");
              }

              // If request wasn't GET
              else if (xmlhttp.status === 400) {
                  console.log("JSCallback Error: Bad request.  Stopping callbacks.");
              }

              // If error, revert to polling
              else {
                  console.log("JSCallback Error: Request failed.");
                  srt.UsePolling = true;
                  polling();
              }
          }
      };

      if (port === null) {
          port = prompt("getPort", "gap_callbackServer:");
      }
      if (token === null) {
          token = prompt("getToken", "gap_callbackServer:");
      }
      xmlhttp.open("GET", "http://127.0.0.1:"+port+"/"+token , true);
      xmlhttp.send();
};

module.exports = callback;
});

// file: lib/android/plugin/android/device.js
sktdefine("srt/plugin/android/device", function(sktrequire, exports, module) {
var channel = sktrequire('srt/channel'),
    utils = sktrequire('srt/utils'),
    exec = sktrequire('srt/exec');

/**
 * This represents the mobile device, and provides properties for inspecting the model, version, UUID of the
 * phone, etc.
 * @constructor
 */
function Device() {
    this.available = false;
    this.platform = null;
    this.version = null;
    this.name = null;
    this.uuid = null;
    this.srt = null;

    var me = this;

    channel.onSKTRuntimeReady.subscribeOnce(function() {
        me.getInfo(function(info) {
            me.available = true;
            me.platform = info.platform;
            me.version = info.version;
            me.name = info.name;
            me.uuid = info.uuid;
            me.srt = info.srt;
            channel.onCordovaInfoReady.fire();
        },function(e) {
            me.available = false;
            utils.alert("[ERROR] Error initializing Cordova: " + e);
        });
    });
}

/**
 * Get device info
 *
 * @param {Function} successCallback The function to call when the heading data is available
 * @param {Function} errorCallback The function to call when there is an error getting the heading data. (OPTIONAL)
 */
Device.prototype.getInfo = function(successCallback, errorCallback) {

    // successCallback required
    if (typeof successCallback !== "function") {
        console.log("Device Error: successCallback is not a function");
        return;
    }

    // errorCallback optional
    if (errorCallback && (typeof errorCallback !== "function")) {
        console.log("Device Error: errorCallback is not a function");
        return;
    }

    // Get info
    exec(successCallback, errorCallback, "Device", "getDeviceInfo", []);
};

/*
 * DEPRECATED
 * This is only for Android.
 *
 * You must explicitly override the back button.
 */
Device.prototype.overrideBackButton = function() {
    console.log("Device.overrideBackButton() is deprecated.  Use App.overrideBackbutton(true).");
    navigator.app.overrideBackbutton(true);
};

/*
 * DEPRECATED
 * This is only for Android.
 *
 * This resets the back button to the default behaviour
 */
Device.prototype.resetBackButton = function() {
    console.log("Device.resetBackButton() is deprecated.  Use App.overrideBackbutton(false).");
    navigator.app.overrideBackbutton(false);
};

/*
 * DEPRECATED
 * This is only for Android.
 *
 * This terminates the activity!
 */
Device.prototype.exitApp = function() {
    console.log("Device.exitApp() is deprecated.  Use App.exitApp().");
    navigator.app.exitApp();
};

module.exports = new Device();
});

// file: lib/android/plugin/android/notification.js
sktdefine("srt/plugin/android/notification", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

/**
 * Provides Android enhanced notification API.
 */
module.exports = {
    activityStart : function(title, message) {
        // If title and message not specified then mimic Android behavior of
        // using default strings.
        if (typeof title === "undefined" && typeof message == "undefined") {
            title = "Busy";
            message = 'Please wait...';
        }

        exec(null, null, 'Notification', 'activityStart', [ title, message ]);
    },

    /**
     * Close an activity dialog
     */
    activityStop : function() {
        exec(null, null, 'Notification', 'activityStop', []);
    },

    /**
     * Display a progress dialog with progress bar that goes from 0 to 100.
     *
     * @param {String}
     *            title Title of the progress dialog.
     * @param {String}
     *            message Message to display in the dialog.
     */
    progressStart : function(title, message) {
        exec(null, null, 'Notification', 'progressStart', [ title, message ]);
    },

    /**
     * Close the progress dialog.
     */
    progressStop : function() {
        exec(null, null, 'Notification', 'progressStop', []);
    },

    /**
     * Set the progress dialog value.
     *
     * @param {Number}
     *            value 0-100
     */
    progressValue : function(value) {
        exec(null, null, 'Notification', 'progressValue', [ value ]);
    }
};
});

// file: lib/android/plugin/android/polling.js
sktdefine("srt/plugin/android/polling", function(sktrequire, exports, module) {
var srt = sktrequire('srt'),
    period = 50,
    polling = function() {
      // Exit if shutting down app
      if (srt.shuttingDown) {
          return;
      }

      // If polling flag was changed, stop using polling from now on and switch to XHR server / callback
      if (!srt.UsePolling) {
          sktrequire('srt/plugin/android/callback')();
          return;
      }

      var msg = prompt("", "gap_poll:");
      if (msg) {
          setTimeout(function() {
              try {
                  var t = eval(""+msg);
              }
              catch (e) {
                  console.log("JSCallbackPolling: Message from Server: " + msg);
                  console.log("JSCallbackPolling Error: "+e);
              }
          }, 1);
          setTimeout(polling, 1);
      }
      else {
          setTimeout(polling, period);
      }
};

module.exports = polling;
});

// file: lib/android/plugin/android/storage.js
sktdefine("srt/plugin/android/storage", function(sktrequire, exports, module) {
var utils = sktrequire('srt/utils'),
    exec = sktrequire('srt/exec'),
    channel = sktrequire('srt/channel');

var queryQueue = {};

/**
 * SQL result set object
 * PRIVATE METHOD
 * @constructor
 */
var DroidDB_Rows = function() {
    this.resultSet = [];    // results array
    this.length = 0;        // number of rows
};

/**
 * Get item from SQL result set
 *
 * @param row           The row number to return
 * @return              The row object
 */
DroidDB_Rows.prototype.item = function(row) {
    return this.resultSet[row];
};

/**
 * SQL result set that is returned to user.
 * PRIVATE METHOD
 * @constructor
 */
var DroidDB_Result = function() {
    this.rows = new DroidDB_Rows();
};

/**
 * Callback from native code when query is complete.
 * PRIVATE METHOD
 *
 * @param id   Query id
 */
function completeQuery(id, data) {
    var query = queryQueue[id];
    if (query) {
        try {
            delete queryQueue[id];

            // Get transaction
            var tx = query.tx;

            // If transaction hasn't failed
            // Note: We ignore all query results if previous query
            //       in the same transaction failed.
            if (tx && tx.queryList[id]) {

                // Save query results
                var r = new DroidDB_Result();
                r.rows.resultSet = data;
                r.rows.length = data.length;
                try {
                    if (typeof query.successCallback === 'function') {
                        query.successCallback(query.tx, r);
                    }
                } catch (ex) {
                    console.log("executeSql error calling user success callback: "+ex);
                }

                tx.queryComplete(id);
            }
        } catch (e) {
            console.log("executeSql error: "+e);
        }
    }
}

/**
 * Callback from native code when query fails
 * PRIVATE METHOD
 *
 * @param reason            Error message
 * @param id                Query id
 */
function failQuery(reason, id) {
    var query = queryQueue[id];
    if (query) {
        try {
            delete queryQueue[id];

            // Get transaction
            var tx = query.tx;

            // If transaction hasn't failed
            // Note: We ignore all query results if previous query
            //       in the same transaction failed.
            if (tx && tx.queryList[id]) {
                tx.queryList = {};

                try {
                    if (typeof query.errorCallback === 'function') {
                        query.errorCallback(query.tx, reason);
                    }
                } catch (ex) {
                    console.log("executeSql error calling user error callback: "+ex);
                }

                tx.queryFailed(id, reason);
            }

        } catch (e) {
            console.log("executeSql error: "+e);
        }
    }
}

/**
 * SQL query object
 * PRIVATE METHOD
 *
 * @constructor
 * @param tx                The transaction object that this query belongs to
 */
var DroidDB_Query = function(tx) {

    // Set the id of the query
    this.id = utils.createUUID();

    // Add this query to the queue
    queryQueue[this.id] = this;

    // Init result
    this.resultSet = [];

    // Set transaction that this query belongs to
    this.tx = tx;

    // Add this query to transaction list
    this.tx.queryList[this.id] = this;

    // Callbacks
    this.successCallback = null;
    this.errorCallback = null;

};

/**
 * Transaction object
 * PRIVATE METHOD
 * @constructor
 */
var DroidDB_Tx = function() {

    // Set the id of the transaction
    this.id = utils.createUUID();

    // Callbacks
    this.successCallback = null;
    this.errorCallback = null;

    // Query list
    this.queryList = {};
};

/**
 * Mark query in transaction as complete.
 * If all queries are complete, call the user's transaction success callback.
 *
 * @param id                Query id
 */
DroidDB_Tx.prototype.queryComplete = function(id) {
    delete this.queryList[id];

    // If no more outstanding queries, then fire transaction success
    if (this.successCallback) {
        var count = 0;
        var i;
        for (i in this.queryList) {
            if (this.queryList.hasOwnProperty(i)) {
                count++;
            }
        }
        if (count === 0) {
            try {
                this.successCallback();
            } catch(e) {
                console.log("Transaction error calling user success callback: " + e);
            }
        }
    }
};

/**
 * Mark query in transaction as failed.
 *
 * @param id                Query id
 * @param reason            Error message
 */
DroidDB_Tx.prototype.queryFailed = function(id, reason) {

    // The sql queries in this transaction have already been run, since
    // we really don't have a real transaction implemented in native code.
    // However, the user callbacks for the remaining sql queries in transaction
    // will not be called.
    this.queryList = {};

    if (this.errorCallback) {
        try {
            this.errorCallback(reason);
        } catch(e) {
            console.log("Transaction error calling user error callback: " + e);
        }
    }
};

/**
 * Execute SQL statement
 *
 * @param sql                   SQL statement to execute
 * @param params                Statement parameters
 * @param successCallback       Success callback
 * @param errorCallback         Error callback
 */
DroidDB_Tx.prototype.executeSql = function(sql, params, successCallback, errorCallback) {

    // Init params array
    if (typeof params === 'undefined') {
        params = [];
    }

    // Create query and add to queue
    var query = new DroidDB_Query(this);
    queryQueue[query.id] = query;

    // Save callbacks
    query.successCallback = successCallback;
    query.errorCallback = errorCallback;

    // Call native code
    exec(null, null, "Storage", "executeSql", [sql, params, query.id]);
};

var DatabaseShell = function() {
};

/**
 * Start a transaction.
 * Does not support rollback in event of failure.
 *
 * @param process {Function}            The transaction function
 * @param successCallback {Function}
 * @param errorCallback {Function}
 */
DatabaseShell.prototype.transaction = function(process, errorCallback, successCallback) {
    var tx = new DroidDB_Tx();
    tx.successCallback = successCallback;
    tx.errorCallback = errorCallback;
    try {
        process(tx);
    } catch (e) {
        console.log("Transaction error: "+e);
        if (tx.errorCallback) {
            try {
                tx.errorCallback(e);
            } catch (ex) {
                console.log("Transaction error calling user error callback: "+e);
            }
        }
    }
};

/**
 * Open database
 *
 * @param name              Database name
 * @param version           Database version
 * @param display_name      Database display name
 * @param size              Database size in bytes
 * @return                  Database object
 */
var DroidDB_openDatabase = function(name, version, display_name, size) {
    exec(null, null, "Storage", "openDatabase", [name, version, display_name, size]);
    var db = new DatabaseShell();
    return db;
};

/**
 * For browsers with no localStorage we emulate it with SQLite. Follows the w3c api.
 * TODO: Do similar for sessionStorage.
 * @constructor
 */
var CupcakeLocalStorage = function() {
    channel.waitForInitialization("cupcakeStorage");

    try {

      this.db = openDatabase('localStorage', '1.0', 'localStorage', 2621440);
      var storage = {};
      this.length = 0;
      function setLength (length) {
        this.length = length;
        localStorage.length = length;
      }
      this.db.transaction(
        function (transaction) {
            var i;
          transaction.executeSql('CREATE TABLE IF NOT EXISTS storage (id NVARCHAR(40) PRIMARY KEY, body NVARCHAR(255))');
          transaction.executeSql('SELECT * FROM storage', [], function(tx, result) {
            for(var i = 0; i < result.rows.length; i++) {
              storage[result.rows.item(i).id] =  result.rows.item(i).body;
            }
            setLength(result.rows.length);
            channel.initializationComplete("cupcakeStorage");
          });

        },
        function (err) {
          utils.alert(err.message);
        }
      );
      this.setItem = function(key, val) {
        if (typeof(storage[key])=='undefined') {
          this.length++;
        }
        storage[key] = val;
        this.db.transaction(
          function (transaction) {
            transaction.executeSql('CREATE TABLE IF NOT EXISTS storage (id NVARCHAR(40) PRIMARY KEY, body NVARCHAR(255))');
            transaction.executeSql('REPLACE INTO storage (id, body) values(?,?)', [key,val]);
          }
        );
      };
      this.getItem = function(key) {
        return storage[key];
      };
      this.removeItem = function(key) {
        delete storage[key];
        this.length--;
        this.db.transaction(
          function (transaction) {
            transaction.executeSql('CREATE TABLE IF NOT EXISTS storage (id NVARCHAR(40) PRIMARY KEY, body NVARCHAR(255))');
            transaction.executeSql('DELETE FROM storage where id=?', [key]);
          }
        );
      };
      this.clear = function() {
        storage = {};
        this.length = 0;
        this.db.transaction(
          function (transaction) {
            transaction.executeSql('CREATE TABLE IF NOT EXISTS storage (id NVARCHAR(40) PRIMARY KEY, body NVARCHAR(255))');
            transaction.executeSql('DELETE FROM storage', []);
          }
        );
      };
      this.key = function(index) {
        var i = 0;
        for (var j in storage) {
          if (i==index) {
            return j;
          } else {
            i++;
          }
        }
        return null;
      };

    } catch(e) {
          utils.alert("Database error "+e+".");
        return;
    }
};

module.exports = {
  openDatabase:DroidDB_openDatabase,
  CupcakeLocalStorage:CupcakeLocalStorage,
  failQuery:failQuery,
  completeQuery:completeQuery
};

});

//file: lib/common/plugin/battery.js
//[20120615][chisu]modify battery to use EventHandlers
sktdefine("srt/plugin/battery", function(sktrequire, exports, module) {
/**
 * This class contains information about the current battery status.
 * @constructor
 */
var srt = sktrequire('srt'),
    exec = sktrequire('srt/exec');
    channel = sktrequire('srt/channel');//[20120615][chisu]modify battery to use EventHandlers

function handlers() {
  return battery.channels.levelchange.numHandlers +
         battery.channels.chargingchange.numHandlers +
         battery.channels.dischargingtimechange.numHandlers +
         battery.channels.chargingtimechange.numHandlers;
}

//[20120615][chisu]modify battery to use EventHandlers
function createEvent(type, data) {
    var event = document.createEvent('Events');
    event.initEvent(type, false, false);
    if (data) {
        for (var i in data) {
            if (data.hasOwnProperty(i)) {
                event[i] = data[i];
            }
        }
    }
    return event;
}

//[20120615][chisu]modify battery to use EventHandlers
var batteryEventHandlers = {};

function addBatteryEventHandler(event,opts){
  return (batteryEventHandlers[event] = channel.create(event, opts));
}
function removeBatteryEventHandler(event){
  return (batteryEventHandlers[event] = channel.create(event, opts));
}
function fireBatteryEvent(type, data) {
    var evt = createEvent(type,data);
    if (typeof batteryEventHandlers[type] != 'undefined') {
    	batteryEventHandlers[type].fire(evt);
    }
}
    
var Battery = function() {
	this.level = null;
	this.charging = null;
	this.chargingTime = null;
	this.dischargingTime = null;
	
	// Create new event handlers on the window (returns a channel instance)
	var subscriptionEvents = {
			onSubscribe:this.onSubscribe,
			onUnsubscribe:this.onUnsubscribe
	};
	this.channels = {
			levelchange:addBatteryEventHandler("levelchange", subscriptionEvents),
			chargingchange:addBatteryEventHandler("chargingchange", subscriptionEvents),
			chargingtimechange:addBatteryEventHandler("chargingtimechange", subscriptionEvents),
			dischargingtimechange:addBatteryEventHandler("dischargingtimechange", subscriptionEvents)
	};
};

//[20120615][chisu]modify battery to use EventHandlers
Battery.prototype.addEventListener = function(evt, handler, capture) {
 var e = evt.toLowerCase();
    if (typeof batteryEventHandlers[e] != 'undefined') {
        batteryEventHandlers[e].subscribe(handler);
    } 
};
Battery.prototype.removeEventListener = function(evt, handler, capture) {
var e = evt.toLowerCase();
    // If unsubcribing from an event that is handled by a plugin
    if (typeof batteryEventHandlers[e] != "undefined") {
        batteryEventHandlers[e].unsubscribe(handler);
    } 
};

/**
 * Event handlers for when callbacks get registered for the battery.
 * Keep track of how many handlers we have so we can start and stop the native battery listener
 * appropriately (and hopefully save on battery life!).
 */
Battery.prototype.onSubscribe = function() {
  var me = battery;
  // If we just registered the first handler, make sure native listener is started.
  if (handlers() === 1) {
    exec(me._status, me._error, "Battery", "start", []);
  }
};

Battery.prototype.onUnsubscribe = function() {
  var me = battery;

  // If we just unregistered the last handler, make sure native listener is stopped.
  if (handlers() === 0) {
      exec(null, null, "Battery", "stop", []);
  }
};

/**
 * Callback for battery status
 *
 * @param {Object} info            keys: level, isPlugged
 */
Battery.prototype._status = function(info) {
    if (info) {
        var me = battery;
        
        var level = me.level;
        var charging = me.charging;
        
        if (level != info.level) {
            // Fire levelchange event
        	me.level = info.level;
            me.charging = info.charging;
            
            //fireBatteryEvent("levelchange", info);
        	fireBatteryEvent("levelchange");
        }
        if(charging != info.charging){
        	me.charging = info.charging;
        	me.level = info.level;

        	fireBatteryEvent("chargingchange");
        }
    }
};

/**
 * Error callback for battery start
 */
Battery.prototype._error = function(e) {
    console.log("Error initializing Battery: " + e);
};

var battery = new Battery();

module.exports = battery;
});

//[20120719][chisu]capture apis
// file: lib/common/plugin/capture.js
sktdefine("srt/plugin/capture", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

/**
 * Launches a capture of different types.
 *
 * @param (DOMString} type
 * @param {Function} successCB
 * @param {Function} errorCB
 * @param {CaptureOption} options
 */
function _capture(type, successCallback, errorCallback, options) {
    var win = function(pluginResult){
    	successCallback(pluginResult);
    };
    exec(win, errorCallback, "Capture", type, [options]);
}
/**
 * The Capture interface exposes an interface to the camera and microphone of the hosting device.
 */
function Capture() {
    this.supportedAudioModes = [];
    this.supportedImageModes = [];
    this.supportedVideoModes = [];
}

/**
 * Launch audio recorder application for recording audio clip(s).
 *
 * @param {Function} successCB
 * @param {Function} errorCB
 * @param {CaptureAudioOptions} options
 */
Capture.prototype.captureAudio = function(successCallback, errorCallback, options){
    _capture("captureAudio", successCallback, errorCallback, options);
};

/**
 * Launch camera application for taking image(s).
 *
 * @param {Function} successCB
 * @param {Function} errorCB
 * @param {CaptureImageOptions} options
 */
Capture.prototype.captureImage = function(successCallback, errorCallback, options){
    _capture("captureImage", successCallback, errorCallback, options);
};

/**
 * Launch device camera application for recording video(s).
 *
 * @param {Function} successCB
 * @param {Function} errorCB
 * @param {CaptureVideoOptions} options
 */
Capture.prototype.captureVideo = function(successCallback, errorCallback, options){
    _capture("captureVideo", successCallback, errorCallback, options);
};


module.exports = new Capture();

});

//[20120724][chisu]indexedDB
//file: lib/common/plugin/indexedDB.js
sktdefine("srt/plugin/indexedDB", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var indexedDB = function() {
    
};

/**
 * open DB
 * @param name          {String} The name for the database
 * @param version          [Optional] {long} The version for the database
 */
indexedDB.prototype.open = function(name,version) {
	var dbOpenRequest = new IDBRequest();
	exec(// Success callback
			function(result) {
                //set javascript IDBDatabase
                var db = new IDBDatabase();
                    db.name = result.name;
                    db.version = result.version;
                    db.objectStoreNames = result.objectStoreNames;
         
				dbOpenRequest.result = db;
         
				// If onsuccess callback
				if (typeof dbOpenRequest.onsuccess === "function") {
					dbOpenRequest.onsuccess(new ProgressEvent("success", {target:dbOpenRequest}));
				}
			}, null, "IndexedDB", "open", [name,version]);

	return dbOpenRequest;
};

/**
 * open DB
 * @param name          {String} The name for the database
 */
indexedDB.prototype.deleteDatabase = function(name) {
	var dbDeleteRequest = new IDBRequest();
	exec(// Success callback
			function(result) {
				dbDeleteRequest.result = result;
				// If onsuccess callback
				if (typeof dbDeleteRequest.onsuccess === "function") {
					dbDeleteRequest.onsuccess(new ProgressEvent("success", {target:dbDeleteRequest}));
				}
			}, null, "IndexedDB", "deleteDatabase", [name]);

	return dbDeleteRequest;
};

module.exports = new indexedDB();
       
});

//[20120724][chisu]IDBRequest
//file: lib/common/plugin/IDBRequest.js
sktdefine("srt/plugin/IDBRequest", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var IDBRequest = function() {

    this.result = null;
    this.error = null;
    this.source = null;
    this.transaction = null;
    this.readyState = 0 ;
    
    // Event handlers
    this.onsuccess = null;   	 // The event handler for the success event
    this.onerror = null;        // When the read has failed (see errors).
};

module.exports = IDBRequest;

});

//[20120724][chisu]IDBDatabase
//file: lib/common/plugin/IDBDatabase.js
sktdefine("srt/plugin/IDBDatabase", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
  FileError = sktrequire('srt/plugin/FileError'),
  ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var IDBDatabase = function() {

  this.name = null;
  this.version = null;
  this.objectStoreNames = null;
  
  // Event handlers
  this.onabort = null;   	 	// The event handler for the abort event.
  this.onerror = null;        	// The event handler for the error event.
  this.onversionchange = null;  // The event handler for the versionchange event.
};

/**
 * This method creates and returns a new object store with the given name in the connected database
 * @param name          						 {String} The name for the database
 * @param optionalParameters          [Optional] {IDBObjectStoreParameters} The version for the database
 */
IDBDatabase.prototype.createObjectStore = function(name,optionalParameters) {
	
	var objectStore = new IDBObjectStore();

	objectStore.name = name;
	objectStore.keyPath = (optionalParameters && optionalParameters.keyPath && 
			typeof optionalParameters.keyPath == 'string') ? optionalParameters.keyPath : null;
	objectStore.autoIncrement = (optionalParameters && optionalParameters.autoIncrement && 
			typeof optionalParameters.autoIncrement == 'boolean') ? optionalParameters.autoIncrement : false;
       
	//return objectStore;
       exec(null
            ,function(result) {
                console.log(result);
                throw new FileError(FileError.PATH_EXISTS_ERR);
            }, "IndexedDB", "createObjectStore", [name,optionalParameters]);
	
	return objectStore;
};

/**
 * This method destroys the object store with the given name in the connected database
 * @param name          {String} The name for the database
 */
IDBDatabase.prototype.deleteObjectStore  = function(name) {
       exec(null, function(result) {
            console.log(result);
            }, "IndexedDB", "deleteObjectStore", [name]);
};

/**
 * This method, when called must execute the steps for creating a transaction in an asychronous fashion.
 * @param storeNames          {any} The names of object stores and indexes in the scope of the new transaction
 * @param mode          {DOMString} The mode for isolating access to data inside the given object stores
 */
IDBDatabase.prototype.transaction   = function(storeNames,mode) {
	var dbTransaction = new Transaction();

	dbTransaction.db = this;
	dbTransaction.mode = mode;
	dbTransaction.storeNames = storeNames;
	
	exec(// Success callback
		function(result) {
				// If onsuccess callback
				if (typeof dbTransaction.oncomplete === "function") {
					dbTransaction.oncomplete(new ProgressEvent("complete", {target:result}));
				}
			}, 
		function(e) {
				dbTransaction.error = e;
				// If error callback
				if (typeof dbTransaction.onerror === "function") {
					dbTransaction.onerror(new ProgressEvent("error", {target:e}));
				}
			}			
			, "IndexedDB", "transaction", [storeNames,mode]);

	return dbTransaction;
	
};
/**
 * This method returns immediately and performs the steps for closing a database connection.
 */
IDBDatabase.prototype.close  = function(name) {
	exec(null, null, "IndexedDB", "close", [name]);
};

module.exports = IDBDatabase;
});

//[20120724][chisu]IDBTransaction
//file: lib/common/plugin/IDBTransaction.js
sktdefine("srt/plugin/IDBTransaction", function(sktrequire, exports, module) {
         
 var IDBTransaction = function() {
        
  };
         
  IDBTransaction.READ_ONLY = 0;
  IDBTransaction.READ_WRITE = 1;
  IDBTransaction.VERSION_CAHNGE = 2;
         
  module.exports = IDBTransaction;
 });
  
//[20120724][chisu]Transaction
//file: lib/common/plugin/Transaction.js
sktdefine("srt/plugin/Transaction", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var Transaction = function() {

this.mode = null;
this.db = null;		 //IDBDatabase
this.error = null;

this.storeNames = null; //[20120731][chisu] this is no spec attribute, but we use it. 

// Event handlers
this.onabort = null;   	 	// The event handler for the abort event.
this.onerror = null;        	// The event handler for the error event.
this.oncomplete = null;  // The event handler for the complete event.
};

/**
* Returns an IDBObjectStore representing an object store that is part of the scope of this transaction
* @param name          						 {String} The requested object store
*/
Transaction.prototype.objectStore = function(name) {
	var idbObjectstore = new IDBObjectStore();

	idbObjectstore.name = name;
	idbObjectstore.transaction = this;
	idbObjectstore.keyPath = null;
	idbObjectstore.indexNames = null;
	idbObjectstore.autoIncremenent = null;
	
	exec(// Success callback
		function(objectstore) {
			
			idbObjectstore.keyPath = objectstore.keyPath;
			idbObjectstore.indexNames = objectstore.indexNames;
			idbObjectstore.autoIncremenent = objectstore.autoIncremenet;
			
			}, null, "IndexedDB", "objectStore", [name]);

	return idbObjectstore;	
};

/**
* If this transaction is finished, throw a DOMException of type InvalidStateError. 
* Otherwise this method sets the transaction's active flag to false and aborts the transaction 
* by running the steps for aborting a transaction with the error parameter set to null.
*/
Transaction.prototype.abort  = function() {
	//exec(null, null, "IndexedDB", "abort", []);
};

module.exports = Transaction;
});

//[20120724][chisu]IDBObjectStoreParameters
//file: lib/common/plugin/IDBObjectStoreParameters.js
sktdefine("srt/plugin/IDBObjectStoreParameters", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

var IDBObjectStoreParameters = function() {

this.keyPath = null;		//specifies the key path of the new object store. 
this.autoIncrement = false;	// specifies whether the object store created should have a key generator.
};

module.exports = IDBObjectStoreParameters;
});

//[20120724][chisu]IDBCursor
//file: lib/common/plugin/IDBCursor.js
sktdefine("srt/plugin/IDBCursor", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var IDBCursor = function() {

this.source = null;
this.direction = null;		 
this.key = null;
this.primaryKey = null;

//[20120803][chisu]not cursor spec attribute but we must use these below
this.name = null;
this.value = null;
this.request = null;
this.indexname = null;
this.type = "objectStore";
};

/**
* update data
* @param value   	The new value to store at the current position.
*/
IDBCursor.prototype.update = function(value) {
    var cursorUpdateRequest = new IDBRequest();
       
       if(this.type == "objectStore"){
          exec(// Success callback
               function(result) {
               cursorUpdateRequest.result = result;
               // If onsuccess callback
               if (typeof cursorUpdateRequest.onsuccess === "function") {
               cursorUpdateRequest.onsuccess(new ProgressEvent("success", {target:cursorUpdateRequest}));
               }
               },
               function(e) {
               cursorUpdateRequest.error = e;
               // If error callback
               if (typeof cursorUpdateRequest.onerror === "function") {
               cursorUpdateRequest.onerror(new ProgressEvent("error", {target:e}));
               }
               }
               , "IndexedDB", "update", [this.name,value]);
          }
       else if(this.type == "index"){
       exec(// Success callback
            function(result) {
            cursorUpdateRequest.result = result;
            // If onsuccess callback
            if (typeof cursorUpdateRequest.onsuccess === "function") {
            cursorUpdateRequest.onsuccess(new ProgressEvent("success", {target:cursorUpdateRequest}));
            }
            },
            function(e) {
            cursorUpdateRequest.error = e;
            // If error callback
            if (typeof cursorUpdateRequest.onerror === "function") {
            cursorUpdateRequest.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "indexupdate", [this.name,this.indexname, value]);
       }
      
       return cursorUpdateRequest;
};

/**
* The operation runs the steps for iterating a cursor count number of times with null as key and this cursor as cursor.
* @param count   	{long} The number of advances forward the cursor should make.
*/
IDBCursor.prototype.advance = function(count) {
       var continuereq = this.request;
       var storename = this.name;
       var indexname = this.indexname;
    
       if(this.type == "objectStore"){
       exec(// Success callback
            function(result) {
            var cursor = new IDBCursor();
            
            cursor.key = result.key;
            cursor.value = result.value;
            
            cursor.primaryKey = result.primaryKey;
            cursor.source = null;
            cursor.direction = null;
            
            cursor.name = storename;
            cursor.request = continuereq;
            continuereq.result = cursor;
            
            // If onsuccess callback
            if (typeof continuereq.onsuccess === "function") {
            continuereq.onsuccess(new ProgressEvent("success", {target:continuereq}));
            }
            
            }
            ,
            function(e) {
            continuereq.error = e;
            // If error callback
            if (typeof continuereq.onerror === "function") {
                continuereq.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "advance", [this.name,count]);
       }
       else if(this.type == "index"){
       exec(// Success callback
            function(result) {
            var cursor = new IDBCursor();
            
            cursor.key = result.key;
            cursor.value = result.value;
            cursor.primaryKey = result.primaryKey;
            cursor.source = null;
            cursor.direction = null;
            
            cursor.name = storename;
            cursor.indexname = indexname;
            cursor.request = continuereq;
            cursor.type = "index";
            continuereq.result = cursor;
             
            // If onsuccess callback
            if (typeof continuereq.onsuccess === "function") {
            continuereq.onsuccess(new ProgressEvent("success", {target:continuereq}));
            }
            
            }
            ,
            function(e) {
            continuereq.error = e;
            // If error callback
            if (typeof continuereq.onerror === "function") {
            continuereq.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "indexadvance", [this.name,this.indexname,count]);
       }
   
};

/**
* @param key   	{long} The next key to position this cursor at
*/
IDBCursor.prototype.continue = function(key) {
       var continuereq = this.request;
       var storename = this.name;
       var indexname = this.indexname;
       
       if(this.type == "objectStore"){
       if(key != null){
       exec(// Success callback
            function(result) {
            var cursor = new IDBCursor();
            
            cursor.key = result.key;
            cursor.value = result.value;
            cursor.primaryKey = result.primaryKey;
            cursor.source = null;
            cursor.direction = null;
            
            cursor.name = storename;
            cursor.request = continuereq;
            continuereq.result = cursor;
            
            // If onsuccess callback
            if (typeof continuereq.onsuccess === "function") {
            continuereq.onsuccess(new ProgressEvent("success", {target:continuereq}));
            }
            
            }
            ,
            function(e) {
            continuereq.error = e;
            // If error callback
            if (typeof continuereq.onerror === "function") {
            continuereq.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "continue", [this.name,key]);
       }
       else{
       exec(// Success callback
            function(result) {
            var cursor = new IDBCursor();
            
            cursor.key = result.key;
            cursor.value = result.value;
            cursor.primaryKey = result.primaryKey;
            cursor.source = null;
            cursor.direction = null;
            
            cursor.name = storename;
            cursor.request = continuereq;
            continuereq.result = cursor;
            
            // If onsuccess callback
            if (typeof continuereq.onsuccess === "function") {
            continuereq.onsuccess(new ProgressEvent("success", {target:continuereq}));
            }
            
            }
            ,
            function(e) {
            continuereq.error = e;
            // If error callback
            if (typeof continuereq.onerror === "function") {
            continuereq.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "continue", [this.name]);
       }
       }
       else if(this.type == "index"){
       if(key != null){
       exec(// Success callback
            function(result) {
            var cursor = new IDBCursor();
            
            cursor.key = result.key;
            cursor.value = result.value;
            cursor.primaryKey = result.primaryKey;
            cursor.source = null;
            cursor.direction = null;
            
            cursor.name = storename;
            cursor.indexname = indexname;
            cursor.request = continuereq;
            cursor.type = "index";
            continuereq.result = cursor;
            
            // If onsuccess callback
            if (typeof continuereq.onsuccess === "function") {
            continuereq.onsuccess(new ProgressEvent("success", {target:continuereq}));
            }
            
            }
            ,
            function(e) {
            continuereq.error = e;
            // If error callback
            if (typeof continuereq.onerror === "function") {
            continuereq.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "indexcontinue", [this.name,this.indexname, key]);
       }
       else{
       exec(// Success callback
            function(result) {
            var cursor = new IDBCursor();
            
            cursor.key = result.key;
            cursor.value = result.value;
            cursor.primaryKey = result.primaryKey;
            cursor.source = null;
            cursor.direction = null;
            
            cursor.name = storename;
            cursor.indexname = indexname;
            cursor.request = continuereq;
            cursor.type = "index";
            continuereq.result = cursor;
            
            // If onsuccess callback
            if (typeof continuereq.onsuccess === "function") {
            continuereq.onsuccess(new ProgressEvent("success", {target:continuereq}));
            }
            
            }
            ,
            function(e) {

            continuereq.error = e;
            // If error callback
            if (typeof continuereq.onerror === "function") {
            continuereq.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "indexcontinue", [this.name,this.indexname]);
        
       }
       }
       
       
};

/**
 *run with this IDBCursor as source and the steps for deleting records from an object store as operation
*/
IDBCursor.prototype.delete = function() {
    var cursorDeleteRequest = new IDBRequest();
       
       if(this.type == "objectStore"){
       exec(// Success callback
            function(result) {
            cursorDeleteRequest.result = result;
            // If onsuccess callback
            if (typeof cursorDeleteRequest.onsuccess === "function") {
            cursorDeleteRequest.onsuccess(new ProgressEvent("success", {target:cursorDeleteRequest}));
            }
            },
            function(e) {
            cursorDeleteRequest.error = e;
            // If error callback
            if (typeof cursorDeleteRequest.onerror === "function") {
            cursorDeleteRequest.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "deleteCursor", [this.name]);
       }
       else if(this.type == "index"){
       exec(// Success callback
            function(result) {
            cursorDeleteRequest.result = result;
            // If onsuccess callback
            if (typeof cursorDeleteRequest.onsuccess === "function") {
            cursorDeleteRequest.onsuccess(new ProgressEvent("success", {target:cursorDeleteRequest}));
            }
            },
            function(e) {
            cursorDeleteRequest.error = e;
            // If error callback
            if (typeof cursorDeleteRequest.onerror === "function") {
            cursorDeleteRequest.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "indexdeleteCursor", [this.name,this.indexname]);
       }
    
       
    return cursorDeleteRequest;
};

module.exports = IDBCursor;
});

//[20120724][chisu]IDBObjectStore
//file: lib/common/plugin/IDBObjectStore.js
sktdefine("srt/plugin/IDBObjectStore", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var IDBObjectStore = function() {

this.name = null;				//On getting, provide the name of this object store.
this.keyPath = null;			//On getting, provide the key path of this object store. This will be either a DOMString, an Array of DOMStrings or null.	 
this.indexNames = null;			//On getting, provide a list of the names of indexes on objects in this object store.
this.transaction = null;		//On getting, returns the transaction this object store belongs to.
this.autoIncremenent = null;	//On getting, provides the auto increment flag for this object store.

};

/**
* add data
* @param value   	The value to be stored in the record
* @param key   		[Optional]The key used to identify the record
*/
IDBObjectStore.prototype.add = function(value,key) {
	var dbAddRequest = new IDBRequest();
       if(key != null){
       exec(// Success callback
			function(result) {
            dbAddRequest.result = result;
            // If onsuccess callback
            if (typeof dbAddRequest.onsuccess === "function") {
            dbAddRequest.onsuccess(new ProgressEvent("success", {target:dbAddRequest}));
            }
			},
			function(e) {
            dbAddRequest.error = e;
            // If error callback
            if (typeof dbAddRequest.onerror === "function") {
            dbAddRequest.onerror(new ProgressEvent("error", {target:e}));
            }
			}
			, "IndexedDB", "add", [this.name,value,key]);
       }
       else{
       exec(// Success callback
			function(result) {
            dbAddRequest.result = result;
            // If onsuccess callback
            if (typeof dbAddRequest.onsuccess === "function") {
            dbAddRequest.onsuccess(new ProgressEvent("success", {target:dbAddRequest}));
            }
			},
			function(e) {
            dbAddRequest.error = e;
            // If error callback
            if (typeof dbAddRequest.onerror === "function") {
            dbAddRequest.onerror(new ProgressEvent("error", {target:e}));
            }
			}
			, "IndexedDB", "add", [this.name,value]);
       }

	return dbAddRequest;
};

/**
* clear data
*/
IDBObjectStore.prototype.clear = function() {
	var dbClearRequest = new IDBRequest();
	exec(// Success callback
			function(result) {
				dbClearRequest.result = result;
				// If onsuccess callback
				if (typeof dbClearRequest.onsuccess === "function") {
					dbClearRequest.onsuccess(new ProgressEvent("success", {target:dbClearRequest}));
				}
			},
			function(e) {
				dbClearRequest.error = e;
				// If error callback
				if (typeof dbClearRequest.onerror === "function") {
					dbClearRequest.onerror(new ProgressEvent("error", {target:e}));
				}
			}
			, "IndexedDB", "clear", [this.name]);

	return dbClearRequest;
};

/**
* get data count
* @param key   		[Optional]Key identifying the record to be retrieved. This can also be an IDBKeyRange.
*/
IDBObjectStore.prototype.count = function(key) {
	var dbCountRequest = new IDBRequest();
	exec(// Success callback
			function(result) {
				dbCountRequest.result = result;
				// If onsuccess callback
				if (typeof dbCountRequest.onsuccess === "function") {
					dbCountRequest.onsuccess(new ProgressEvent("success", {target:dbCountRequest}));
				}
			},
			function(e) {
				dbCountRequest.error = e;
				// If error callback
				if (typeof dbCountRequest.onerror === "function") {
					dbCountRequest.onerror(new ProgressEvent("error", {target:e}));
				}
			}
			, "IndexedDB", "count", [this.name,key]);
	return dbCountRequest;
};

/**
* This method creates and returns a new index with the given name and parameters in the connected database
* @param name   					The name of a new index
* @param keyPath   					[Optional]The key path used by the new index.
* @param optionalParameters   		[Optional]{IDBIndexParameters} The options object whose attributes are optional parameters to this function
*/
IDBObjectStore.prototype.createIndex = function(name,keyPath,optionalParameters) {

       var index = new IDBIndex();
       
       index.name = name;
       index.objectStore = this;
       index.keyPath = keyPath;
       index.unique = (optionalParameters && optionalParameters.unique &&
                              typeof optionalParameters.unique == 'boolean') ? optionalParameters.unique : false;
       index.multiEntry = (optionalParameters && optionalParameters.multiEntry &&
                                    typeof optionalParameters.multiEntry == 'boolean') ? optionalParameters.multiEntry : false;
       
       function sc(result){
        console.log("INDEX is create");
       }
       function ec(error){
       console.log("error is happend!!");
       }
              
       if(keyPath != null && optionalParameters != null){
        exec(sc, ec, "IndexedDB", "createIndex", [this.name, name,keyPath,optionalParameters]);
       }
       else if(keyPath != null && optionalParameters == null){
        exec(sc, ec, "IndexedDB", "createIndex", [this.name, name,keyPath]);
       }
       else if(keyPath == null && optionalParameters != null){
        exec(sc, ec, "IndexedDB", "createIndex", [this.name, name,null,optionalParameters]);
       }
      
       return index;
};

/**
* delete data
* @param key   				Key identifying the record to be deleted
*/
IDBObjectStore.prototype.delete = function(key) {
	var dbDeleteRequest = new IDBRequest();
	exec(// Success callback
			function(result) {
				dbDeleteRequest.result = result;
				// If onsuccess callback
				if (typeof dbDeleteRequest.onsuccess === "function") {
					dbDeleteRequest.onsuccess(new ProgressEvent("success", {target:dbDeleteRequest}));
				}
			},
			function(e) {
				dbDeleteRequest.error = e;
				// If error callback
				if (typeof dbDeleteRequest.onerror === "function") {
					dbDeleteRequest.onerror(new ProgressEvent("error", {target:e}));
				}
			}
			, "IndexedDB", "delete", [this.name,key]);
	return dbDeleteRequest;
};

/**
* delete index
* @param indexName   		The name of an existing index
*/
IDBObjectStore.prototype.deleteIndex = function(indexName) {
       function sc(result){
       console.log("delete index is success");
       }
       function ec(error){
       console.log(error);
       }
       
	exec(sc, ec, "IndexedDB", "deleteIndex", [this.name,indexName]);
};

/**
* get data
* @param key   		Key identifying the record to be retrieved.
*/
IDBObjectStore.prototype.get = function(key) {
	var dbGetRequest = new IDBRequest();
	exec(// Success callback
			function(result) {
				dbGetRequest.result = result;
				// If onsuccess callback
				if (typeof dbGetRequest.onsuccess === "function") {
					dbGetRequest.onsuccess(new ProgressEvent("success", {target:dbGetRequest}));
				}
			},
			function(e) {
				dbGetRequest.error = e;
				// If error callback
				if (typeof dbGetRequest.onerror === "function") {
					dbGetRequest.onerror(new ProgressEvent("error", {target:e}));
				}
			}
			, "IndexedDB", "get", [this.name,key]);
	
	return dbGetRequest;
};

/**
* Returns an IDBIndex representing an index that is part of the object store
* @param name   	The name of an existing index
*/
IDBObjectStore.prototype.index = function(name) {
    var index = new IDBIndex();
       index.name = name ;
       index.objectStore = this;
       
       function sc(result){

       
       }
	exec(sc, null, "IndexedDB", "index", [this.name,name]);
       
    return index;
};

/**
* method creates a cursor
* @param range   					[OptionalThe key range to use as the cursor's range
* @param direction   				[Optional]The cursor's required direction
*/
IDBObjectStore.prototype.openCursor = function(range,direction) {
       var openCursorRequest = new IDBRequest();
       var storename = this.name;
       exec(// Success callback
			function(result) {
                var cursor = new IDBCursor();
            
                cursor.key = result.key;
                cursor.value = result.value;
                cursor.primaryKey = result.primaryKey;
                cursor.source = null;
                cursor.direction = null;
            
                cursor.name = storename;
                cursor.request = openCursorRequest;
                cursor.type = "objectStore";
            
                openCursorRequest.result = cursor;
            
                // If onsuccess callback
                if (typeof openCursorRequest.onsuccess === "function") {
                openCursorRequest.onsuccess(new ProgressEvent("success", {target:openCursorRequest}));
                }
			},
			function(e) {
                openCursorRequest.error = e;
                // If error callback
                if (typeof openCursorRequest.onerror === "function") {
                openCursorRequest.onerror(new ProgressEvent("error", {target:e}));
                    }
			}, "IndexedDB", "openCursor", [this.name,range,direction]);
       
       return openCursorRequest;
};

/**
* put data
* @param value   	The value to be stored in the record
* @param key   		[Optional]The key used to identify the record
*/
IDBObjectStore.prototype.put = function(value,key) {
	var dbPutRequest = new IDBRequest();
       if(key != null){
       exec(// Success callback
			function(result) {
            dbPutRequest.result = result;
            // If onsuccess callback
            if (typeof dbPutRequest.onsuccess === "function") {
            dbPutRequest.onsuccess(new ProgressEvent("success", {target:dbPutRequest}));
            }
			},
			function(e) {
            dbPutRequest.error = e;
            // If error callback
            if (typeof dbPutRequest.onerror === "function") {
            dbPutRequest.onerror(new ProgressEvent("error", {target:e}));
            }
			}
			, "IndexedDB", "put", [this.name,value,key]);
       }
       else{
       exec(// Success callback
			function(result) {
            dbPutRequest.result = result;
            // If onsuccess callback
            if (typeof dbPutRequest.onsuccess === "function") {
            dbPutRequest.onsuccess(new ProgressEvent("success", {target:dbPutRequest}));
            }
			},
			function(e) {
            dbPutRequest.error = e;
            // If error callback
            if (typeof dbPutRequest.onerror === "function") {
            dbPutRequest.onerror(new ProgressEvent("error", {target:e}));
            }
			}
			, "IndexedDB", "put", [this.name,value]);
       }
	
	
	return dbPutRequest;
};

module.exports = IDBObjectStore;
});


//[20120730][chisu]IDBIndex
//file: lib/common/plugin/IDBIndex.js
sktdefine("srt/plugin/IDBIndex", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var IDBIndex = function() {

this.name = null;				
this.objectStore = null;			 
this.keyPath = null;			//On getting, provide the key path of this object store.
this.multiEntry = null;			//On getting, provide the multiEntry flag of this index.
this.unique = null;	

};

/**
* this method creates a cursor. The cursor must implement the IDBCursorWithValue interface.
* @param range   	[Optional]The key range to use as the cursor's range
* @param direction  [Optional]The cursor's required direction
*/
IDBIndex.prototype.openCursor = function(range,direction) {
              
    var openCursorRequest = new IDBRequest();
    var indexname = this.name;  // index name
    var objectstorename = this.objectStore.name; // object store name
     
    exec(// Success callback
        function(result) {
        var cursor = new IDBCursor();
        
        cursor.key = result.key;
        cursor.value = result.value;
        cursor.primaryKey = result.primaryKey;
        cursor.source = null;
        cursor.direction = null;
        
        cursor.name = objectstorename;
        cursor.indexname = indexname;
        cursor.request = openCursorRequest;
        cursor.type = "index";
        
        openCursorRequest.result = cursor;
            
        // If onsuccess callback
        if (typeof openCursorRequest.onsuccess === "function") {
        openCursorRequest.onsuccess(new ProgressEvent("success", {target:openCursorRequest}));
        }
        },
        function(e) {
        openCursorRequest.error = e;
        // If error callback
        if (typeof openCursorRequest.onerror === "function") {
        openCursorRequest.onerror(new ProgressEvent("error", {target:e}));
        }
         }, "IndexedDB", "indexopenCursor", [this.objectStore.name,this.name,range,direction]);
       
       return openCursorRequest;
};

/**
* this method creates a cursor. The cursor must implement the IDBCursor interface,
* but must not implement the IDBCursorWithValue interface.
* @param range   	[Optional]The key range to use as the cursor's range
* @param direction  [Optional]The cursor's required direction
*/
IDBIndex.prototype.openKeyCursor = function(range,direction) {
    var openCursorRequest = new IDBRequest();
    var indexname = this.name;
    
    exec(// Success callback
        function(result) {
        var cursor = new IDBCursor();
        
        cursor.key = result.key;
        cursor.value = result.value;
        cursor.primaryKey = result.primaryKey;
        cursor.source = null;
        cursor.direction = null;
        
        cursor.name = objectstorename;
        cursor.indexname = indexname;
        cursor.request = openCursorRequest;
        cursor.type = "index";
        
        openCursorRequest.result = cursor;
        
        // If onsuccess callback
        if (typeof openCursorRequest.onsuccess === "function") {
        openCursorRequest.onsuccess(new ProgressEvent("success", {target:openCursorRequest}));
        }
        },
        function(e) {
        openCursorRequest.error = e;
        // If error callback
        if (typeof openCursorRequest.onerror === "function") {
        openCursorRequest.onerror(new ProgressEvent("error", {target:e}));
        }
        }, "IndexedDB", "indexopenKeyCursor", [this.objectStore.name,this.name,range,direction]);
       
       return openCursorRequest;
};

/**
* @param key   	Key identifying the record to be retrieved. 
*/
IDBIndex.prototype.get = function(key) {
    var dbGetRequest = new IDBRequest();
    exec(// Success callback
        function(result) {
        dbGetRequest.result = result.value;
        // If onsuccess callback
        if (typeof dbGetRequest.onsuccess === "function") {
        dbGetRequest.onsuccess(new ProgressEvent("success", {target:dbGetRequest}));
        }
        },
        function(e) {
        dbGetRequest.error = e;
        // If error callback
        if (typeof dbGetRequest.onerror === "function") {
        dbGetRequest.onerror(new ProgressEvent("error", {target:e}));
        }
        }
        , "IndexedDB", "indexget", [this.objectStore.name,this.name,key]);
       
       return dbGetRequest;
       
};

/**
* @param key   	Key identifying the record to be retrieved. 
*/
IDBIndex.prototype.getKey = function(key) {
       var dbGetRequest = new IDBRequest();
       exec(// Success callback
            function(result) {
            dbGetRequest.result = result.key;
            // If onsuccess callback
            if (typeof dbGetRequest.onsuccess === "function") {
            dbGetRequest.onsuccess(new ProgressEvent("success", {target:dbGetRequest}));
            }
            },
            function(e) {
            dbGetRequest.error = e;
            // If error callback
            if (typeof dbGetRequest.onerror === "function") {
            dbGetRequest.onerror(new ProgressEvent("error", {target:e}));
            }
            }
            , "IndexedDB", "indexgetKey", [this.objectStore.name,this.name,key]);
       
       return dbGetRequest;
};

/**
* @param key   	[Optional]Key identifying the record to be retrieved. 
*/
IDBIndex.prototype.count = function(key) {
	exec(null, null, "IDBIndex", "count", [key]);
};

module.exports = IDBIndex;
});

//[20120730][chisu]IDBKeyRange
//file: lib/common/plugin/IDBKeyRange.js
sktdefine("srt/plugin/IDBKeyRange", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

var IDBKeyRange = function() {

this.lower = null;				//This value is the lower-bound of the key range.
this.upper = null;			 	//This value is the upper-bound of the key range.
this.lowerOpen = null;			//Returns false if the lower-bound value is included in the key range. Returns true 
								//if the lower-bound value is excluded from the key range.
this.upperOpen = null;			//Returns false if the upper-bound value is included in the key range.

};

/**
* Creates and returns a new key range with both lower and upper set to value and both lowerOpen and upperOpen set to false.
* @param value   	The key range to use as the cursor's range
*/
IDBKeyRange.prototype.only = function(value) {
	var keyrange = new IDBKeyRange();
	keyrange.lower = value;
	keyrange.upper = value;
	keyrange.lowerOpen = false;
	keyrange.upperOpen = false;
	return keyrange;
};

/**
* Creates and returns a new key range with lower set to lower, lowerOpen set to open, upper set to undefined and and upperOpen set to true.
* @param lower   	The lower bound value
* @param open   	[Optional]Set to false if the lower-bound should be included in the key range. 
*/
IDBKeyRange.prototype.lowerBound = function(value,open) {
	var keyrange = new IDBKeyRange();
	keyrange.lower = value;
	keyrange.upper = undefined;
	keyrange.lowerOpen = open;
	keyrange.upperOpen = true;
	return keyrange;
};

/**
* Creates and returns a new key range with lower set to undefined, lowerOpen set to true, upper set to upper and and upperOpen set to open.
* @param lower   	The upper bound value
* @param open   	[Optional]Set to false if the lower-bound should be included in the key range. 
*/
IDBKeyRange.prototype.upperBound = function(value,open) {
	var keyrange = new IDBKeyRange;
	keyrange.lower = undefined;
	keyrange.upper = value;
	keyrange.lowerOpen = true;
	keyrange.upperOpen = open;
	return keyrange;
};

/**
* Creates and returns a new key range with lower set to lower, lowerOpen set to lowerOpen, upper set to upper and upperOpen set to upperOpen.
* @param lower   	The lower-bound value
* @param upper   	The upper-bound value
* @param lowerOpen   	Set to false if the lower-bound should be included in the key range.
* @param upperOpen   	Set to false if the upper-bound should be included in the key range.
*/
IDBKeyRange.prototype.bound = function(lower,upper,lowerOpen,upperOpen) {
	var keyrange = new IDBKeyRange();
	keyrange.lower = lower;
	keyrange.upper = upper;
	keyrange.lowerOpen = lowerOpen;
	keyrange.upperOpen = upperOpen;
	return keyrange;
};

module.exports = new IDBKeyRange();
});



// file: lib/common/plugin/compass.js
sktdefine("srt/plugin/compass", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    utils = sktrequire('srt/utils'),
    CompassHeading = sktrequire('srt/plugin/CompassHeading'),
    CompassError = sktrequire('srt/plugin/CompassError'),
    timers = {},
    compass = {
        /**
         * Asynchronously acquires the current heading.
         * @param {Function} successCallback The function to call when the heading
         * data is available
         * @param {Function} errorCallback The function to call when there is an error
         * getting the heading data.
         * @param {CompassOptions} options The options for getting the heading data (not used).
         */
        getCurrentHeading:function(successCallback, errorCallback, options) {
            // successCallback required
            if (typeof successCallback !== "function") {
              console.log("Compass Error: successCallback is not a function");
              return;
            }

            // errorCallback optional
            if (errorCallback && (typeof errorCallback !== "function")) {
              console.log("Compass Error: errorCallback is not a function");
              return;
            }

            var win = function(result) {
                var ch = new CompassHeading(result.magneticHeading, result.trueHeading, result.headingAccuracy, result.timestamp);
                successCallback(ch);
            };
            var fail = function(code) {
                var ce = new CompassError(code);
                errorCallback(ce);
            };

            // Get heading
            exec(win, fail, "Compass", "getHeading", [options]);
        },

        /**
         * Asynchronously acquires the heading repeatedly at a given interval.
         * @param {Function} successCallback The function to call each time the heading
         * data is available
         * @param {Function} errorCallback The function to call when there is an error
         * getting the heading data.
         * @param {HeadingOptions} options The options for getting the heading data
         * such as timeout and the frequency of the watch. For iOS, filter parameter
         * specifies to watch via a distance filter rather than time.
         */
        watchHeading:function(successCallback, errorCallback, options) {
            // Default interval (100 msec)
            var frequency = (options !== undefined && options.frequency !== undefined) ? options.frequency : 100;
            var filter = (options !== undefined && options.filter !== undefined) ? options.filter : 0;

            // successCallback required
            if (typeof successCallback !== "function") {
              console.log("Compass Error: successCallback is not a function");
              return;
            }

            // errorCallback optional
            if (errorCallback && (typeof errorCallback !== "function")) {
              console.log("Compass Error: errorCallback is not a function");
              return;
            }

            var id = utils.createUUID();
            if (filter > 0) {
                // is an iOS request for watch by filter, no timer needed
                timers[id] = "iOS";
                compass.getCurrentHeading(successCallback, errorCallback, options);
            } else {
                // Start watch timer to get headings
                timers[id] = window.setInterval(function() {
                    compass.getCurrentHeading(successCallback, errorCallback);
                }, frequency);
            }

            return id;
        },

        /**
         * Clears the specified heading watch.
         * @param {String} watchId The ID of the watch returned from #watchHeading.
         */
        clearWatch:function(id) {
            // Stop javascript timer & remove from timer list
            if (id && timers[id]) {
                if (timers[id] != "iOS") {
                      clearInterval(timers[id]);
                  } else {
                    // is iOS watch by filter so call into device to stop
                    exec(null, null, "Compass", "stopHeading", []);
                }
                delete timers[id];
            }
        }
    };

module.exports = compass;
});

// file: lib/common/plugin/console-via-logger.js
sktdefine("srt/plugin/console-via-logger", function(sktrequire, exports, module) {
//------------------------------------------------------------------------------

var logger = sktrequire("srt/plugin/logger");
var utils  = sktrequire("srt/utils");

//------------------------------------------------------------------------------
// object that we're exporting
//------------------------------------------------------------------------------
var console = module.exports;

//------------------------------------------------------------------------------
// copy of the original console object
//------------------------------------------------------------------------------
var WinConsole = window.console;

//------------------------------------------------------------------------------
// whether to use the logger
//------------------------------------------------------------------------------
var UseLogger = false;

//------------------------------------------------------------------------------
// Timers
//------------------------------------------------------------------------------
var Timers = {};

//------------------------------------------------------------------------------
// used for unimplemented methods
//------------------------------------------------------------------------------
function noop() {}

//------------------------------------------------------------------------------
// used for unimplemented methods
//------------------------------------------------------------------------------
console.useLogger = function (value) {
    if (arguments.length) UseLogger = !!value;

    if (UseLogger) {
        if (logger.useConsole()) {
            throw new Error("console and logger are too intertwingly");
        }
    }

    return UseLogger;
};

//------------------------------------------------------------------------------
console.log = function() {
    if (logger.useConsole()) return;
    logger.log.apply(logger, [].slice.call(arguments));
};

//------------------------------------------------------------------------------
console.error = function() {
    if (logger.useConsole()) return;
    logger.error.apply(logger, [].slice.call(arguments));
};

//------------------------------------------------------------------------------
console.warn = function() {
    if (logger.useConsole()) return;
    logger.warn.apply(logger, [].slice.call(arguments));
};

//------------------------------------------------------------------------------
console.info = function() {
    if (logger.useConsole()) return;
    logger.info.apply(logger, [].slice.call(arguments));
};

//------------------------------------------------------------------------------
console.debug = function() {
    if (logger.useConsole()) return;
    logger.debug.apply(logger, [].slice.call(arguments));
};

//------------------------------------------------------------------------------
console.assert = function(expression) {
    if (expression) return;

    var message = utils.vformat(arguments[1], [].slice.call(arguments, 2));
    console.log("ASSERT: " + message);
};

//------------------------------------------------------------------------------
console.clear = function() {};

//------------------------------------------------------------------------------
console.dir = function(object) {
    console.log("%o", object);
};

//------------------------------------------------------------------------------
console.dirxml = function(node) {
    console.log(node.innerHTML);
};

//------------------------------------------------------------------------------
console.trace = noop;

//------------------------------------------------------------------------------
console.group = console.log;

//------------------------------------------------------------------------------
console.groupCollapsed = console.log;

//------------------------------------------------------------------------------
console.groupEnd = noop;

//------------------------------------------------------------------------------
console.time = function(name) {
    Timers[name] = new Date().valueOf();
};

//------------------------------------------------------------------------------
console.timeEnd = function(name) {
    var timeStart = Timers[name];
    if (!timeStart) {
        console.warn("unknown timer: " + name);
        return;
    }

    var timeElapsed = new Date().valueOf() - timeStart;
    console.log(name + ": " + timeElapsed + "ms");
};

//------------------------------------------------------------------------------
console.timeStamp = noop;

//------------------------------------------------------------------------------
console.profile = noop;

//------------------------------------------------------------------------------
console.profileEnd = noop;

//------------------------------------------------------------------------------
console.count = noop;

//------------------------------------------------------------------------------
console.exception = console.log;

//------------------------------------------------------------------------------
console.table = function(data, columns) {
    console.log("%o", data);
};

//------------------------------------------------------------------------------
// return a new function that calls both functions passed as args
//------------------------------------------------------------------------------
function wrapperedOrigCall(orgFunc, newFunc) {
    return function() {
        var args = [].slice.call(arguments);
        try { orgFunc.apply(WinConsole, args); } catch (e) {}
        try { newFunc.apply(console,    args); } catch (e) {}
    };
}

//------------------------------------------------------------------------------
// For every function that exists in the original console object, that
// also exists in the new console object, wrap the new console method
// with one that calls both
//------------------------------------------------------------------------------
for (var key in console) {
    if (typeof WinConsole[key] == "function") {
        console[key] = wrapperedOrigCall(WinConsole[key], console[key]);
    }
}

});

//[20120625][chisu]add CalendarError
//file: lib/common/plugin/CalendarError.js
sktdefine("srt/plugin/CalendarError", function(sktrequire, exports, module) {
/**
*  CalendarError.
*  An error code assigned by an implementation when an error has occured
* @constructor
*/
var CalendarError = function(err) {
  this.code = (typeof err != 'undefined' ? err : null);
};

/**
* Error codes
*/
CalendarError.UNKNOWN_ERROR = 0;
CalendarError.INVALID_ARGUMENT_ERROR = 1;
CalendarError.TIMEOUT_ERROR = 2;
CalendarError.PENDING_OPERATION_ERROR = 3;
CalendarError.IO_ERROR = 4;
CalendarError.NOT_SUPPORTED_ERROR = 5;
CalendarError.PERMISSION_DENIED_ERROR = 20;

module.exports = CalendarError;
});

//[20120625][chisu]add CalendarRepeatRule
//file: lib/common/plugin/CalendarRepeatRule.js
sktdefine("srt/plugin/CalendarRepeatRule", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
	utils = sktrequire('srt/utils');

/**
* Contains information about a single CalendarRepeatRule.
* @constructor
* @param {DOMString} frequency
* @param {short} interval
* @param {DOMString} expires
* @param {Array.<DOMString>} exceptionDates
* @param {Array.<DOMString>} daysInWeek
* @param {Array.<DOMString>} daysInMonth
* @param {Array.<DOMString>} daysInYear
* @param {Array.<DOMString>} weeksInMonth
* @param {Array.<DOMString>} monthsInYear
*/
var CalendarRepeatRule = function (frequency, interval, expires, exceptionDates, daysInWeek, daysInMonth, daysInYear,
		weeksInMonth, monthsInYear) {
  this.frequency = frequency || null;
  this.interval = interval || null;
  if(device.platform == 'Android') {
     this.expires = new Date(expires) || null; 
  } else {
     this.expires = expires || null; 
  }
  
  this.exceptionDates = exceptionDates || null;
  this.daysInWeek = daysInWeek || null; 
  this.daysInMonth = daysInMonth || null; 
  this.daysInYear = daysInYear || null; 
  this.weeksInMonth = weeksInMonth || null; 
  this.monthsInYear = monthsInYear || null; 
};

module.exports = CalendarRepeatRule;

});

//file: lib/common/plugin/CalendarFindOptions.js
sktdefine("srt/plugin/CalendarFindOptions", function(sktrequire, exports, module) {
/**
 * CalendarFindOptions.
 * @constructor
 * @param filter used to match [CalendarEventFilter], nullable
 * @param multiple boolean used to determine if more than one contact should be returned
 */

var CalendarFindOptions = function(filter, multiple) {
    this.filter = filter || '';
    this.multiple = (typeof multiple != 'undefined' ? multiple : false);
};

module.exports = CalendarFindOptions;
});

//file: lib/common/plugin/CalendarEventFilter.js
sktdefine("srt/plugin/CalendarEventFilter", function(sktrequire, exports, module) {
/**
 * CalendarEventFilter.
 * @constructor
 * @param endAfter  Search for Calendar Events that end after the time provided as a valid date or time string.
 * @param endBefore   Search for Calendar Events that end before the time provided as a valid date or time string
 * @param startAfter   Search for Calendar Events that start after the time provided as a valid date or time string.
 * @param startBefore   Search for Calendar Events that start before the time provided as a valid date or time string..
 * @param {DOMString} id unique identifier
 * @param {DOMString} description
 * @param {DOMString} location
 * @param {DOMString} summary
 * @param {DOMString} start
 * @param {DOMString} end
 * @param {DOMString} status
 * @param {DOMString} trasparency
 * @param {CalendarRepeatRule} recurrence
 * @param {DOMString} reminder
 */

var CalendarEventFilter = function(endAfter, endBefore,startAfter,startBefore,id, description, location, 
		summary, start, end, status,trasparency, recurrence, reminder) {
	this.endAfter = endAfter || null;
    this.endBefore = endBefore || null;
    this.startAfter = startAfter || null; 
    this.startBefore = startBefore || null;
    this.id = id || null;
    this.description = description || null;
    this.location = location || null; 
    this.summary = summary || null;
    this.start = start || null; 
    this.end = end || null; 
    this.status = status || null; 
    this.trasparency = trasparency || null; 
    this.recurrence = recurrence || null; // CalendarRepeatRule
    this.reminder = reminder || null;
};

module.exports = CalendarEventFilter;
});

//[20120625][chisu]add CalendarEvent
//file: lib/common/plugin/CalendarEvent.js
sktdefine("srt/plugin/CalendarEvent", function(sktrequire, exports, module) {
var CalendarError = sktrequire('srt/plugin/CalendarError'),
    utils = sktrequire('srt/utils');

/**
* Contains information about a single calendarEvent.
* @constructor
* @param {DOMString} id unique identifier
* @param {DOMString} description
* @param {DOMString} location
* @param {DOMString} summary
* @param {DOMString} start
* @param {DOMString} end
* @param {DOMString} status
* @param {DOMString} trasparency
* @param {CalendarRepeatRule} recurrence
* @param {DOMString} reminder
*/
var CalendarEvent = function (id, description, location, summary, start, end, status,
		trasparency, recurrence, reminder) {
    this.id = id || null;
    this.description = description || null;
    this.location = location || null; 
    this.summary = summary || null;
    if(device.platform == 'Android') {
       this.start = new Date(start) || null; 
       this.end = new Date(end) || null;
    } else {
       this.start = start || null; 
       this.end = end || null;
    }
    this.status = status || null; 
    this.trasparency = trasparency || null; 
    this.recurrence = recurrence || null; // CalendarRepeatRule
    this.reminder = reminder || null;
};


/**
* Creates a deep copy of this CalendarEvent.
* With the CalendarEvent ID set to null.
* @return copy of this CalendarEvent
*/
CalendarEvent.prototype.clone = function() {
    var clonedCalendarEvent = utils.clone(this);
    clonedCalendarEvent.id = null;
    return clonedContact;
};

module.exports = CalendarEvent;

});

//[20120625][chisu]add calendar
//file: lib/common/plugin/calendar.js
sktdefine("srt/plugin/calendar", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    CalendarError = sktrequire('srt/plugin/CalendarError'),
    utils = sktrequire('srt/utils'),
    CalendarEvent = sktrequire('srt/plugin/CalendarEvent');

function makeRecurrence(recurrence){
	var i;
	var repeatrule = new CalendarRepeatRule();
	for (i in recurrence) {
		if (typeof repeatrule[i] !== 'undefined' && recurrence.hasOwnProperty(i)) {
			if(i =="expires"){
				repeatrule[i] = new Date(recurrence[i]);//toUTCString
			}
			else
				repeatrule[i] = recurrence[i];            		
		}
	}
	return repeatrule;
}

function makeFilterForAndrpoid(filter){
	var i;
    var androidFilter = new CalendarEventFilter ();
    for (i in filter) {
        if (typeof androidFilter[i] !== 'undefined' && filter.hasOwnProperty(i)) {
        	if(i =="start" || i =="end" || i =="endAfter" ||i =="endBefore"||i =="startAfter" ||i =="startBefore"){
        		//androidFilter[i] = new Date(filter[i]).toGMTString();//toUTCString
        		androidFilter[i] = new Date(filter[i]);
        	}
        	else if(i == "recurrence"){
        		androidFilter[i] = makeRecurrence(filter[i]);
        	}
        	else{
        		androidFilter[i] = filter[i];            		
        	}
        }
    }
    return androidFilter;
}

function createEventFromNative(properties) {
	var i;
    var event = new CalendarEvent();
    for (i in properties) {
        if (typeof event[i] !== 'undefined' && properties.hasOwnProperty(i)) {
        	event[i] = properties[i];
        }
    }
    return event;
}

/**
* Represents a group of calendar.
* @constructor
*/
var calendar = {
		
	//[20120622][chisu]add addEvent function 
	/**
	 * Returns an Event added in storage.
	 * @param successCB success callback
	 * @param errorCB error callback
	 * @param {CalendarEvent} CalendarEvent added in storage
	 * @return an CalendarEvent added in storagea
	 */
	addEvent:function(successCB, errorCB, event) {
		if (!successCB) {
			throw new TypeError("You must specify a success callback for the add command.");
		}
		else if(typeof sccessCB === 'function'){
			throw new TypeError("You must specify a success callback for the fiaddnd command.");
		}
		if (!event) {
			if (typeof errorCB === "function") {
				errorCB(new CalendarError(CalendarError.INVALID_ARGUMENT_ERROR));
			}
		} 
		else {
			var win = function(result) {
				var cs = calendar.createEvent(result);
				successCB(cs);
			};
			var fail = function(code) {
			      errorCB(new CalendarError(code));
			  };
			exec(win, fail, "Calendar", "addEvent", [event]);
		}
	},
	
	//[20120622][chisu]add deleteEvent function 
	/**
	 * Removes event from device storage.
	 * @param successCB success callback
	 * @param errorCB error callback
	 * @param {String} Event id to be removed
	 */
	deleteEvent:function(successCB, errorCB, id) {
		if (!successCB) {
			throw new TypeError("You must specify a success callback for the deleteEvent command.");
		}
		else if(typeof sccessCB === 'function'){
			throw new TypeError("You must specify a success callback for the deleteEvent command.");
		}
		if (id == null) {
			if (typeof errorCB === "function") {
				errorCB(new CalendarError(CalendarError.INVALID_ARGUMENT_ERROR));
			}
		} 
		else {
			var fail = function(code) {
			      errorCB(new CalendarError(code));
			  };
			exec(successCB, fail, "Calendar", "deleteEvent", [id]);
		}
	},
	
    /**
     * Returns an array of Events matching the search criteria.
     * @param successCB success callback
     * @param errorCB error callback
     * @param {CalendarFindOptions} options that can be applied to event searching
     * @return array of Events matching search criteria
     */
    findEvents:function(successCB, errorCB, options) {
        if (!successCB) {
            throw new TypeError("You must specify a success callback for the find command.");
        }
        else {
            var win = function(result) {
                var cs = [];
                for (var i = 0, l = result.length; i < l; i++) {
                    cs.push(calendar.createEvent(result[i]));
                }
                successCB(cs);
            };
            //make date property of options to Date();
            if(options != null && options.hasOwnProperty("filter") && device.platform == 'Android'){
            	options.filter = makeFilterForAndrpoid(options.filter);
            }
            exec(win, errorCB, "Calendar", "findEvents", [options]);
        }
    },

    /**
     * This function creates a new calendarEvent, but it does not persist the calendarevent
     * to device storage. To persist the evnets to device storage, invoke
     * calendar.addEvent().
     * @param properties an object who's properties will be examined to create a new CalendarEvent
     * @returns new CalendarEvent object
     */
    createEvent:function(properties) {
        var i;
        var event = new CalendarEvent();
        for (i in properties) {
            if (typeof event[i] !== 'undefined' && properties.hasOwnProperty(i)) {
            	if(device.platform == 'Android') {
                  if(i =="start" || i =="end"){
                    event[i] = new Date(properties[i]);//toUTCString
                  }
                  else if(i == "recurrence"){
                    event[i] = makeRecurrence(properties[i]);
                  } else {
                    event[i] = properties[i];
                  }
              } else {           	
                event[i] = properties[i];
              }
            }
        }
        return event;
    }
};

module.exports = calendar;

});

// file: lib/common/plugin/contacts.js
sktdefine("srt/plugin/contacts", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    ContactError = sktrequire('srt/plugin/ContactError'),
    utils = sktrequire('srt/utils'),
    Contact = sktrequire('srt/plugin/Contact');

/**
* Represents a group of Contacts.
* @constructor
*/
var contacts = {
		
	//[20120622][chisu]add add function 
	/**
	 * Returns an Contact added in storage.
	 * @param successCB success callback
	 * @param errorCB error callback
	 * @param {Contact} Contact added in storage
	 * @return an Contact added in storagea
	 */
	add:function(successCB, errorCB, contact) {
		if (!successCB) {
			throw new TypeError("You must specify a success callback for the add command.");
		}
		else if(typeof sccessCB === 'function'){
			throw new TypeError("You must specify a success callback for the fiaddnd command.");
		}
		if (!contact) {
			if (typeof errorCB === "function") {
				errorCB(new ContactError(ContactError.INVALID_ARGUMENT_ERROR));
			}
		} 
		else {
			var win = function(result) {
				var cs = contacts.create(result);
				successCB(cs);
			};
			var fail = function(code) {
			      errorCB(new ContactError(code));
			  };
			exec(win, fail, "Contacts", "add", [contact]);
		}
	},
	
	//[20120622][chisu]add remove function 
	/**
	 * Removes contact from device storage.
	 * @param successCB success callback
	 * @param errorCB error callback
	 * @param {String} Contact id to be removed
	 */
	remove:function(successCB, errorCB, id) {
		if (!successCB) {
			throw new TypeError("You must specify a success callback for the detele command.");
		}
		else if(typeof sccessCB === 'function'){
			throw new TypeError("You must specify a success callback for the detele command.");
		}
		if (id == null) {
			if (typeof errorCB === "function") {
				errorCB(new ContactError(ContactError.INVALID_ARGUMENT_ERROR));
			}
		} 
		else {
			var fail = function(code) {
			      errorCB(new ContactError(code));
			  };
			exec(successCB, fail, "Contacts", "remove", [id]);
		}
	},
	
    /**
     * Returns an array of Contacts matching the search criteria.
     * @param fields that should be searched
     * @param successCB success callback
     * @param errorCB error callback
     * @param {ContactFindOptions} options that can be applied to contact searching
     * @return array of Contacts matching search criteria
     */
    find:function(fields, successCB, errorCB, options) {
        if (!successCB) {
            throw new TypeError("You must specify a success callback for the find command.");
        }
        if (!fields || (utils.isArray(fields) && fields.length === 0)) {
            if (typeof errorCB === "function") {
                errorCB(new ContactError(ContactError.INVALID_ARGUMENT_ERROR));
            }
        } else {
            var win = function(result) {
                var cs = [];
                for (var i = 0, l = result.length; i < l; i++) {
                    cs.push(contacts.create(result[i]));
                }
                successCB(cs);
            };
            exec(win, errorCB, "Contacts", "search", [fields, options]);
        }
    },

    /**
     * This function creates a new contact, but it does not persist the contact
     * to device storage. To persist the contact to device storage, invoke
     * contact.add().
     * @param properties an object who's properties will be examined to create a new Contact
     * @returns new Contact object
     */
    create:function(properties) {
        var i;
        var contact = new Contact();
        for (i in properties) {
            if (typeof contact[i] !== 'undefined' && properties.hasOwnProperty(i)) {
                contact[i] = properties[i];
            }
        }
        return contact;
    }
};

module.exports = contacts;

});

// file: lib/common/plugin/geolocation.js
sktdefine("srt/plugin/geolocation", function(sktrequire, exports, module) {
var utils = sktrequire('srt/utils'),
    exec = sktrequire('srt/exec'),
    PositionError = sktrequire('srt/plugin/PositionError'),
    Position = sktrequire('srt/plugin/Position');

var timers = {};   // list of timers in use

// Returns default params, overrides if provided with values
function parseParameters(options) {
    var opt = {
        maximumAge: 0,
        enableHighAccuracy: false,
        timeout: Infinity
    };

    if (options) {
        if (options.maximumAge !== undefined && !isNaN(options.maximumAge) && options.maximumAge > 0) {
            opt.maximumAge = options.maximumAge;
        }
        if (options.enableHighAccuracy !== undefined) {
            opt.enableHighAccuracy = options.enableHighAccuracy;
        }
        if (options.timeout !== undefined && !isNaN(options.timeout)) {
            if (options.timeout < 0) {
                opt.timeout = 0;
            } else {
                opt.timeout = options.timeout;
            }
        }
    }

    return opt;
}

// Returns a timeout failure, closed over a specified timeout value and error callback.
function createTimeout(errorCallback, timeout) {
    var t = setTimeout(function() {
        clearTimeout(t);
        t = null;
        errorCallback({
            code:PositionError.TIMEOUT,
            message:"Position retrieval timed out."
        });
    }, timeout);
    return t;
}

var geolocation = {
    lastPosition:null, // reference to last known (cached) position returned
    /**
   * Asynchronously aquires the current position.
   *
   * @param {Function} successCallback    The function to call when the position data is available
   * @param {Function} errorCallback      The function to call when there is an error getting the heading position. (OPTIONAL)
   * @param {PositionOptions} options     The options for getting the position data. (OPTIONAL)
   */
    getCurrentPosition:function(successCallback, errorCallback, options) {
        if (arguments.length === 0) {
            throw new Error("getCurrentPosition must be called with at least one argument.");
        }
        options = parseParameters(options);

        // Timer var that will fire an error callback if no position is retrieved from native
        // before the "timeout" param provided expires
        var timeoutTimer = null;

        var win = function(p) {
            clearTimeout(timeoutTimer);
            if (!timeoutTimer) {
                // Timeout already happened, or native fired error callback for
                // this geo request.
                // Don't continue with success callback.
                return;
            }
            var pos = new Position(
                {
                    latitude:p.latitude,
                    longitude:p.longitude,
                    altitude:p.altitude,
                    accuracy:p.accuracy,
                    heading:p.heading,
                    velocity:p.velocity,
                    altitudeAccuracy:p.altitudeAccuracy
                },
                (p.timestamp === undefined ? new Date() : ((p.timestamp instanceof Date) ? p.timestamp : new Date(p.timestamp)))
            );
            geolocation.lastPosition = pos;
            successCallback(pos);
        };
        var fail = function(e) {
            clearTimeout(timeoutTimer);
            timeoutTimer = null;
            var err = new PositionError(e.code, e.message);
            if (errorCallback) {
                errorCallback(err);
            }
        };

        // Check our cached position, if its timestamp difference with current time is less than the maximumAge, then just
        // fire the success callback with the cached position.
        if (geolocation.lastPosition && options.maximumAge && (((new Date()).getTime() - geolocation.lastPosition.timestamp.getTime()) <= options.maximumAge)) {
            successCallback(geolocation.lastPosition);
        // If the cached position check failed and the timeout was set to 0, error out with a TIMEOUT error object.
        } else if (options.timeout === 0) {
            fail({
                code:PositionError.TIMEOUT,
                message:"timeout value in PositionOptions set to 0 and no cached Position object available, or cached Position object's age exceed's provided PositionOptions' maximumAge parameter."
            });
        // Otherwise we have to call into native to retrieve a position.
        } else {
            if (options.timeout !== Infinity) {
                // If the timeout value was not set to Infinity (default), then
                // set up a timeout function that will fire the error callback
                // if no successful position was retrieved before timeout expired.
                timeoutTimer = createTimeout(fail, options.timeout);
            } else {
                // This is here so the check in the win function doesn't mess stuff up
                // may seem weird but this guarantees timeoutTimer is
                // always truthy before we call into native
                timeoutTimer = true;
            }
            exec(win, fail, "Geolocation", "getLocation", [options.enableHighAccuracy, options.maximumAge]);
        }
        return timeoutTimer;
    },
    /**
     * Asynchronously watches the geolocation for changes to geolocation.  When a change occurs,
     * the successCallback is called with the new location.
     *
     * @param {Function} successCallback    The function to call each time the location data is available
     * @param {Function} errorCallback      The function to call when there is an error getting the location data. (OPTIONAL)
     * @param {PositionOptions} options     The options for getting the location data such as frequency. (OPTIONAL)
     * @return String                       The watch id that must be passed to #clearWatch to stop watching.
     */
    watchPosition:function(successCallback, errorCallback, options) {
        if (arguments.length === 0) {
            throw new Error("watchPosition must be called with at least one argument.");
        }
        options = parseParameters(options);

        var id = utils.createUUID();

        // Tell device to get a position ASAP, and also retrieve a reference to the timeout timer generated in getCurrentPosition
        timers[id] = geolocation.getCurrentPosition(successCallback, errorCallback, options);

        var fail = function(e) {
            clearTimeout(timers[id]);
            var err = new PositionError(e.code, e.message);
            if (errorCallback) {
                errorCallback(err);
            }
        };

        var win = function(p) {
            clearTimeout(timers[id]);
            if (options.timeout !== Infinity) {
                timers[id] = createTimeout(fail, options.timeout);
            }
            var pos = new Position(
                {
                    latitude:p.latitude,
                    longitude:p.longitude,
                    altitude:p.altitude,
                    accuracy:p.accuracy,
                    heading:p.heading,
                    velocity:p.velocity,
                    altitudeAccuracy:p.altitudeAccuracy
                },
                (p.timestamp === undefined ? new Date() : ((p.timestamp instanceof Date) ? p.timestamp : new Date(p.timestamp)))
            );
            geolocation.lastPosition = pos;
            successCallback(pos);
        };

        exec(win, fail, "Geolocation", "addWatch", [id, options.enableHighAccuracy]);

        return id;
    },
    /**
     * Clears the specified heading watch.
     *
     * @param {String} id       The ID of the watch returned from #watchPosition
     */
    clearWatch:function(id) {
        if (id && timers[id] !== undefined) {
            clearTimeout(timers[id]);
            delete timers[id];
            exec(null, null, "Geolocation", "clearWatch", [id]);
        }
    }
};

module.exports = geolocation;

});

// file: lib/ios/plugin/ios/Contact.js
sktdefine("srt/plugin/ios/Contact", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    ContactError = sktrequire('srt/plugin/ContactError');

/**
 * Provides iOS Contact.display API.
 */
module.exports = {
    display : function(errorCB, options) {
        /*
         *    Display a contact using the iOS Contact Picker UI
         *    NOT part of W3C spec so no official documentation
         *
         *    @param errorCB error callback
         *    @param options object
         *    allowsEditing: boolean AS STRING
         *        "true" to allow editing the contact
         *        "false" (default) display contact
         */

        if (this.id === null) {
            if (typeof errorCB === "function") {
                var errorObj = new ContactError(ContactError.UNKNOWN_ERROR);
                errorCB(errorObj);
            }
        }
        else {
            exec(null, errorCB, "Contacts","displayContact", [this.id, options]);
        }
    }
};
});

// file: lib/ios/plugin/ios/Entry.js
sktdefine("srt/plugin/ios/Entry", function(sktrequire, exports, module) {
module.exports = {
    toURL:function() {
        // TODO: refactor path in a cross-platform way so we can eliminate
        // these kinds of platform-specific hacks.
        return "file://localhost" + this.fullPath;
    },
    toURI: function() {
        console.log("DEPRECATED: Update your code to use 'toURL'");
        return "file://localhost" + this.fullPath;
    }
};
});

// file: lib/ios/plugin/ios/FileReader.js
sktdefine("srt/plugin/ios/FileReader", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    FileError = sktrequire('srt/plugin/FileError'),
    FileReader = sktrequire('srt/plugin/FileReader'),
    ProgressEvent = sktrequire('srt/plugin/ProgressEvent');

module.exports = {
    readAsText:function(file, encoding) {
        // Figure out pathing
        this.fileName = '';
        if (typeof file.fullPath === 'undefined') {
            this.fileName = file;
        } else {
            this.fileName = file.fullPath;
        }

        // Already loading something
        if (this.readyState == FileReader.LOADING) {
            throw new FileError(FileError.INVALID_STATE_ERR);
        }

        // LOADING state
        this.readyState = FileReader.LOADING;

        // If loadstart callback
        if (typeof this.onloadstart === "function") {
            this.onloadstart(new ProgressEvent("loadstart", {target:this}));
        }

        // Default encoding is UTF-8
        var enc = encoding ? encoding : "UTF-8";

        var me = this;

        // Read file
        exec(
            // Success callback
            function(r) {
                // If DONE (cancelled), then don't do anything
                if (me.readyState === FileReader.DONE) {
                    return;
                }

                // Save result
                me.result = decodeURIComponent(r);

                // If onload callback
                if (typeof me.onload === "function") {
                    me.onload(new ProgressEvent("load", {target:me}));
                }

                // DONE state
                me.readyState = FileReader.DONE;

                // If onloadend callback
                if (typeof me.onloadend === "function") {
                    me.onloadend(new ProgressEvent("loadend", {target:me}));
                }
            },
            // Error callback
            function(e) {
                // If DONE (cancelled), then don't do anything
                if (me.readyState === FileReader.DONE) {
                    return;
                }

                // DONE state
                me.readyState = FileReader.DONE;

                // null result
                me.result = null;

                // Save error
                me.error = new FileError(e);

                // If onerror callback
                if (typeof me.onerror === "function") {
                    me.onerror(new ProgressEvent("error", {target:me}));
                }

                // If onloadend callback
                if (typeof me.onloadend === "function") {
                    me.onloadend(new ProgressEvent("loadend", {target:me}));
                }
            },
        "File", "readAsText", [this.fileName, enc]);
    }
};
});

// file: lib/ios/plugin/ios/console.js
sktdefine("srt/plugin/ios/console", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

/**
 * This class provides access to the debugging console.
 * @constructor
 */
var DebugConsole = function() {
    this.winConsole = window.console;
    this.logLevel = DebugConsole.INFO_LEVEL;
};

// from most verbose, to least verbose
DebugConsole.ALL_LEVEL    = 1; // same as first level
DebugConsole.INFO_LEVEL   = 1;
DebugConsole.WARN_LEVEL   = 2;
DebugConsole.ERROR_LEVEL  = 4;
DebugConsole.NONE_LEVEL   = 8;

DebugConsole.prototype.setLevel = function(level) {
    this.logLevel = level;
};

var stringify = function(message) {
    try {
        if (typeof message === "object" && JSON && JSON.stringify) {
            try {
                return JSON.stringify(message);
            }
            catch (e) {
                return "error JSON.stringify()ing argument: " + e;
            }
        } else {
            return message.toString();
        }
    } catch (e) {
        return e.toString();
    }
};

/**
 * Print a normal log message to the console
 * @param {Object|String} message Message or object to print to the console
 */
DebugConsole.prototype.log = function(message) {
    if (this.logLevel <= DebugConsole.INFO_LEVEL) {
        exec(null, null, 'Debug Console', 'log', [ stringify(message), { logLevel: 'INFO' } ]);
    }
    else if (this.winConsole && this.winConsole.log) {
        this.winConsole.log(message);
    }
};

/**
 * Print a warning message to the console
 * @param {Object|String} message Message or object to print to the console
 */
DebugConsole.prototype.warn = function(message) {
    if (this.logLevel <= DebugConsole.WARN_LEVEL) {
        exec(null, null, 'Debug Console', 'log', [ stringify(message), { logLevel: 'WARN' } ]);
    }
    else if (this.winConsole && this.winConsole.warn) {
        this.winConsole.warn(message);
    }
};

/**
 * Print an error message to the console
 * @param {Object|String} message Message or object to print to the console
 */
DebugConsole.prototype.error = function(message) {
    if (this.logLevel <= DebugConsole.ERROR_LEVEL) {
        exec(null, null, 'Debug Console', 'log', [ stringify(message), { logLevel: 'ERROR' } ]);
    }
    else if (this.winConsole && this.winConsole.error){
        this.winConsole.error(message);
    }
};

module.exports = new DebugConsole();
});

// file: lib/ios/plugin/ios/contacts.js
sktdefine("srt/plugin/ios/contacts", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

/**
 * Provides iOS enhanced contacts API.
 */
module.exports = {
    newContactUI : function(successCallback) {
        /*
         *    Create a contact using the iOS Contact Picker UI
         *    NOT part of W3C spec so no official documentation
         *
         * returns:  the id of the created contact as param to successCallback
         */
        exec(successCallback, null, "Contacts","newContact", []);
    },
    chooseContact : function(successCallback, options) {
        /*
         *    Select a contact using the iOS Contact Picker UI
         *    NOT part of W3C spec so no official documentation
         *
         *    @param errorCB error callback
         *    @param options object
         *    allowsEditing: boolean AS STRING
         *        "true" to allow editing the contact
         *        "false" (default) display contact
         *
         * returns:  the id of the selected contact as param to successCallback
         */
        exec(successCallback, null, "Contacts","chooseContact", [options]);
    }
};
});

// file: lib/ios/plugin/ios/device.js
sktdefine("srt/plugin/ios/device", function(sktrequire, exports, module) {
/**
 * this represents the mobile device, and provides properties for inspecting the model, version, UUID of the
 * phone, etc.
 * @constructor
 */
var exec = sktrequire('srt/exec'),
    utils = sktrequire('srt/utils'),
    channel = sktrequire('srt/channel');

var Device = function() {
    this.platform = null;
    this.version  = null;
    this.name     = null;
    this.srt  = null;
    this.uuid     = null;
};

Device.prototype.setInfo = function(info) {
    try {
        this.platform = info.platform;
        this.version = info.version;
        this.name = info.name;
        this.srt = info.srt;
        this.uuid = info.uuid;
        channel.onCordovaInfoReady.fire();
    } catch(e) {
        utils.alert('Error during device info setting in srt/plugin/ios/device!');
    }
};

module.exports = new Device();

});

// file: lib/ios/plugin/ios/nativecomm.js
sktdefine("srt/plugin/ios/nativecomm", function(sktrequire, exports, module) {
var srt = sktrequire('srt');

/**
 * Called by native code to retrieve all queued commands and clear the queue.
 */
module.exports = function() {
  var json = JSON.stringify(srt.commandQueue);
  srt.commandQueue = [];
  return json;
};
});

// file: lib/ios/plugin/ios/notification.js
sktdefine("srt/plugin/ios/notification", function(sktrequire, exports, module) {
var Media = sktrequire('srt/plugin/Media');

module.exports = {
    beep:function(count) {
        (new Media('beep.wav')).play();
    }
};
});

// file: lib/common/plugin/logger.js
sktdefine("srt/plugin/logger", function(sktrequire, exports, module) {
//------------------------------------------------------------------------------
// The logger module exports the following properties/functions:
//
// LOG                          - constant for the level LOG
// ERROR                        - constant for the level ERROR
// WARN                         - constant for the level WARN
// INFO                         - constant for the level INFO
// DEBUG                        - constant for the level DEBUG
// logLevel()                   - returns current log level
// logLevel(value)              - sets and returns a new log level
// useConsole()                 - returns whether logger is using console
// useConsole(value)            - sets and returns whether logger is using console
// log(message,...)             - logs a message at level LOG
// error(message,...)           - logs a message at level ERROR
// warn(message,...)            - logs a message at level WARN
// info(message,...)            - logs a message at level INFO
// debug(message,...)           - logs a message at level DEBUG
// logLevel(level,message,...)  - logs a message specified level
//
//------------------------------------------------------------------------------

var logger = exports;

var exec    = sktrequire('srt/exec');
var utils   = sktrequire('srt/utils');

var UseConsole   = true;
var Queued       = [];
var DeviceReady  = false;
var CurrentLevel;

/**
 * Logging levels
 */

var Levels = [
    "LOG",
    "ERROR",
    "WARN",
    "INFO",
    "DEBUG"
];

/*
 * add the logging levels to the logger object and
 * to a separate levelsMap object for testing
 */

var LevelsMap = {};
for (var i=0; i<Levels.length; i++) {
    var level = Levels[i];
    LevelsMap[level] = i;
    logger[level]    = level;
}

CurrentLevel = LevelsMap.WARN;

/**
 * Getter/Setter for the logging level
 *
 * Returns the current logging level.
 *
 * When a value is passed, sets the logging level to that value.
 * The values should be one of the following constants:
 *    logger.LOG
 *    logger.ERROR
 *    logger.WARN
 *    logger.INFO
 *    logger.DEBUG
 *
 * The value used determines which messages get printed.  The logging
 * values above are in order, and only messages logged at the logging
 * level or above will actually be displayed to the user.  Eg, the
 * default level is WARN, so only messages logged with LOG, ERROR, or
 * WARN will be displayed; INFO and DEBUG messages will be ignored.
 */
logger.level = function (value) {
    if (arguments.length) {
        if (LevelsMap[value] === null) {
            throw new Error("invalid logging level: " + value);
        }
        CurrentLevel = LevelsMap[value];
    }

    return Levels[CurrentLevel];
};

/**
 * Getter/Setter for the useConsole functionality
 *
 * When useConsole is true, the logger will log via the
 * browser 'console' object.  Otherwise, it will use the
 * native Logger plugin.
 */
logger.useConsole = function (value) {
    if (arguments.length) UseConsole = !!value;

    if (UseConsole) {
        if (typeof console == "undefined") {
            throw new Error("global console object is not defined");
        }

        if (typeof console.log != "function") {
            throw new Error("global console object does not have a log function");
        }

        if (typeof console.useLogger == "function") {
            if (console.useLogger()) {
                throw new Error("console and logger are too intertwingly");
            }
        }
    }

    return UseConsole;
};

/**
 * Logs a message at the LOG level.
 *
 * Parameters passed after message are used applied to
 * the message with utils.format()
 */
logger.log   = function(message) { logWithArgs("LOG",   arguments); };

/**
 * Logs a message at the ERROR level.
 *
 * Parameters passed after message are used applied to
 * the message with utils.format()
 */
logger.error = function(message) { logWithArgs("ERROR", arguments); };

/**
 * Logs a message at the WARN level.
 *
 * Parameters passed after message are used applied to
 * the message with utils.format()
 */
logger.warn  = function(message) { logWithArgs("WARN",  arguments); };

/**
 * Logs a message at the INFO level.
 *
 * Parameters passed after message are used applied to
 * the message with utils.format()
 */
logger.info  = function(message) { logWithArgs("INFO",  arguments); };

/**
 * Logs a message at the DEBUG level.
 *
 * Parameters passed after message are used applied to
 * the message with utils.format()
 */
logger.debug = function(message) { logWithArgs("DEBUG", arguments); };

// log at the specified level with args
function logWithArgs(level, args) {
    args = [level].concat([].slice.call(args));
    logger.logLevel.apply(logger, args);
}

/**
 * Logs a message at the specified level.
 *
 * Parameters passed after message are used applied to
 * the message with utils.format()
 */
logger.logLevel = function(level, message /* , ... */) {
    // format the message with the parameters
    var formatArgs = [].slice.call(arguments, 2);
    message    = utils.vformat(message, formatArgs);

    if (LevelsMap[level] === null) {
        throw new Error("invalid logging level: " + level);
    }

    if (LevelsMap[level] > CurrentLevel) return;

    // queue the message if not yet at deviceready
    if (!DeviceReady && !UseConsole) {
        Queued.push([level, message]);
        return;
    }

    // if not using the console, use the native logger
    if (!UseConsole) {
        exec(null, null, "Logger", "logLevel", [level, message]);
        return;
    }

    // make sure console is not using logger
    if (console.__usingCordovaLogger) {
        throw new Error("console and logger are too intertwingly");
    }

    // log to the console
    switch (level) {
        case logger.LOG:   console.log(message); break;
        case logger.ERROR: console.log("ERROR: " + message); break;
        case logger.WARN:  console.log("WARN: "  + message); break;
        case logger.INFO:  console.log("INFO: "  + message); break;
        case logger.DEBUG: console.log("DEBUG: " + message); break;
    }
};

// when deviceready fires, log queued messages
logger.__onDeviceReady = function() {
    if (DeviceReady) return;

    DeviceReady = true;

    for (var i=0; i<Queued.length; i++) {
        var messageArgs = Queued[i];
        logger.logLevel(messageArgs[0], messageArgs[1]);
    }

    Queued = null;
};

// add a deviceready event to log queued messages
document.addEventListener("deviceready", logger.__onDeviceReady, false);

});

//[20120619][chisu]HTML5 Network Info add
// file: lib/common/plugin/connection.js
sktdefine("srt/plugin/connection", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec'),
    srt = sktrequire('srt'),
    channel = sktrequire('srt/channel');

var NetworkConnection = function () {
    this.type = null;
    this._firstRun = true;
    this._timer = null;
    this.timeout = 500;

    var me = this;

    channel.onSKTRuntimeReady.subscribeOnce(function() {
        me.getInfo(function (info) {
            me.type = info;
            if (info === "none") {
                // set a timer if still offline at the end of timer send the offline event
                me._timer = setTimeout(function(){
                    srt.fireDocumentEvent("offline");
                    me._timer = null;
                    }, me.timeout);
            } else {
                // If there is a current offline event pending clear it
                if (me._timer !== null) {
                    clearTimeout(me._timer);
                    me._timer = null;
                }
                srt.fireDocumentEvent("online");
            }

            // should only fire this once
            if (me._firstRun) {
                me._firstRun = false;
                channel.onCordovaConnectionReady.fire();
            }
        },
        function (e) {
            // If we can't get the network info we should still tell Cordova
            // to fire the deviceready event.
            if (me._firstRun) {
                me._firstRun = false;
                channel.onCordovaConnectionReady.fire();
            }
            console.log("Error initializing Network Connection: " + e);
        });
    });
    
};

/**
 * Get connection info
 *
 * @param {Function} successCallback The function to call when the Connection data is available
 * @param {Function} errorCallback The function to call when there is an error getting the Connection data. (OPTIONAL)
 */
NetworkConnection.prototype.getInfo = function (successCallback, errorCallback) {
    // Get info
    exec(successCallback, errorCallback, "NetworkStatus", "getConnectionInfo", []);
};

module.exports = new NetworkConnection();
});

//[20120823][chisu]add childbrowser
//file: lib/common/plugin/childbrowser.js
sktdefine("srt/plugin/childbrowser", function(sktrequire, exports, module) {

	var utils = sktrequire("srt/utils"),
	exec = sktrequire("srt/exec");
	
	/**
	 * Constructor
	 */
	function ChildBrowser() {
	};

	ChildBrowser.CLOSE_EVENT = 0;
	ChildBrowser.LOCATION_CHANGED_EVENT = 1;

	/**
	 * Display a new browser with the specified URL.
	 * This method loads up a new web view in a dialog.
	 *
	 * @param url           The url to load
	 * @param options       An object that specifies additional options
	 */
	ChildBrowser.prototype.showWebPage = function(url, options) {
	    if (options === null || options === "undefined") {
	        var options = new Object();
	        options.showLocationBar = true;
	    }
	    
	    srt.exec(this._onEvent, this._onError, "ChildBrowser", "showWebPage", [url, options]);
	};

	/**
	 * Close the browser opened by showWebPage.
	 */
	ChildBrowser.prototype.close = function(successCallback) {
		srt.exec(this._onEvent, null, "ChildBrowser", "close", []);
	};

	/**
	 * Display a new browser with the specified URL.
	 * This method starts a new web browser activity.
	 *
	 * @param url           The url to load
	 * @param usecordova   Load url in cordova webview [optional]
	 */
	//[20120827][chisu]not used
	/*
	ChildBrowser.prototype.openExternal = function(url, userSRT) {
	    if (userSRT === true) {
	        navigator.app.loadUrl(url);
	    }
	    else {
	    	srt.exec(null, null, "ChildBrowser", "openExternal", [url, userSRT]);
	    }
	};
	*/
	
	/**
	 * Method called when the child browser has an event.
	 */
	ChildBrowser.prototype._onEvent = function(data) {
	    if (data.type == ChildBrowser.CLOSE_EVENT && typeof navigator.childBrowser.onClose === "function") {
	    	navigator.childBrowser.onClose();
	    }
	    if (data.type == ChildBrowser.LOCATION_CHANGED_EVENT && typeof navigator.childBrowser.onLocationChange === "function") {
	    	navigator.childBrowser.onLocationChange(data.location);
	    }
	};

	/**
	 * Method called when the child browser has an error.
	 */
	ChildBrowser.prototype._onError = function(data) {
	    if (typeof navigator.childBrowser.onError === "function") {
	    	navigator.childBrowser.onError(data);
	    }
	};
	
	module.exports = new ChildBrowser();

});

//[20120820][chisu]add localnotification
//file: lib/common/plugin/localnotification.js
sktdefine("srt/plugin/localnotification", function(sktrequire, exports, module) {

	var utils = sktrequire("srt/utils"),
	exec = sktrequire("srt/exec");

	/**
	 * Empty constructor
	 */
	var LocalNotification = function() {
	};

	/**
	 * Register a notification message for a specific date / time
	 * 
	 * @param successCB
	 * @param failureCB
	 * @param options
	 *            Array with arguments. Valid arguments are date, message,
	 *            repeatDaily and id
	 */
	LocalNotification.prototype.add = function(successCallback,errorcallback,options) {
		// successCallback required
		if (typeof successCallback !== "function" ) {
			throw "add must be called with at least a success callback function as first parameter.";
		}  
		// successCallback required
		else if (successCallback === null ) {
			throw "add must be called with at least a success callback function as first parameter.";
		} 
		
		var defaults = {
			date : new Date(),
			message : '',
			ticker : '',
			repeatDaily : false,
			id : ""
		};

		if (options.date) {
			options.date = (options.date.getMonth()+1) + "/" + (options.date.getDate()) + "/"
					+ (options.date.getFullYear()) + "/" + (options.date.getHours()) + "/"
					+ (options.date.getMinutes());
		}

		for ( var key in defaults) {
			if (typeof options[key] !== "undefined")
				defaults[key] = options[key];
		}

		srt.exec(successCallback, errorcallback, 'LocalNotification', 'add', new Array(defaults));
	};

	/**
	 * Cancel an existing notification using its original ID.
	 * 
	 * @param id
	 *            The ID that was used when creating the notification using the
	 *            'add' method.
	 */
	LocalNotification.prototype.cancel = function(successCallback, errorCallback,notificationId) {
		// successCallback required
		if (typeof successCallback !== "function" ) {
			throw "cancel must be called with at least a success callback function as first parameter.";
		}  
		// successCallback required
		else if (successCallback === null ) {
			throw "cancel must be called with at least a success callback function as first parameter.";
		} 
		
		srt.exec(successCallback, errorCallback, 'LocalNotification', 'cancel', new Array({
			id : notificationId
		}));
	};

	/**
	 * Cancel all notifications that were created by your application.
	 */
	LocalNotification.prototype.cancelAll = function(successCallback,errorCallback) {
		// successCallback required
		if (typeof successCallback !== "function" ) {
			throw "cancelAll must be called with at least a success callback function as first parameter.";
		}  
		// successCallback required
		else if (successCallback === null ) {
			throw "cancelAll must be called with at least a success callback function as first parameter.";
		} 
		
		srt.exec(successCallback, errorCallback, 'LocalNotification', 'cancelAll', new Array());
	};
	
	module.exports = new LocalNotification();
});

//[20120820][chisu]add screenshot
//file: lib/common/plugin/screenshot.js
sktdefine("srt/plugin/screenshot", function(sktrequire, exports, module) {

	var utils = sktrequire("srt/utils"),
	exec = sktrequire("srt/exec");


	var screenshot = {
		
		/**
		 * Capture Screen
		 *
		 * @param {Function} successCallback The function to call when the screen is caputred
		 * @param {Function} errorCallback The function to call when there is an error capturing screen
		 */
		captureScreenshot: function(successCallback, errorCallback, filename) {
				// successCallback required
				if (typeof successCallback !== "function" ) {
					throw "captureScreenshot must be called with at least a success callback function as first parameter.";
				}  
				// successCallback required
				else if (successCallback === null ) {
					throw "captureScreenshot must be called with at least a success callback function as first parameter.";
				} 
				
				else if(filename != null && typeof filename != "string"){
					throw "3rd argument must be string Type.";
				}

				exec(successCallback, errorCallback, "ScreenShot", "captureScreenshot", [filename]);
			}
	};

	module.exports = screenshot;

});

//[20120820][chisu]add deviceinteraction
//file: lib/common/plugin/deviceinteraction.js
sktdefine("srt/plugin/deviceinteraction", function(sktrequire, exports, module) {
	/**
	 * This class provides access to devicestatus data.
	 * @constructor
	 */
	var utils = sktrequire("srt/utils"),
	exec = sktrequire("srt/exec");


	var deviceinteraction = {
		
		/**
		 * start Beep
		 * 
		 * @param long time beep number 
		 */
		startBeep: function(time){
				if (typeof time == "string" ) {
					throw "1rd argument must be number Type.";
				}
				if (time == null || time == undefined) {
					time = 1000;
				}

				return exec(null, null, "DeviceInteraction", "startBeep", [time]);
			},
		/**
		 * stop Beep
		 */
		stopBeep: function(){
				return exec(null, null, "DeviceInteraction", "stopBeep", []);
			},
		/**
		 * Change the Device RingTone
		 *
		 * @param {Function} successCallback The function to call when the Ring tone is correctty setted.
		 * @param {Function} errorCallback The function to call when there is an error changing the ringtone
		 * @param String path 
		 * @param String name [OPTIONAL]
		 */
		setCallRingtone: function(successCallback, errorCallback, path , name) {
				// successCallback required
				if (typeof successCallback !== "function" ) {
					throw "setCallRingtone must be called with at least a success callback function as first parameter.";
				}  
				// successCallback required
				else if (successCallback === null ) {
					throw "setCallRingtone must be called with at least a success callback function as first parameter.";
				} 

				if (typeof path != "string" ) {
					throw "3rd argument must be string Type.";
				}
				
				exec(successCallback, errorCallback, "DeviceInteraction", "setCallRingtone", [path, name]);
			},
		/**
		 * Change the Device Wall Paper
		 *
		 * @param {Function} successCallback The function to call when the WallPaper is changed.
		 * @param {Function} errorCallback The function to call when there is an error changing the wallpaper
		 * @param String path 
		 */
		setWallpaper: function(successCallback, errorCallback, path) {
				// successCallback required
				if (typeof successCallback !== "function" ) {
					throw "setWallpaper must be called with at least a success callback function as first parameter.";
				}  
				// successCallback required
				else if (successCallback === null ) {
					throw "setWallpaper must be called with at least a success callback function as first parameter.";
				} 

				if (typeof path != "string" ) {
					throw "3rd argument must be string Type.";
				}

				exec(successCallback, errorCallback, "DeviceInteraction", "setWallpaper", [path]);
			}
	};

	module.exports = deviceinteraction;

});

//[20120814][chisu]add devicestatus
//file: lib/common/plugin/devicestatus.js
sktdefine("srt/plugin/devicestatus", function(sktrequire, exports, module) {
	/**
	 * This class provides access to devicestatus data.
	 * @constructor
	 */
	var utils = sktrequire("srt/utils"),
	exec = sktrequire("srt/exec");


	var devicestatus = {

		getPropertyValue: function(successCallback, errorCallback, property) {
			// successCallback required
			if (typeof successCallback !== "function" ) {
				throw "getPropertyValue must be called with at least a success callback function as first parameter.";
			}  
			// successCallback required
			else if (successCallback === null ) {
				throw "getPropertyValue must be called with at least a success callback function as first parameter.";
			} 

			if (typeof property != "object" ) {
				throw "3rd argument must be Object Type.";
			}

			function sc(val){
				successCallback(val.property, val.value);	
			}
			
			exec(sc, errorCallback, "DeviceStatus", "getPropertyValue", [property]);
		},

		isSupported: function(aspect, property){
			if (typeof aspect != "string" ) {
				throw "1rd argument must be string Type.";
			}
			if (typeof property != "string" ) {
				throw "2rd argument must be string Type.";
			}
			
			return exec(null, null, "DeviceStatus", "isSupported", [aspect,property]);
		}


	};

	module.exports = devicestatus;

});

//[20120619][chisu]add messaging
//file: lib/common/plugin/messaging.js
sktdefine("srt/plugin/messaging", function(sktrequire, exports, module) {
/**
* This class provides access to sending message
* @constructor
*/
var utils = sktrequire("srt/utils"),
  exec = sktrequire("srt/exec"),
  Messaging = sktrequire("srt/plugin/Messaging");
  //Message = sktrequire("srt/plugin/Message");


var messaging = {

  sendMessage: function(successCallback, errorCallback, msg) {
      // successCallback required
      if (typeof successCallback !== "function" ) {
          throw "sendMessage must be called with at least a success callback function as first parameter.";
      }  
      // successCallback required
      else if (successCallback === null ) {
          throw "sendMessage must be called with at least a success callback function as first parameter.";
      } 
      
      // msg required
      if (typeof msg != "object" ) {
          throw "3rd argument must be Message Type.";
      }
      
      exec(successCallback, errorCallback, "Messaging", "sendMessage", [msg]);
  },
  
  createMessage: function(type){
  	var msg = new Message();
  	msg.type = type;
  	return msg;
  }
  

};

module.exports = messaging;

});

//[20120613][chisu]Messaging
//file: lib/common/plugin/Messaging.js
sktdefine("srt/plugin/Messaging", function(sktrequire, exports, module) {
	module.exports = {
			TYPE_SMS:   1,
			TYPE_MMS:   2,
			TYPE_EMAIL: 3
	};
});

//[20120613][chisu]MessagingError
//file: lib/common/plugin/MessagingError.js
sktdefine("srt/plugin/MessagingError", function(sktrequire, exports, module) {
	module.exports = {
			UNKNOWN_ERROR :  		   1,
			INVALID_ARGUMENT_ERROR :   2,
			TIMEOUT_ERROR:             3,
			PENDING_OPERATION_ERROR :  4,
			IO_ERROR :                 5,
			NOT_SUPPORTED_ERROR:       6,
			PERMISSION_DENIED_ERROR :  20,
			MESSAGE_SIZE_EXCEEDED:     30
	};
})

//[20120613][chisu]Message
//file: lib/common/plugin/Message.js
sktdefine("srt/plugin/Message", function(sktrequire, exports, module) {
	
var Message = function(type,from,to,cc,bcc,body,subject,attachments) {
this.type = type;
this.from = from;
this.to = to;
this.cc = cc;
this.bcc = bcc;
this.body = body;
this.subject = subject;
this.attachments = attachments;

};

module.exports = Message;

});

// file: lib/common/plugin/notification.js
sktdefine("srt/plugin/notification", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

/**
 * Provides access to notifications on the device.
 */

module.exports = {

    /**
     * Open a native alert dialog, with a customizable title and button text.
     *
     * @param {String} message              Message to print in the body of the alert
     * @param {Function} completeCallback   The callback that is called when user clicks on a button.
     * @param {String} title                Title of the alert dialog (default: Alert)
     * @param {String} buttonLabel          Label of the close button (default: OK)
     */
    alert: function(message, completeCallback, title, buttonLabel) {
        var _title = (title || "Alert");
        var _buttonLabel = (buttonLabel || "OK");
        exec(completeCallback, null, "Notification", "alert", [message, _title, _buttonLabel]);
    },

    /**
     * Open a native confirm dialog, with a customizable title and button text.
     * The result that the user selects is returned to the result callback.
     *
     * @param {String} message              Message to print in the body of the alert
     * @param {Function} resultCallback     The callback that is called when user clicks on a button.
     * @param {String} title                Title of the alert dialog (default: Confirm)
     * @param {String} buttonLabels         Comma separated list of the labels of the buttons (default: 'OK,Cancel')
     */
    confirm: function(message, resultCallback, title, buttonLabels) {
        var _title = (title || "Confirm");
        var _buttonLabels = (buttonLabels || "OK,Cancel");
        exec(resultCallback, null, "Notification", "confirm", [message, _title, _buttonLabels]);
    },

    /**
     * Causes the device to vibrate.
     *
     * @param {Integer} mills       The number of milliseconds to vibrate for.
     */
    vibrate: function(mills) {
        exec(null, null, "Notification", "vibrate", [mills]);
    },

    /**
     * Causes the device to beep.
     * On Android, the default notification ringtone is played "count" times.
     *
     * @param {Integer} count       The number of beeps.
     */
    beep: function(count) {
        exec(null, null, "Notification", "beep", [count]);
    }
};
});

//[20120613][chisu] navigator.vibrate();
//file: lib/common/plugin/vibrate.js
sktdefine("srt/plugin/vibrate", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

/**
 * Causes the device to vibrate.
 *
 * @param {Integer} mills       The number of milliseconds to vibrate for.
 */
var vibrate = function(time) {
	 if (typeof time === 'object') {
		 exec(null, null, "Vibrate", "vibratepattern", [time]);
	 }
	 else if(typeof time === 'number'){
		 exec(null, null, "Vibrate", "vibrate", [time]);
	 }
};

module.exports = vibrate;

});

// file: lib/common/plugin/requestFileSystem.js
sktdefine("srt/plugin/requestFileSystem", function(sktrequire, exports, module) {
var FileError = sktrequire('srt/plugin/FileError'),
    FileSystem = sktrequire('srt/plugin/FileSystem'),
    exec = sktrequire('srt/exec');

/**
 * Request a file system in which to store application data.
 * @param type  local file system type
 * @param size  indicates how much storage space, in bytes, the application expects to need
 * @param successCallback  invoked with a FileSystem object
 * @param errorCallback  invoked if error occurs retrieving file system
 */
var requestFileSystem = function(type, size, successCallback, errorCallback) {
    var fail = function(code) {
        if (typeof errorCallback === 'function') {
            errorCallback(new FileError(code));
        }
    };

    if (type < 0 || type > 3) {
        fail(FileError.SYNTAX_ERR);
    } else {
        // if successful, return a FileSystem object
        var success = function(file_system) {
            if (file_system) {
                if (typeof successCallback === 'function') {
                    // grab the name and root from the file system object
                    var result = new FileSystem(file_system.name, file_system.root);
                    successCallback(result);
                }
            }
            else {
                // no FileSystem object returned
                fail(FileError.NOT_FOUND_ERR);
            }
        };
        exec(success, fail, "File", "requestFileSystem", [type, size]);
    }
};

module.exports = requestFileSystem;
});

// file: lib/common/plugin/resolveLocalFileSystemURI.js
sktdefine("srt/plugin/resolveLocalFileSystemURI", function(sktrequire, exports, module) {
var DirectoryEntry = sktrequire('srt/plugin/DirectoryEntry'),
    FileEntry = sktrequire('srt/plugin/FileEntry'),
    FileError = sktrequire('srt/plugin/FileError'),
    exec = sktrequire('srt/exec');

/**
 * Look up file system Entry referred to by local URI.
 * @param {DOMString} uri  URI referring to a local file or directory
 * @param successCallback  invoked with Entry object corresponding to URI
 * @param errorCallback    invoked if error occurs retrieving file system entry
 */
module.exports = function(uri, successCallback, errorCallback) {
    // error callback
    var fail = function(error) {
        if (typeof errorCallback === 'function') {
            errorCallback(new FileError(error));
        }
    };
    // sanity check for 'not:valid:filename'
    if(!uri || uri.split(":").length > 2) {
        setTimeout( function() {
            fail(FileError.ENCODING_ERR);
        },0);
        return;
    }
    // if successful, return either a file or directory entry
    var success = function(entry) {
        var result;
        if (entry) {
            if (typeof successCallback === 'function') {
                // create appropriate Entry object
                result = (entry.isDirectory) ? new DirectoryEntry(entry.name, entry.fullPath) : new FileEntry(entry.name, entry.fullPath);
                try {
                    successCallback(result);
                }
                catch (e) {
                    console.log('Error invoking callback: ' + e);
                }
            }
        }
        else {
            // no Entry object returned
            fail(FileError.NOT_FOUND_ERR);
        }
    };

    exec(success, fail, "File", "resolveLocalFileSystemURI", [uri]);
};

});

// file: lib/common/plugin/splashscreen.js
sktdefine("srt/plugin/splashscreen", function(sktrequire, exports, module) {
var exec = sktrequire('srt/exec');

var splashscreen = {
    hide:function() {
        exec(null, null, "SplashScreen", "hide", []);
    }
};

module.exports = splashscreen;
});

// file: lib/common/utils.js
sktdefine("srt/utils", function(sktrequire, exports, module) {
var utils = exports;

/**
 * Returns an indication of whether the argument is an array or not
 */
utils.isArray = function(a) {
    return Object.prototype.toString.call(a) == '[object Array]';
};

/**
 * Returns an indication of whether the argument is a Date or not
 */
utils.isDate = function(d) {
    return Object.prototype.toString.call(d) == '[object Date]';
};

/**
 * Does a deep clone of the object.
 */
utils.clone = function(obj) {
    if(!obj || typeof obj == 'function' || utils.isDate(obj) || typeof obj != 'object') {
        return obj;
    }

    var retVal, i;

    if(utils.isArray(obj)){
        retVal = [];
        for(i = 0; i < obj.length; ++i){
            retVal.push(utils.clone(obj[i]));
        }
        return retVal;
    }

    retVal = {};
    for(i in obj){
        if(!(i in retVal) || retVal[i] != obj[i]) {
            retVal[i] = utils.clone(obj[i]);
        }
    }
    return retVal;
};

/**
 * Returns a wrappered version of the function
 */
utils.close = function(context, func, params) {
    if (typeof params == 'undefined') {
        return function() {
            return func.apply(context, arguments);
        };
    } else {
        return function() {
            return func.apply(context, params);
        };
    }
};

/**
 * Create a UUID
 */
utils.createUUID = function() {
    return UUIDcreatePart(4) + '-' +
        UUIDcreatePart(2) + '-' +
        UUIDcreatePart(2) + '-' +
        UUIDcreatePart(2) + '-' +
        UUIDcreatePart(6);
};

/**
 * Extends a child object from a parent object using classical inheritance
 * pattern.
 */
utils.extend = (function() {
    // proxy used to establish prototype chain
    var F = function() {};
    // extend Child from Parent
    return function(Child, Parent) {
        F.prototype = Parent.prototype;
        Child.prototype = new F();
        Child.__super__ = Parent.prototype;
        Child.prototype.constructor = Child;
    };
}());

/**
 * Alerts a message in any available way: alert or console.log.
 */
utils.alert = function(msg) {
    if (alert) {
        alert(msg);
    } else if (console && console.log) {
        console.log(msg);
    }
};

/**
 * Formats a string and arguments following it ala sprintf()
 *
 * see utils.vformat() for more information
 */
utils.format = function(formatString /* ,... */) {
    var args = [].slice.call(arguments, 1);
    return utils.vformat(formatString, args);
};

/**
 * Formats a string and arguments following it ala vsprintf()
 *
 * format chars:
 *   %j - format arg as JSON
 *   %o - format arg as JSON
 *   %c - format arg as ''
 *   %% - replace with '%'
 * any other char following % will format it's
 * arg via toString().
 *
 * for rationale, see FireBug's Console API:
 *    http://getfirebug.com/wiki/index.php/Console_API
 */
utils.vformat = function(formatString, args) {
    if (formatString === null || formatString === undefined) return "";
    if (arguments.length == 1) return formatString.toString();
    if (typeof formatString != "string") return formatString.toString();

    var pattern = /(.*?)%(.)(.*)/;
    var rest    = formatString;
    var result  = [];

    while (args.length) {
        var arg   = args.shift();
        var match = pattern.exec(rest);

        if (!match) break;

        rest = match[3];

        result.push(match[1]);

        if (match[2] == '%') {
            result.push('%');
            args.unshift(arg);
            continue;
        }

        result.push(formatted(arg, match[2]));
    }

    result.push(rest);

    return result.join('');
};

//------------------------------------------------------------------------------
function UUIDcreatePart(length) {
    var uuidpart = "";
    for (var i=0; i<length; i++) {
        var uuidchar = parseInt((Math.random() * 256), 10).toString(16);
        if (uuidchar.length == 1) {
            uuidchar = "0" + uuidchar;
        }
        uuidpart += uuidchar;
    }
    return uuidpart;
}

//------------------------------------------------------------------------------
function formatted(object, formatChar) {

    try {
        switch(formatChar) {
            case 'j':
            case 'o': return JSON.stringify(object);
            case 'c': return '';
        }
    }
    catch (e) {
        return "error JSON.stringify()ing argument: " + e;
    }

    if ((object === null) || (object === undefined)) {
        return Object.prototype.toString.call(object);
    }

    return object.toString();
}

});


window.srt = sktrequire('srt');

// file: lib/scripts/bootstrap.js
(function (context) {
    var channel = sktrequire("srt/channel"),
        _self = {
            boot: function () {
                /**
                 * Create all cordova objects once page has fully loaded and native side is ready.
                 */
                channel.join(function() {
                    var builder = sktrequire('srt/builder'),
                        base = sktrequire('srt/common'),
                        platform = sktrequire('srt/platform');

                    // Drop the common globals into the window object, but be nice and don't overwrite anything.
                    builder.build(base.objects).intoButDontClobber(window);

                    // Drop the platform-specific globals into the window object
                    // and clobber any existing object.
                    builder.build(platform.objects).intoAndClobber(window);

                    // Merge the platform-specific overrides/enhancements into
                    // the window object.
                    if (typeof platform.merges !== 'undefined') {
                        builder.build(platform.merges).intoAndMerge(window);
                    }

                    // Call the platform-specific initialization
                    platform.initialize();

                    // Fire event to notify that all objects are created
                    channel.onSKTRuntimeReady.fire();

                    // Fire onDeviceReady event once all constructors have run and
                    // cordova info has been received from native side.
                    channel.join(function() {
                        sktrequire('srt').fireDocumentEvent('deviceready');
                    }, channel.deviceReadyChannelsArray);

                }, [ channel.onDOMContentLoaded, channel.onNativeReady ]);
            }
        };

    // boot up once native side is ready
    channel.onNativeReady.subscribeOnce(_self.boot);

    // _nativeReady is global variable that the native side can set
    // to signify that the native code is ready. It is a global since
    // it may be called before any cordova JS is ready.
    if (window._nativeReady) {
        channel.onNativeReady.fire();
    }

}(window));


})();